import { A as CoreLibraryService, D as CreateFormDialogService, O as CoreFormService, S as Tooltip, T as CodeEditor, U as Dialog, V as CORE_FORM_TEMPLATES, Y as getDefaultPropertyValue, Z as modifyPropertyTarget, _ as JSONSchemaValidator, a as MarkdownDialogService, c as ExpressionDialogService, d as ExportDialogService, dt as PropertyType, f as PreviewDeviceToolbar, i as FieldPresetDialogService, k as CoreFieldService, l as ArrayTableDialogService, n as FormStoreRecoveryRequiredError, o as beautifyCode, p as FormPreviewContent, r as ImportDialogService, s as flattenToOneLine, u as PreviewDialogService, ut as PropertyChangeType, v as JSONFormatValidator, y as JSONContent } from "./ngx-formly-builder-ui-types-D0bY_dJC.mjs";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DestroyRef, Directive, booleanAttribute, computed, effect, forwardRef, inject, input, model, output, signal, viewChild } from "@angular/core";
import { defer, finalize } from "rxjs";
import { get } from "lodash-es";
import * as i1 from "@angular/forms";
import { FormsModule, NG_VALIDATORS, NgForm, NgModel } from "@angular/forms";
import { MatSlideToggle } from "@angular/material/slide-toggle";
import { MatSelect } from "@angular/material/select";
import { MatOption } from "@angular/material/core";
import saveAs from "file-saver";
import { CdkDrag, CdkDragHandle, CdkDropList } from "@angular/cdk/drag-drop";
var JSONArrayValidator = class JSONArrayValidator {
	enabled = input(true, {
		...ngDevMode ? { debugName: "enabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute,
		alias: "coreJsonArray"
	});
	validate(control) {
		if (this.enabled() && control.value) return control.value[0] !== "[" ? { jsonArray: this.getValidationErrors() } : null;
		return null;
	}
	getValidationErrors() {
		return [{
			label: "Array Root",
			messages: ["JSON root must be an array"]
		}];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: JSONArrayValidator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: JSONArrayValidator,
		isStandalone: true,
		selector: "[coreJsonArray]",
		inputs: { enabled: {
			classPropertyName: "enabled",
			publicName: "coreJsonArray",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => JSONArrayValidator),
			multi: true
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: JSONArrayValidator,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[coreJsonArray]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => JSONArrayValidator),
				multi: true
			}]
		}]
	}],
	propDecorators: { enabled: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "coreJsonArray",
			required: false
		}]
	}] }
});
var JSONContentDialog = class JSONContentDialog {
	header = input.required(...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	saveButtonLabel = input.required(...ngDevMode ? [{ debugName: "saveButtonLabel" }] : /* istanbul ignore next */ []);
	saveButtonIcon = input.required(...ngDevMode ? [{ debugName: "saveButtonIcon" }] : /* istanbul ignore next */ []);
	formFieldsJson = model.required(...ngDevMode ? [{ debugName: "formFieldsJson" }] : /* istanbul ignore next */ []);
	isOpen = model.required(...ngDevMode ? [{ debugName: "isOpen" }] : /* istanbul ignore next */ []);
	isArrayRoot = input(false, {
		...ngDevMode ? { debugName: "isArrayRoot" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	schema = input(...ngDevMode ? [void 0, { debugName: "schema" }] : /* istanbul ignore next */ []);
	form = viewChild.required(NgForm, ...ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []);
	jsonModel = viewChild("jsonModel", {
		...ngDevMode ? { debugName: "jsonModel" } : /* istanbul ignore next */ {},
		read: NgModel
	});
	save = output();
	inputId = `dialog-input-${Math.random().toString(36).substring(2, 15)}`;
	dialogPT = {
		header: { style: { height: "5rem" } },
		content: { style: { height: "calc(100% - 10rem)" } },
		footer: { style: {
			height: "5rem",
			alignItems: "center",
			justifyContent: "space-between"
		} }
	};
	beautify() {
		if (!this.form().valid) return;
		try {
			const parsed = JSON.parse(this.formFieldsJson());
			this.formFieldsJson.set(JSON.stringify(parsed, null, 2));
		} catch (error) {
			console.error("Error beautifying", error);
		}
	}
	saveForm() {
		this.save.emit(this.form().value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: JSONContentDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: JSONContentDialog,
		isStandalone: true,
		selector: "core-json-content-dialog",
		inputs: {
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			saveButtonLabel: {
				classPropertyName: "saveButtonLabel",
				publicName: "saveButtonLabel",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			saveButtonIcon: {
				classPropertyName: "saveButtonIcon",
				publicName: "saveButtonIcon",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			formFieldsJson: {
				classPropertyName: "formFieldsJson",
				publicName: "formFieldsJson",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			isOpen: {
				classPropertyName: "isOpen",
				publicName: "isOpen",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			isArrayRoot: {
				classPropertyName: "isArrayRoot",
				publicName: "isArrayRoot",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			schema: {
				classPropertyName: "schema",
				publicName: "schema",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			formFieldsJson: "formFieldsJsonChange",
			isOpen: "isOpenChange",
			save: "save"
		},
		viewQueries: [{
			propertyName: "form",
			first: true,
			predicate: NgForm,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "jsonModel",
			first: true,
			predicate: ["jsonModel"],
			descendants: true,
			read: NgModel,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-dialog
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [pt]="dialogPT"
      [header]="header()"
      [(visible)]="isOpen"
    >
      <form
        #form="ngForm"
        class="flex h-full min-h-0 flex-col"
      >
        @if (isOpen()) {
          <div
            class="grid h-20 w-full grid-cols-1 items-start gap-2 py-2 sm:grid-cols-2 lg:grid-cols-3"
          >
            <ng-content select="[formFields]" />
          </div>
          <core-json-content
            #jsonModel="ngModel"
            class="h-[calc(100%-5rem)]"
            name="json"
            required
            coreJsonFormat
            [coreJsonArray]="isArrayRoot()"
            [coreJsonSchema]="schema()"
            [(ngModel)]="formFieldsJson"
          />
        }
      </form>
      <ng-template #footer>
        <span class="inline-flex items-center gap-2">
          <button
            coreButton
            text
            aria-label="Beautify JSON"
            coreTooltip="Beautify JSON"
            tooltipPosition="above"
            [disabled]="!jsonModel()?.valid"
            (click)="beautify()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              wand_stars
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Beautify</span
            >
          </button>
          <ng-content select="[lhsActions]" />
        </span>
        <button
          coreButton
          [disabled]="!this.form().valid"
          (click)="saveForm()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            {{ saveButtonIcon() }}
          </i>
          <span coreButtonLabel>{{ saveButtonLabel() }}</span>
        </button>
      </ng-template>
    </core-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "component",
				type: JSONContent,
				selector: "core-json-content",
				inputs: ["editable"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "directive",
				type: JSONFormatValidator,
				selector: "[coreJsonFormat]"
			},
			{
				kind: "directive",
				type: JSONArrayValidator,
				selector: "[coreJsonArray]",
				inputs: ["coreJsonArray"]
			},
			{
				kind: "directive",
				type: JSONSchemaValidator,
				selector: "[coreJsonSchema]",
				inputs: ["coreJsonSchema"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: JSONContentDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-json-content-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Dialog,
				JSONContent,
				FormsModule,
				JSONFormatValidator,
				JSONArrayValidator,
				JSONSchemaValidator,
				Tooltip
			],
			template: `
    <core-dialog
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [pt]="dialogPT"
      [header]="header()"
      [(visible)]="isOpen"
    >
      <form
        #form="ngForm"
        class="flex h-full min-h-0 flex-col"
      >
        @if (isOpen()) {
          <div
            class="grid h-20 w-full grid-cols-1 items-start gap-2 py-2 sm:grid-cols-2 lg:grid-cols-3"
          >
            <ng-content select="[formFields]" />
          </div>
          <core-json-content
            #jsonModel="ngModel"
            class="h-[calc(100%-5rem)]"
            name="json"
            required
            coreJsonFormat
            [coreJsonArray]="isArrayRoot()"
            [coreJsonSchema]="schema()"
            [(ngModel)]="formFieldsJson"
          />
        }
      </form>
      <ng-template #footer>
        <span class="inline-flex items-center gap-2">
          <button
            coreButton
            text
            aria-label="Beautify JSON"
            coreTooltip="Beautify JSON"
            tooltipPosition="above"
            [disabled]="!jsonModel()?.valid"
            (click)="beautify()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              wand_stars
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Beautify</span
            >
          </button>
          <ng-content select="[lhsActions]" />
        </span>
        <button
          coreButton
          [disabled]="!this.form().valid"
          (click)="saveForm()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            {{ saveButtonIcon() }}
          </i>
          <span coreButtonLabel>{{ saveButtonLabel() }}</span>
        </button>
      </ng-template>
    </core-dialog>
  `
		}]
	}],
	propDecorators: {
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: true
			}]
		}],
		saveButtonLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "saveButtonLabel",
				required: true
			}]
		}],
		saveButtonIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "saveButtonIcon",
				required: true
			}]
		}],
		formFieldsJson: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formFieldsJson",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["formFieldsJsonChange"]
		}],
		isOpen: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isOpen",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["isOpenChange"]
		}],
		isArrayRoot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isArrayRoot",
				required: false
			}]
		}],
		schema: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "schema",
				required: false
			}]
		}],
		form: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => NgForm), { isSignal: true }]
		}],
		jsonModel: [{
			type: i0.ViewChild,
			args: ["jsonModel", {
				read: NgModel,
				isSignal: true
			}]
		}],
		save: [{
			type: i0.Output,
			args: ["save"]
		}]
	}
});
var FieldPresetDialog = class FieldPresetDialog {
	dialogService = inject(FieldPresetDialogService);
	fieldService = inject(CoreFieldService);
	isOpen = this.dialogService.isOpen;
	data = this.dialogService.data;
	formName = signal("", ...ngDevMode ? [{ debugName: "formName" }] : /* istanbul ignore next */ []);
	formFieldsJSON = signal("", ...ngDevMode ? [{ debugName: "formFieldsJSON" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (this.isOpen()) {
				const data = this.data();
				if (!data) throw new Error("FieldPresetDialog: No data available when dialog is open");
				this.formName.set(data.name);
				this.formFieldsJSON.set(data.json);
			}
		});
	}
	save() {
		if (!this.data()) throw new Error("Unable to save dialog form without data");
		const field = JSON.parse(this.formFieldsJSON());
		this.fieldService.savePreset(this.formName(), field);
		this.dialogService.close();
	}
	updateVisibility(visible) {
		if (!visible) this.dialogService.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldPresetDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldPresetDialog,
		isStandalone: true,
		selector: "core-field-preset-dialog",
		ngImport: i0,
		template: `
    <core-json-content-dialog
      header="Save Field as Preset"
      saveButtonLabel="Save"
      saveButtonIcon="save"
      [isOpen]="isOpen()"
      [(formFieldsJson)]="formFieldsJSON"
      (isOpenChange)="updateVisibility($event)"
      (save)="save()"
    >
      <ng-container formFields>
        <div>
          <div class="core-labeled-control">
            <input
              #nameModel="ngModel"
              class="w-full"
              name="name"
              coreInput
              required
              autocomplete="off"
              data-bwignore
              id="preset-dialog-name-input"
              [(ngModel)]="formName"
            />
            <label for="preset-dialog-name-input">Name</label>
          </div>
          @if (!nameModel.valid && nameModel.touched) {
            <div
              role="alert"
              class="core-message"
              class="mt-1 inline-block"
              severity="error"
              size="small"
              variant="simple"
            >
              Name is required.
            </div>
          }
        </div>
      </ng-container>
    </core-json-content-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: JSONContentDialog,
				selector: "core-json-content-dialog",
				inputs: [
					"header",
					"saveButtonLabel",
					"saveButtonIcon",
					"formFieldsJson",
					"isOpen",
					"isArrayRoot",
					"schema"
				],
				outputs: [
					"formFieldsJsonChange",
					"isOpenChange",
					"save"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldPresetDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-preset-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule, JSONContentDialog],
			template: `
    <core-json-content-dialog
      header="Save Field as Preset"
      saveButtonLabel="Save"
      saveButtonIcon="save"
      [isOpen]="isOpen()"
      [(formFieldsJson)]="formFieldsJSON"
      (isOpenChange)="updateVisibility($event)"
      (save)="save()"
    >
      <ng-container formFields>
        <div>
          <div class="core-labeled-control">
            <input
              #nameModel="ngModel"
              class="w-full"
              name="name"
              coreInput
              required
              autocomplete="off"
              data-bwignore
              id="preset-dialog-name-input"
              [(ngModel)]="formName"
            />
            <label for="preset-dialog-name-input">Name</label>
          </div>
          @if (!nameModel.valid && nameModel.touched) {
            <div
              role="alert"
              class="core-message"
              class="mt-1 inline-block"
              severity="error"
              size="small"
              variant="simple"
            >
              Name is required.
            </div>
          }
        </div>
      </ng-container>
    </core-json-content-dialog>
  `
		}]
	}],
	ctorParameters: () => []
});
var ExportDialog = class ExportDialog {
	dialogService = inject(ExportDialogService);
	formService = inject(CoreFormService);
	isOpen = this.dialogService.isOpen;
	formName = signal("", ...ngDevMode ? [{ debugName: "formName" }] : /* istanbul ignore next */ []);
	formFieldsJSON = signal("", ...ngDevMode ? [{ debugName: "formFieldsJSON" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (this.isOpen()) {
				this.formName.set(this.formService.activeForm()?.name ?? "Form");
				this.formFieldsJSON.set(this.formService.activeFormFieldsJSON());
			}
		});
	}
	updateVisibility(visible) {
		if (!visible) this.dialogService.close();
	}
	exportForm() {
		try {
			const blob = new Blob([this.formFieldsJSON()], { type: "application/json" });
			saveAs(blob, this.formName());
			this.dialogService.close();
		} catch {
			return;
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExportDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ExportDialog,
		isStandalone: true,
		selector: "core-export-dialog",
		ngImport: i0,
		template: `
    <core-json-content-dialog
      header="Export Form"
      saveButtonLabel="Export Form"
      saveButtonIcon="download"
      [isArrayRoot]="true"
      [isOpen]="isOpen()"
      [(formFieldsJson)]="formFieldsJSON"
      (isOpenChange)="updateVisibility($event)"
      (save)="exportForm()"
    >
      <ng-container formFields>
        <div>
          <div class="core-labeled-control">
            <input
              #nameModel="ngModel"
              class="w-full"
              name="name"
              coreInput
              required
              autocomplete="off"
              data-bwignore
              id="export-dialog-name-input"
              [(ngModel)]="formName"
            />
            <label for="export-dialog-name-input">Name</label>
          </div>
          @if (!nameModel.valid && nameModel.touched) {
            <div
              role="alert"
              class="core-message"
              class="mt-1 inline-block"
              severity="error"
              size="small"
              variant="simple"
            >
              Name is required.
            </div>
          }
        </div>
      </ng-container>
    </core-json-content-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: JSONContentDialog,
				selector: "core-json-content-dialog",
				inputs: [
					"header",
					"saveButtonLabel",
					"saveButtonIcon",
					"formFieldsJson",
					"isOpen",
					"isArrayRoot",
					"schema"
				],
				outputs: [
					"formFieldsJsonChange",
					"isOpenChange",
					"save"
				]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExportDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-export-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [JSONContentDialog, FormsModule],
			template: `
    <core-json-content-dialog
      header="Export Form"
      saveButtonLabel="Export Form"
      saveButtonIcon="download"
      [isArrayRoot]="true"
      [isOpen]="isOpen()"
      [(formFieldsJson)]="formFieldsJSON"
      (isOpenChange)="updateVisibility($event)"
      (save)="exportForm()"
    >
      <ng-container formFields>
        <div>
          <div class="core-labeled-control">
            <input
              #nameModel="ngModel"
              class="w-full"
              name="name"
              coreInput
              required
              autocomplete="off"
              data-bwignore
              id="export-dialog-name-input"
              [(ngModel)]="formName"
            />
            <label for="export-dialog-name-input">Name</label>
          </div>
          @if (!nameModel.valid && nameModel.touched) {
            <div
              role="alert"
              class="core-message"
              class="mt-1 inline-block"
              severity="error"
              size="small"
              variant="simple"
            >
              Name is required.
            </div>
          }
        </div>
      </ng-container>
    </core-json-content-dialog>
  `
		}]
	}],
	ctorParameters: () => []
});
var FormPreviewDialog = class FormPreviewDialog {
	previewContent = viewChild(FormPreviewContent, ...ngDevMode ? [{ debugName: "previewContent" }] : /* istanbul ignore next */ []);
	dialogService = inject(PreviewDialogService);
	formService = inject(CoreFormService);
	isOpen = this.dialogService.isOpen;
	activePreviewFormFields = this.formService.activePreviewFormFields;
	pt = { header: { class: "grid grid-cols-[1fr_auto] gap-x-4 gap-y-2 lg:grid-cols-[1fr_auto_1fr]" } };
	updateVisibility(visible) {
		if (!visible) this.dialogService.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormPreviewDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormPreviewDialog,
		isStandalone: true,
		selector: "core-form-preview-dialog",
		viewQueries: [{
			propertyName: "previewContent",
			first: true,
			predicate: FormPreviewContent,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-dialog
      header="Form Preview"
      [style]="{ width: 'calc(100vw - 32px)', height: 'calc(100dvh - 32px)' }"
      [pt]="pt"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      <ng-template
        #header
        let-titleId="ariaLabelledBy"
      >
        <span
          class="core-dialog-title"
          [id]="titleId"
          >Form Preview</span
        >
        <core-preview-device-toolbar
          class="col-span-2 row-start-2 lg:col-span-1 lg:col-start-2 lg:row-start-1"
          [scale]="previewContent()?.scale() ?? 1"
        />
      </ng-template>
      @if (isOpen()) {
        <core-form-preview-content [formFields]="activePreviewFormFields()" />
      }
    </core-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "component",
				type: FormPreviewContent,
				selector: "core-form-preview-content",
				inputs: ["formFields"]
			},
			{
				kind: "component",
				type: PreviewDeviceToolbar,
				selector: "core-preview-device-toolbar",
				inputs: ["scale"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormPreviewDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-preview-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Dialog,
				FormPreviewContent,
				PreviewDeviceToolbar
			],
			template: `
    <core-dialog
      header="Form Preview"
      [style]="{ width: 'calc(100vw - 32px)', height: 'calc(100dvh - 32px)' }"
      [pt]="pt"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      <ng-template
        #header
        let-titleId="ariaLabelledBy"
      >
        <span
          class="core-dialog-title"
          [id]="titleId"
          >Form Preview</span
        >
        <core-preview-device-toolbar
          class="col-span-2 row-start-2 lg:col-span-1 lg:col-start-2 lg:row-start-1"
          [scale]="previewContent()?.scale() ?? 1"
        />
      </ng-template>
      @if (isOpen()) {
        <core-form-preview-content [formFields]="activePreviewFormFields()" />
      }
    </core-dialog>
  `
		}]
	}],
	propDecorators: { previewContent: [{
		type: i0.ViewChild,
		args: [i0.forwardRef(() => FormPreviewContent), { isSignal: true }]
	}] }
});
const BLANK_TEMPLATE_ID = "blank";
const STORAGE_RECOVERY_MESSAGE = "Recover saved data in the Workspace panel before creating a form.";
var CreateFormDialog = class CreateFormDialog {
	onDialogOpened(select) {
		if (this.libraryOptions.length) {
			select.focus();
			select.open();
		}
	}
	form = viewChild.required("form", {
		...ngDevMode ? { debugName: "form" } : /* istanbul ignore next */ {},
		read: NgForm
	});
	dialogService = inject(CreateFormDialogService);
	libraryService = inject(CoreLibraryService);
	formService = inject(CoreFormService);
	configuredTemplates = inject(CORE_FORM_TEMPLATES, { optional: true }) ?? this.libraryService.formTemplates;
	nameInputId = "create-form-name";
	selectedLibraryInputId = "create-form-selected-library";
	libraryOptions = this.libraryService.libraryOptions;
	formName = signal("", ...ngDevMode ? [{ debugName: "formName" }] : /* istanbul ignore next */ []);
	selectedLibrary = signal(null, ...ngDevMode ? [{ debugName: "selectedLibrary" }] : /* istanbul ignore next */ []);
	isCreating = signal(false, ...ngDevMode ? [{ debugName: "isCreating" }] : /* istanbul ignore next */ []);
	isDraggingFile = signal(false, ...ngDevMode ? [{ debugName: "isDraggingFile" }] : /* istanbul ignore next */ []);
	fileReader = null;
	creationError = signal("", ...ngDevMode ? [{ debugName: "creationError" }] : /* istanbul ignore next */ []);
	errorMessage = computed(() => this.formService.hasStorageRecoveryIssues() ? STORAGE_RECOVERY_MESSAGE : this.creationError(), ...ngDevMode ? [{ debugName: "errorMessage" }] : /* istanbul ignore next */ []);
	templates = [{
		id: BLANK_TEMPLATE_ID,
		name: "Blank Form",
		description: "Start from scratch with an empty canvas and build your structure manually.",
		icon: "note_add",
		fields: [],
		model: {}
	}, ...this.configuredTemplates.map((template) => ({
		id: template.id || (template.libraryId ? `${template.name}-${template.libraryId}` : template.name),
		name: template.name,
		description: template.description ?? "",
		icon: template.icon ?? "description",
		fields: template.fields,
		model: template.model,
		libraryId: template.libraryId
	}))];
	quickStartTemplates = this.templates.slice(1);
	constructor() {
		inject(DestroyRef).onDestroy(() => this.dialogService.close());
		effect(() => {
			if (!this.dialogService.isOpen()) this.reset();
		});
	}
	reset() {
		if (this.fileReader) {
			this.fileReader.abort();
			this.fileReader = null;
			this.isCreating.set(false);
		}
		this.isDraggingFile.set(false);
		this.creationError.set("");
		this.formName.set("");
		this.selectedLibrary.set(null);
		this.form().resetForm({
			name: this.formName(),
			formlyUI: null
		});
	}
	onVisibilityChange(visible) {
		if (!visible) this.dialogService.close();
	}
	onFileDragOver(event) {
		if (!event.dataTransfer?.types.includes("Files") || !this.canCreate()) return;
		event.preventDefault();
		event.dataTransfer.dropEffect = "copy";
		this.isDraggingFile.set(true);
	}
	onFileDragLeave(event) {
		if (!event.currentTarget.contains(event.relatedTarget)) this.isDraggingFile.set(false);
	}
	onFileDrop(event) {
		event.preventDefault();
		event.stopPropagation();
		this.isDraggingFile.set(false);
		this.importFiles(event.dataTransfer?.files);
	}
	importFiles(files) {
		if (!this.canCreate()) return;
		if (!files?.length) return;
		const file = files[0];
		if (files.length !== 1 || !/\.(json|txt)$/i.test(file.name)) {
			this.creationError.set("Choose or drop one JSON or TXT form file at a time.");
			return;
		}
		const name = this.formName().trim() || file.name.replace(/\.(json|txt)$/i, "") || "New form";
		const libraryId = this.selectedLibrary() ?? "form-vanilla";
		const library = this.libraryService.getLibrary(libraryId);
		const reader = new FileReader();
		this.fileReader = reader;
		this.creationError.set("");
		this.isCreating.set(true);
		reader.onload = () => {
			this.fileReader = null;
			this.isCreating.set(false);
			if (!this.canCreate()) return;
			let fields;
			try {
				fields = JSON.parse(reader.result);
			} catch {
				this.creationError.set("Could not read the form. Use a valid JSON field array.");
				return;
			}
			if (!Array.isArray(fields) || fields.some((field) => !field || typeof field !== "object" || Array.isArray(field))) {
				this.creationError.set("The form must contain a JSON array of field objects.");
				return;
			}
			if (library?.enableFormUploadSchema && !library.schema?.safeParse(fields).success) {
				this.creationError.set("The form does not match the selected UI library. Check the file or choose another library.");
				return;
			}
			this.saveForm(name, fields, {}, libraryId);
		};
		reader.onerror = () => {
			this.fileReader = null;
			this.isCreating.set(false);
			this.creationError.set("Could not read the file. Please try again.");
		};
		reader.readAsText(file);
	}
	canCreate() {
		return this.dialogService.isOpen() && !this.isCreating() && !this.formService.hasStorageRecoveryIssues() && !!this.form().valid;
	}
	createForm(templateId = BLANK_TEMPLATE_ID) {
		if (!this.dialogService.isOpen() || this.isCreating() || this.formService.hasStorageRecoveryIssues()) return;
		if (!this.form().valid) {
			this.form().form.markAllAsTouched();
			return;
		}
		const template = this.templates.find((t) => t.id === templateId);
		if (!template) return;
		const name = this.formName().trim() || (templateId === BLANK_TEMPLATE_ID ? "New form" : template.name);
		const libraryId = template.libraryId ?? this.selectedLibrary() ?? "form-vanilla";
		this.saveForm(name, template.fields, template.model, libraryId);
	}
	saveForm(name, fields, model, libraryId) {
		this.creationError.set("");
		this.isCreating.set(true);
		defer(() => this.formService.addForm$(name, fields, model, libraryId, true, this.dialogService.parentId())).pipe(finalize(() => this.isCreating.set(false))).subscribe({
			next: () => this.dialogService.close(),
			error: (error) => this.creationError.set(error instanceof FormStoreRecoveryRequiredError ? STORAGE_RECOVERY_MESSAGE : "Could not create the form. Please try again.")
		});
	}
	close() {
		this.dialogService.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CreateFormDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CreateFormDialog,
		isStandalone: true,
		selector: "core-create-form-dialog",
		viewQueries: [{
			propertyName: "form",
			first: true,
			predicate: ["form"],
			descendants: true,
			read: NgForm,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-dialog
      header="Create Form"
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        maxHeight: 'calc(100dvh - 32px)',
      }"
      [visible]="dialogService.isOpen()"
      [focusOnShow]="libraryOptions.length === 0"
      (opened)="onDialogOpened(librarySelect)"
      (visibleChange)="onVisibilityChange($event)"
    >
      <form
        #form="ngForm"
        class="flex flex-col gap-6"
      >
        @if (errorMessage()) {
          <div
            role="alert"
            class="core-message"
            severity="error"
          >
            {{ errorMessage() }}
          </div>
        }
        <div class="grid w-full shrink-0 grid-cols-1 items-start gap-4 py-2 sm:grid-cols-2">
          <div class="min-w-0">
            <div class="core-labeled-control">
              <input
                class="w-full"
                name="name"
                coreInput
                autocomplete="off"
                data-bwignore
                [id]="nameInputId"
                [ngModel]="formName()"
                (ngModelChange)="formName.set($event)"
              />
              <label [for]="nameInputId">Name</label>
            </div>
          </div>
          <div class="min-w-0">
            <div class="core-labeled-control">
              <mat-select
                #librarySelect
                class="w-full"
                name="formlyUI"
                aria-label="UI Library"
                [id]="selectedLibraryInputId"
                [ngModel]="selectedLibrary()"
                [attr.aria-describedby]="'create-form-library-help'"
                (ngModelChange)="selectedLibrary.set($event)"
                ><mat-option [value]="null">None (Vanilla)</mat-option>
                @for (option of libraryOptions; track $index) {
                  <mat-option [value]="option.id">{{ option.label }}</mat-option>
                }
              </mat-select>
              <label [for]="selectedLibraryInputId">UI Library</label>
            </div>
            <small
              class="mt-1 block text-muted-color"
              id="create-form-library-help"
            >
              Leave empty for Vanilla (native HTML controls).
            </small>
          </div>
        </div>

        <div
          class="grid grid-cols-1 gap-4"
          role="group"
          aria-label="Starting point"
          [class.sm:grid-cols-2]="quickStartTemplates.length > 0"
        >
          <div
            class="relative"
            (dragenter)="onFileDragOver($event)"
            (dragover)="onFileDragOver($event)"
            (dragleave)="onFileDragLeave($event)"
            (drop)="onFileDrop($event)"
          >
            <button
              class="flex h-full min-h-44 w-full cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed px-6 pt-16 pb-6 text-center transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary enabled:hover:border-primary enabled:hover:bg-emphasis disabled:cursor-not-allowed disabled:opacity-50 sm:min-h-72 sm:p-6"
              type="button"
              id="template-blank"
              aria-label="Start with a blank form"
              aria-describedby="blank-form-description"
              [class.border-primary]="isDraggingFile()"
              [class.border-surface]="!isDraggingFile()"
              [disabled]="!form.valid || isCreating() || formService.hasStorageRecoveryIssues()"
              (click)="createForm()"
            >
              <i
                class="material-symbols-outlined text-4xl!"
                aria-hidden="true"
                >{{ isDraggingFile() ? 'download' : 'draft' }}</i
              >
              <span class="text-lg font-semibold">Start with a blank form</span>
              <span
                class="text-sm text-muted-color"
                id="blank-form-description"
                >Build from scratch, or drop a JSON form file here.</span
              >
            </button>
            <button
              class="absolute top-2 right-2 h-11 w-11"
              coreButton
              text
              type="button"
              severity="secondary"
              aria-label="Import form file"
              coreTooltip="Import form file"
              tooltipPosition="above"
              [disabled]="!form.valid || isCreating() || formService.hasStorageRecoveryIssues()"
              (click)="fileSelect.click()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                aria-hidden="true"
                >upload</i
              >
            </button>
            <input
              #fileSelect
              class="hidden"
              type="file"
              accept=".json,.txt"
              (change)="importFiles(fileSelect.files); fileSelect.value = ''"
            />
          </div>

          @if (quickStartTemplates.length > 0) {
            <section
              class="min-w-0 rounded-xl border border-surface p-5 sm:p-6"
              aria-labelledby="quick-start-heading"
            >
              <h2
                class="m-0 text-center text-lg font-semibold"
                id="quick-start-heading"
              >
                Quick Start
              </h2>
              <p class="mt-2 mb-5 text-center text-sm text-muted-color">
                Choose an example to get started quickly.
              </p>
              <div class="flex flex-col gap-3">
                @for (template of quickStartTemplates; track template.id) {
                  <button
                    class="flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border border-surface px-3 py-2 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary enabled:hover:border-primary enabled:hover:bg-emphasis disabled:cursor-not-allowed disabled:opacity-50"
                    type="button"
                    [id]="'template-' + template.id"
                    [attr.aria-label]="template.name"
                    [attr.aria-describedby]="'template-description-' + $index"
                    [disabled]="
                      !form.valid || isCreating() || formService.hasStorageRecoveryIssues()
                    "
                    (click)="createForm(template.id)"
                  >
                    <i
                      class="material-symbols-outlined shrink-0 text-lg!"
                      aria-hidden="true"
                      >{{ template.icon }}</i
                    >
                    <span class="min-w-0 flex-1 text-sm font-medium">{{ template.name }}</span>
                    <span
                      class="sr-only"
                      [id]="'template-description-' + $index"
                      >{{ template.description }}</span
                    >
                    <i
                      class="material-symbols-outlined shrink-0 text-lg!"
                      aria-hidden="true"
                      >chevron_right</i
                    >
                  </button>
                }
              </div>
            </section>
          }
        </div>
      </form>
    </core-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "component",
				type: MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CreateFormDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-create-form-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Dialog,
				FormsModule,
				MatSelect,
				MatOption,
				Tooltip
			],
			template: `
    <core-dialog
      header="Create Form"
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        maxHeight: 'calc(100dvh - 32px)',
      }"
      [visible]="dialogService.isOpen()"
      [focusOnShow]="libraryOptions.length === 0"
      (opened)="onDialogOpened(librarySelect)"
      (visibleChange)="onVisibilityChange($event)"
    >
      <form
        #form="ngForm"
        class="flex flex-col gap-6"
      >
        @if (errorMessage()) {
          <div
            role="alert"
            class="core-message"
            severity="error"
          >
            {{ errorMessage() }}
          </div>
        }
        <div class="grid w-full shrink-0 grid-cols-1 items-start gap-4 py-2 sm:grid-cols-2">
          <div class="min-w-0">
            <div class="core-labeled-control">
              <input
                class="w-full"
                name="name"
                coreInput
                autocomplete="off"
                data-bwignore
                [id]="nameInputId"
                [ngModel]="formName()"
                (ngModelChange)="formName.set($event)"
              />
              <label [for]="nameInputId">Name</label>
            </div>
          </div>
          <div class="min-w-0">
            <div class="core-labeled-control">
              <mat-select
                #librarySelect
                class="w-full"
                name="formlyUI"
                aria-label="UI Library"
                [id]="selectedLibraryInputId"
                [ngModel]="selectedLibrary()"
                [attr.aria-describedby]="'create-form-library-help'"
                (ngModelChange)="selectedLibrary.set($event)"
                ><mat-option [value]="null">None (Vanilla)</mat-option>
                @for (option of libraryOptions; track $index) {
                  <mat-option [value]="option.id">{{ option.label }}</mat-option>
                }
              </mat-select>
              <label [for]="selectedLibraryInputId">UI Library</label>
            </div>
            <small
              class="mt-1 block text-muted-color"
              id="create-form-library-help"
            >
              Leave empty for Vanilla (native HTML controls).
            </small>
          </div>
        </div>

        <div
          class="grid grid-cols-1 gap-4"
          role="group"
          aria-label="Starting point"
          [class.sm:grid-cols-2]="quickStartTemplates.length > 0"
        >
          <div
            class="relative"
            (dragenter)="onFileDragOver($event)"
            (dragover)="onFileDragOver($event)"
            (dragleave)="onFileDragLeave($event)"
            (drop)="onFileDrop($event)"
          >
            <button
              class="flex h-full min-h-44 w-full cursor-pointer flex-col items-center justify-center gap-3 rounded-xl border-2 border-dashed px-6 pt-16 pb-6 text-center transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary enabled:hover:border-primary enabled:hover:bg-emphasis disabled:cursor-not-allowed disabled:opacity-50 sm:min-h-72 sm:p-6"
              type="button"
              id="template-blank"
              aria-label="Start with a blank form"
              aria-describedby="blank-form-description"
              [class.border-primary]="isDraggingFile()"
              [class.border-surface]="!isDraggingFile()"
              [disabled]="!form.valid || isCreating() || formService.hasStorageRecoveryIssues()"
              (click)="createForm()"
            >
              <i
                class="material-symbols-outlined text-4xl!"
                aria-hidden="true"
                >{{ isDraggingFile() ? 'download' : 'draft' }}</i
              >
              <span class="text-lg font-semibold">Start with a blank form</span>
              <span
                class="text-sm text-muted-color"
                id="blank-form-description"
                >Build from scratch, or drop a JSON form file here.</span
              >
            </button>
            <button
              class="absolute top-2 right-2 h-11 w-11"
              coreButton
              text
              type="button"
              severity="secondary"
              aria-label="Import form file"
              coreTooltip="Import form file"
              tooltipPosition="above"
              [disabled]="!form.valid || isCreating() || formService.hasStorageRecoveryIssues()"
              (click)="fileSelect.click()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                aria-hidden="true"
                >upload</i
              >
            </button>
            <input
              #fileSelect
              class="hidden"
              type="file"
              accept=".json,.txt"
              (change)="importFiles(fileSelect.files); fileSelect.value = ''"
            />
          </div>

          @if (quickStartTemplates.length > 0) {
            <section
              class="min-w-0 rounded-xl border border-surface p-5 sm:p-6"
              aria-labelledby="quick-start-heading"
            >
              <h2
                class="m-0 text-center text-lg font-semibold"
                id="quick-start-heading"
              >
                Quick Start
              </h2>
              <p class="mt-2 mb-5 text-center text-sm text-muted-color">
                Choose an example to get started quickly.
              </p>
              <div class="flex flex-col gap-3">
                @for (template of quickStartTemplates; track template.id) {
                  <button
                    class="flex min-h-11 cursor-pointer items-center gap-3 rounded-lg border border-surface px-3 py-2 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary enabled:hover:border-primary enabled:hover:bg-emphasis disabled:cursor-not-allowed disabled:opacity-50"
                    type="button"
                    [id]="'template-' + template.id"
                    [attr.aria-label]="template.name"
                    [attr.aria-describedby]="'template-description-' + $index"
                    [disabled]="
                      !form.valid || isCreating() || formService.hasStorageRecoveryIssues()
                    "
                    (click)="createForm(template.id)"
                  >
                    <i
                      class="material-symbols-outlined shrink-0 text-lg!"
                      aria-hidden="true"
                      >{{ template.icon }}</i
                    >
                    <span class="min-w-0 flex-1 text-sm font-medium">{{ template.name }}</span>
                    <span
                      class="sr-only"
                      [id]="'template-description-' + $index"
                      >{{ template.description }}</span
                    >
                    <i
                      class="material-symbols-outlined shrink-0 text-lg!"
                      aria-hidden="true"
                      >chevron_right</i
                    >
                  </button>
                }
              </div>
            </section>
          }
        </div>
      </form>
    </core-dialog>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { form: [{
		type: i0.ViewChild,
		args: ["form", {
			read: NgForm,
			isSignal: true
		}]
	}] }
});
var ImportDialog = class ImportDialog {
	fileSelectElement = viewChild.required("fileSelect", ...ngDevMode ? [{ debugName: "fileSelectElement" }] : /* istanbul ignore next */ []);
	dialogService = inject(ImportDialogService);
	formService = inject(CoreFormService);
	libraryService = inject(CoreLibraryService);
	isOpen = this.dialogService.isOpen;
	selectedLibraryInputId = "import-form-selected-library";
	libraryOptions = this.libraryService.libraryOptions;
	schema = computed(() => {
		const selectedLibrary = this.libraryService.getLibrary(this.selectedLibraryId() ?? "form-vanilla");
		return selectedLibrary?.enableFormUploadSchema ? selectedLibrary.schema : void 0;
	}, ...ngDevMode ? [{ debugName: "schema" }] : /* istanbul ignore next */ []);
	formName = signal("", ...ngDevMode ? [{ debugName: "formName" }] : /* istanbul ignore next */ []);
	formFieldsJSON = signal("", ...ngDevMode ? [{ debugName: "formFieldsJSON" }] : /* istanbul ignore next */ []);
	selectedLibraryId = signal(null, ...ngDevMode ? [{ debugName: "selectedLibraryId" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (this.isOpen()) {
				this.formName.set("New Form");
				this.formFieldsJSON.set("[]");
				this.selectedLibraryId.set(null);
			}
		});
	}
	updateVisibility(visible) {
		if (!visible) this.dialogService.close();
	}
	loadFromFile() {
		const file = this.fileSelectElement().nativeElement.files?.item(0) ?? null;
		if (!file) return;
		const reader = new FileReader();
		reader.onload = (readerEvent) => {
			const content = readerEvent.target?.result;
			if (content) this.formFieldsJSON.set(content);
		};
		reader.readAsText(file);
	}
	importForm() {
		let formFields;
		try {
			formFields = JSON.parse(this.formFieldsJSON());
		} catch {
			return;
		}
		if (!Array.isArray(formFields)) return;
		this.formService.addForm$(this.formName(), formFields, {}, this.selectedLibraryId() ?? "form-vanilla", true, null).subscribe({
			next: () => {
				const activeFormId = this.formService.activeFormId();
				if (activeFormId) this.dialogService.notifyImported(activeFormId);
				this.dialogService.close();
			},
			error: () => void 0
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ImportDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ImportDialog,
		isStandalone: true,
		selector: "core-import-dialog",
		viewQueries: [{
			propertyName: "fileSelectElement",
			first: true,
			predicate: ["fileSelect"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-json-content-dialog
      class="text-base"
      header="Import Form"
      saveButtonLabel="Import Form"
      saveButtonIcon="upload"
      [isArrayRoot]="true"
      [schema]="schema()"
      [isOpen]="isOpen()"
      [(formFieldsJson)]="formFieldsJSON"
      (isOpenChange)="updateVisibility($event)"
      (save)="importForm()"
    >
      <ng-container formFields>
        <div>
          <div class="core-labeled-control">
            <input
              #nameModel="ngModel"
              class="w-full"
              name="name"
              coreInput
              required
              autocomplete="off"
              data-bwignore
              id="import-dialog-name-input"
              [(ngModel)]="formName"
            />
            <label for="import-dialog-name-input">Name</label>
          </div>
          @if (!nameModel.valid && nameModel.touched) {
            <div
              role="alert"
              class="core-message"
              class="mt-1 inline-block"
              severity="error"
              size="small"
              variant="simple"
            >
              Name is required.
            </div>
          }
        </div>
        <div>
          <div class="core-labeled-control">
            <mat-select
              class="w-full"
              name="formlyUI"
              aria-label="UI Library"
              [id]="selectedLibraryInputId"
              [attr.aria-describedby]="'import-form-library-help'"
              [(ngModel)]="selectedLibraryId"
              ><mat-option [value]="null">None (Vanilla)</mat-option>
              @for (option of libraryOptions; track $index) {
                <mat-option [value]="option.id">{{ option.label }}</mat-option>
              }
            </mat-select>
            <label [for]="selectedLibraryInputId">UI Library</label>
          </div>
          <small
            class="mt-1 block text-muted-color"
            id="import-form-library-help"
          >
            Leave empty for Vanilla (native HTML controls).
          </small>
        </div>
      </ng-container>
      <ng-container lhsActions>
        <span>
          <button
            coreButton
            text
            (click)="fileSelect.click()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              file_open
            </i>
            <span coreButtonLabel>Choose File</span>
          </button>
          <input
            #fileSelect
            class="hidden"
            type="file"
            accept=".json, .txt"
            (input)="loadFromFile()"
          />
        </span>
      </ng-container>
    </core-json-content-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: JSONContentDialog,
				selector: "core-json-content-dialog",
				inputs: [
					"header",
					"saveButtonLabel",
					"saveButtonIcon",
					"formFieldsJson",
					"isOpen",
					"isArrayRoot",
					"schema"
				],
				outputs: [
					"formFieldsJsonChange",
					"isOpenChange",
					"save"
				]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.RequiredValidator,
				selector: ":not([type=checkbox])[required][formControlName],:not([type=checkbox])[required][formControl],:not([type=checkbox])[required][ngModel]",
				inputs: ["required"]
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ImportDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-import-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				JSONContentDialog,
				FormsModule,
				MatSelect,
				MatOption
			],
			template: `
    <core-json-content-dialog
      class="text-base"
      header="Import Form"
      saveButtonLabel="Import Form"
      saveButtonIcon="upload"
      [isArrayRoot]="true"
      [schema]="schema()"
      [isOpen]="isOpen()"
      [(formFieldsJson)]="formFieldsJSON"
      (isOpenChange)="updateVisibility($event)"
      (save)="importForm()"
    >
      <ng-container formFields>
        <div>
          <div class="core-labeled-control">
            <input
              #nameModel="ngModel"
              class="w-full"
              name="name"
              coreInput
              required
              autocomplete="off"
              data-bwignore
              id="import-dialog-name-input"
              [(ngModel)]="formName"
            />
            <label for="import-dialog-name-input">Name</label>
          </div>
          @if (!nameModel.valid && nameModel.touched) {
            <div
              role="alert"
              class="core-message"
              class="mt-1 inline-block"
              severity="error"
              size="small"
              variant="simple"
            >
              Name is required.
            </div>
          }
        </div>
        <div>
          <div class="core-labeled-control">
            <mat-select
              class="w-full"
              name="formlyUI"
              aria-label="UI Library"
              [id]="selectedLibraryInputId"
              [attr.aria-describedby]="'import-form-library-help'"
              [(ngModel)]="selectedLibraryId"
              ><mat-option [value]="null">None (Vanilla)</mat-option>
              @for (option of libraryOptions; track $index) {
                <mat-option [value]="option.id">{{ option.label }}</mat-option>
              }
            </mat-select>
            <label [for]="selectedLibraryInputId">UI Library</label>
          </div>
          <small
            class="mt-1 block text-muted-color"
            id="import-form-library-help"
          >
            Leave empty for Vanilla (native HTML controls).
          </small>
        </div>
      </ng-container>
      <ng-container lhsActions>
        <span>
          <button
            coreButton
            text
            (click)="fileSelect.click()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              file_open
            </i>
            <span coreButtonLabel>Choose File</span>
          </button>
          <input
            #fileSelect
            class="hidden"
            type="file"
            accept=".json, .txt"
            (input)="loadFromFile()"
          />
        </span>
      </ng-container>
    </core-json-content-dialog>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { fileSelectElement: [{
		type: i0.ViewChild,
		args: ["fileSelect", { isSignal: true }]
	}] }
});
var FieldTableDialog = class FieldTableDialog {
	dialogService = inject(ArrayTableDialogService);
	nextRowId = 0;
	data = this.dialogService.data;
	isOpen = this.dialogService.isOpen;
	workingRows = signal([], ...ngDevMode ? [{ debugName: "workingRows" }] : /* istanbul ignore next */ []);
	propertyType = PropertyType;
	dialogPT = {
		header: { style: { height: "5rem" } },
		content: { style: { height: "calc(100% - 10rem)" } },
		footer: { style: {
			height: "5rem",
			alignItems: "center",
			justifyContent: "space-between"
		} }
	};
	displayRows = computed(() => [...this.workingRows()], ...ngDevMode ? [{ debugName: "displayRows" }] : /* istanbul ignore next */ []);
	columns = computed(() => (this.data()?.childProperties ?? []).map((property) => ({
		key: property.key,
		label: property.label ?? property.key ?? "",
		property
	})), ...ngDevMode ? [{ debugName: "columns" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (!this.isOpen()) return;
			const data = this.data();
			if (!data) return;
			this.nextRowId = 0;
			this.workingRows.set(data.rows.map((value) => ({
				id: `table-row-${++this.nextRowId}`,
				value: structuredClone(value)
			})));
		});
	}
	getValue(row, column) {
		const cellValue = get(row.value, column.key);
		switch (column.property.type) {
			case PropertyType.INPUT: return typeof cellValue === "string" || typeof cellValue === "number" ? cellValue : null;
			case PropertyType.BOOLEAN: return typeof cellValue === "boolean" ? cellValue : null;
			case PropertyType.SELECT: return typeof cellValue === "string" || typeof cellValue === "number" ? cellValue : null;
		}
		return null;
	}
	getSelectOptions(column) {
		return column.property.options;
	}
	updateCell(row, column, value) {
		const changeType = this.getChangeType(column.property, value);
		const currentValue = (this.workingRows().find((current) => current.id === row.id) ?? row).value;
		const updatedValue = changeType === PropertyChangeType.CLEAR ? modifyPropertyTarget(currentValue, {
			type: PropertyChangeType.CLEAR,
			path: column.key.split(".")
		}) : modifyPropertyTarget(currentValue, {
			type: PropertyChangeType.VALUE,
			path: column.key.split("."),
			value
		});
		this.updateRow(row.id, updatedValue);
	}
	onRowReorder(event) {
		const { dragIndex, dropIndex } = event;
		if (dragIndex === void 0 || dropIndex === void 0) return;
		this.workingRows.update((rows) => {
			const reorderedRows = [...rows];
			const [row] = reorderedRows.splice(dragIndex, 1);
			if (row) reorderedRows.splice(dropIndex, 0, row);
			return reorderedRows;
		});
	}
	addRow() {
		if (!this.data()?.canAdd) return;
		this.workingRows.update((rows) => [...rows, {
			id: `table-row-${++this.nextRowId}`,
			value: this.createEmptyRow()
		}]);
	}
	removeRow(row) {
		if (!this.data()?.canRemove) return;
		this.workingRows.update((rows) => rows.filter((current) => current.id !== row.id));
	}
	save() {
		const data = this.data();
		if (!data) return;
		data.saveCallback(this.workingRows().map(({ value }) => structuredClone(value)));
		this.dialogService.close();
	}
	cancel() {
		this.dialogService.close();
	}
	updateVisibility(visible) {
		if (!visible) this.cancel();
	}
	updateRow(id, value) {
		this.workingRows.update((rows) => rows.map((row) => row.id === id ? {
			...row,
			value
		} : row));
	}
	createEmptyRow() {
		let value = {};
		for (const property of this.data()?.childProperties ?? []) {
			if (property.key === void 0) continue;
			const defaultValue = this.getDefaultValue(property);
			value = modifyPropertyTarget(value, {
				type: PropertyChangeType.VALUE,
				path: property.key.split("."),
				value: defaultValue
			});
		}
		return value;
	}
	getDefaultValue(property) {
		const inputDataType = property.dataType;
		const dataType = inputDataType ? inputDataType === "number" ? "number" : "text" : void 0;
		return getDefaultPropertyValue(property.type, dataType);
	}
	getChangeType(property, value) {
		const { clearOnEmpty, clearOnFalse } = property;
		return (clearOnEmpty || clearOnFalse) && typeof value !== "number" && !value ? PropertyChangeType.CLEAR : PropertyChangeType.VALUE;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldTableDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldTableDialog,
		isStandalone: true,
		selector: "core-field-table-dialog",
		ngImport: i0,
		template: `
    <core-dialog
      [pt]="dialogPT"
      [header]="data()?.title || 'Edit items'"
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      <div class="min-h-0 overflow-auto">
        <table class="core-data-table">
          <thead>
            <tr>
              <th
                class="w-12"
                aria-label="Reorder"
              ></th>
              @for (column of columns(); track column.key) {
                <th>{{ column.label }}</th>
              }
              <th class="w-32">Actions</th>
            </tr>
          </thead>
          <tbody
            cdkDropList
            (cdkDropListDropped)="
              onRowReorder({ dragIndex: $event.previousIndex, dropIndex: $event.currentIndex })
            "
          >
            @for (row of displayRows(); track row.id; let rowIndex = $index) {
              <tr cdkDrag>
                <td>
                  <button
                    coreButton
                    text
                    type="button"
                    aria-label="Move row up"
                    [disabled]="rowIndex === 0"
                    (click)="onRowReorder({ dragIndex: rowIndex, dropIndex: rowIndex - 1 })"
                  >
                    <i
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >arrow_upward</i
                    >
                  </button>
                  <button
                    coreButton
                    text
                    type="button"
                    aria-label="Move row down"
                    [disabled]="rowIndex === $count - 1"
                    (click)="onRowReorder({ dragIndex: rowIndex, dropIndex: rowIndex + 1 })"
                  >
                    <i
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >arrow_downward</i
                    >
                  </button>
                  <span
                    cdkDragHandle
                    class="material-symbols-outlined"
                    aria-label="Reorder row"
                    coreTooltip="Reorder row"
                    tooltipPosition="above"
                    >drag_indicator</span
                  >
                </td>
                @for (column of columns(); track column.key) {
                  <td>
                    @switch (column.property.type) {
                      @case (propertyType.INPUT) {
                        <input
                          coreInput
                          class="w-full"
                          [type]="column.property.dataType"
                          [attr.aria-label]="column.label"
                          [ngModel]="getValue(row, column)"
                          (ngModelChange)="updateCell(row, column, $event)"
                        />
                      }
                      @case (propertyType.BOOLEAN) {
                        <mat-slide-toggle
                          [aria-label]="column.label"
                          [ngModel]="getValue(row, column)"
                          (ngModelChange)="updateCell(row, column, $event)"
                        />
                      }
                      @case (propertyType.SELECT) {
                        <mat-select
                          class="w-full"
                          [aria-label]="column.label"
                          [ngModel]="getValue(row, column)"
                          (ngModelChange)="updateCell(row, column, $event)"
                        >
                          @for (option of getSelectOptions(column); track $index) {
                            <mat-option [value]="option.value">{{ option.label }}</mat-option>
                          }
                        </mat-select>
                      }
                    }
                  </td>
                }
                <td>
                  <div class="flex items-center justify-center gap-1">
                    @if (data()?.canRemove) {
                      <button
                        coreButton
                        text
                        rounded
                        severity="danger"
                        type="button"
                        aria-label="Delete row"
                        coreTooltip="Delete row"
                        tooltipPosition="above"
                        (click)="removeRow(row)"
                      >
                        <i
                          coreButtonIcon
                          class="material-symbols-outlined"
                          >delete</i
                        >
                      </button>
                    }
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <ng-template #footer>
        <span>
          @if (data()?.canAdd) {
            <button
              coreButton
              text
              aria-label="Add item"
              coreTooltip="Add item"
              tooltipPosition="above"
              (click)="addRow()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >add</i
              >
              <span coreButtonLabel>Add item</span>
            </button>
          }
        </span>
        <button
          coreButton
          type="button"
          (click)="save()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >save</i
          >
          <span coreButtonLabel>Save</span>
        </button>
      </ng-template>
    </core-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "component",
				type: MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			},
			{
				kind: "directive",
				type: CdkDrag,
				selector: "[cdkDrag]",
				inputs: [
					"cdkDragData",
					"cdkDragLockAxis",
					"cdkDragRootElement",
					"cdkDragBoundary",
					"cdkDragStartDelay",
					"cdkDragFreeDragPosition",
					"cdkDragDisabled",
					"cdkDragConstrainPosition",
					"cdkDragPreviewClass",
					"cdkDragPreviewContainer",
					"cdkDragScale"
				],
				outputs: [
					"cdkDragStarted",
					"cdkDragReleased",
					"cdkDragEnded",
					"cdkDragEntered",
					"cdkDragExited",
					"cdkDragDropped",
					"cdkDragMoved"
				],
				exportAs: ["cdkDrag"]
			},
			{
				kind: "directive",
				type: CdkDragHandle,
				selector: "[cdkDragHandle]",
				inputs: ["cdkDragHandleDisabled"]
			},
			{
				kind: "directive",
				type: CdkDropList,
				selector: "[cdkDropList], cdk-drop-list",
				inputs: [
					"cdkDropListConnectedTo",
					"cdkDropListData",
					"cdkDropListOrientation",
					"id",
					"cdkDropListLockAxis",
					"cdkDropListDisabled",
					"cdkDropListSortingDisabled",
					"cdkDropListEnterPredicate",
					"cdkDropListSortPredicate",
					"cdkDropListAutoScrollDisabled",
					"cdkDropListAutoScrollStep",
					"cdkDropListElementContainer",
					"cdkDropListHasAnchor"
				],
				outputs: [
					"cdkDropListDropped",
					"cdkDropListEntered",
					"cdkDropListExited",
					"cdkDropListSorted"
				],
				exportAs: ["cdkDropList"]
			},
			{
				kind: "component",
				type: MatSlideToggle,
				selector: "mat-slide-toggle",
				inputs: [
					"name",
					"id",
					"labelPosition",
					"aria-label",
					"aria-labelledby",
					"aria-describedby",
					"required",
					"color",
					"disabled",
					"fullWidth",
					"disableRipple",
					"tabIndex",
					"checked",
					"hideIcon",
					"disabledInteractive"
				],
				outputs: ["change", "toggleChange"],
				exportAs: ["matSlideToggle"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldTableDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-table-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				Dialog,
				MatSelect,
				MatOption,
				CdkDrag,
				CdkDragHandle,
				CdkDropList,
				MatSlideToggle,
				Tooltip
			],
			template: `
    <core-dialog
      [pt]="dialogPT"
      [header]="data()?.title || 'Edit items'"
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      <div class="min-h-0 overflow-auto">
        <table class="core-data-table">
          <thead>
            <tr>
              <th
                class="w-12"
                aria-label="Reorder"
              ></th>
              @for (column of columns(); track column.key) {
                <th>{{ column.label }}</th>
              }
              <th class="w-32">Actions</th>
            </tr>
          </thead>
          <tbody
            cdkDropList
            (cdkDropListDropped)="
              onRowReorder({ dragIndex: $event.previousIndex, dropIndex: $event.currentIndex })
            "
          >
            @for (row of displayRows(); track row.id; let rowIndex = $index) {
              <tr cdkDrag>
                <td>
                  <button
                    coreButton
                    text
                    type="button"
                    aria-label="Move row up"
                    [disabled]="rowIndex === 0"
                    (click)="onRowReorder({ dragIndex: rowIndex, dropIndex: rowIndex - 1 })"
                  >
                    <i
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >arrow_upward</i
                    >
                  </button>
                  <button
                    coreButton
                    text
                    type="button"
                    aria-label="Move row down"
                    [disabled]="rowIndex === $count - 1"
                    (click)="onRowReorder({ dragIndex: rowIndex, dropIndex: rowIndex + 1 })"
                  >
                    <i
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >arrow_downward</i
                    >
                  </button>
                  <span
                    cdkDragHandle
                    class="material-symbols-outlined"
                    aria-label="Reorder row"
                    coreTooltip="Reorder row"
                    tooltipPosition="above"
                    >drag_indicator</span
                  >
                </td>
                @for (column of columns(); track column.key) {
                  <td>
                    @switch (column.property.type) {
                      @case (propertyType.INPUT) {
                        <input
                          coreInput
                          class="w-full"
                          [type]="column.property.dataType"
                          [attr.aria-label]="column.label"
                          [ngModel]="getValue(row, column)"
                          (ngModelChange)="updateCell(row, column, $event)"
                        />
                      }
                      @case (propertyType.BOOLEAN) {
                        <mat-slide-toggle
                          [aria-label]="column.label"
                          [ngModel]="getValue(row, column)"
                          (ngModelChange)="updateCell(row, column, $event)"
                        />
                      }
                      @case (propertyType.SELECT) {
                        <mat-select
                          class="w-full"
                          [aria-label]="column.label"
                          [ngModel]="getValue(row, column)"
                          (ngModelChange)="updateCell(row, column, $event)"
                        >
                          @for (option of getSelectOptions(column); track $index) {
                            <mat-option [value]="option.value">{{ option.label }}</mat-option>
                          }
                        </mat-select>
                      }
                    }
                  </td>
                }
                <td>
                  <div class="flex items-center justify-center gap-1">
                    @if (data()?.canRemove) {
                      <button
                        coreButton
                        text
                        rounded
                        severity="danger"
                        type="button"
                        aria-label="Delete row"
                        coreTooltip="Delete row"
                        tooltipPosition="above"
                        (click)="removeRow(row)"
                      >
                        <i
                          coreButtonIcon
                          class="material-symbols-outlined"
                          >delete</i
                        >
                      </button>
                    }
                  </div>
                </td>
              </tr>
            }
          </tbody>
        </table>
      </div>

      <ng-template #footer>
        <span>
          @if (data()?.canAdd) {
            <button
              coreButton
              text
              aria-label="Add item"
              coreTooltip="Add item"
              tooltipPosition="above"
              (click)="addRow()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >add</i
              >
              <span coreButtonLabel>Add item</span>
            </button>
          }
        </span>
        <button
          coreButton
          type="button"
          (click)="save()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >save</i
          >
          <span coreButtonLabel>Save</span>
        </button>
      </ng-template>
    </core-dialog>
  `
		}]
	}],
	ctorParameters: () => []
});
var ExpressionDialog = class ExpressionDialog {
	editingKey = signal(false, ...ngDevMode ? [{ debugName: "editingKey" }] : /* istanbul ignore next */ []);
	targetInput = viewChild("targetInput", ...ngDevMode ? [{ debugName: "targetInput" }] : /* istanbul ignore next */ []);
	targetEditButton = viewChild("targetEditButton", ...ngDevMode ? [{ debugName: "targetEditButton" }] : /* istanbul ignore next */ []);
	constructor() {
		let wasEditing = false;
		effect(() => {
			const editing = this.editingKey();
			if (editing) this.targetInput()?.nativeElement.focus();
			else if (wasEditing) this.targetEditButton()?.nativeElement.focus();
			wasEditing = editing;
		});
	}
	codeEditor = viewChild(CodeEditor, ...ngDevMode ? [{ debugName: "codeEditor" }] : /* istanbul ignore next */ []);
	dialogService = inject(ExpressionDialogService);
	isOpen = this.dialogService.isOpen;
	data = this.dialogService.data;
	dialogPT = {
		header: { style: { height: "5rem" } },
		content: { style: {
			height: "calc(100% - 10rem)",
			overflow: "hidden"
		} },
		footer: { style: {
			height: "5rem",
			alignItems: "center",
			justifyContent: "space-between"
		} }
	};
	placeholder = `// Set the target using a javascript expression.

// Available variables:
// model: The current model object
// formState: The current form state
// field: The current field configuration

// Example:
// model.age >= 18; // sets the target to true if age is 18 or older

// You can also use a self executing function for a multi-line expression:
(() => {
  console.log('Evaluating expression with', model);
  const age = model.age || 0;
  return age >= 18;
})();
  `;
	setKey(newKey) {
		this.dialogService.setKey(newKey);
		this.editingKey.set(false);
	}
	beautify() {
		this.dialogService.setValue(beautifyCode(this.getEditorValue()));
	}
	async flattenToLine() {
		this.dialogService.setValue(await flattenToOneLine(this.getEditorValue()));
	}
	addFunctionBlock() {
		this.dialogService.setValue(this.getEditorValue() + `(() => {
  const bar = 'World';
  return 'Hello ' + (model?.foo || bar);
})()`);
	}
	save() {
		const key = this.data()?.key || "";
		const value = this.getEditorValue();
		this.data()?.saveCallback(key, value);
		this.dialogService.close();
	}
	updateVisibility(visible) {
		if (!visible) this.dialogService.close();
	}
	getEditorValue() {
		return this.codeEditor()?.getValue() || "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpressionDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ExpressionDialog,
		isStandalone: true,
		selector: "core-expression-dialog",
		viewQueries: [
			{
				propertyName: "targetInput",
				first: true,
				predicate: ["targetInput"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "targetEditButton",
				first: true,
				predicate: ["targetEditButton"],
				descendants: true,
				isSignal: true
			},
			{
				propertyName: "codeEditor",
				first: true,
				predicate: CodeEditor,
				descendants: true,
				isSignal: true
			}
		],
		ngImport: i0,
		template: `
    <core-dialog
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [pt]="dialogPT"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      <ng-template #header>
        <div class="inline-flex items-center justify-center gap-2 text-xl font-semibold">
          <span>Edit expression:</span>

          @if (!editingKey()) {
            <button
              #targetEditButton
              coreButton
              text
              type="button"
              aria-label="Edit expression target"
              (click)="editingKey.set(true)"
            >
              <span class="inline-flex items-center gap-2">
                <span class="ml-2">{{ data()?.key || '<- target ->' }}</span>
                <i class="material-symbols-outlined"> edit </i>
              </span>
            </button>
          } @else {
            <span class="inline-flex gap-2">
              <input
                #nameInput="ngModel"
                #targetInput
                type="text"
                placeholder="e.g., model.myKey"
                coreInput
                aria-label="Expression target"
                [ngModel]="data()?.key || ''"
                (keydown.enter)="setKey(nameInput.value)"
              />
              <button
                coreButton
                text
                rounded
                aria-label="Confirm target"
                coreTooltip="Confirm target"
                tooltipPosition="above"
                [showDelay]="500"
                (click)="setKey(nameInput.value)"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  check
                </i>
              </button>
              <button
                coreButton
                text
                rounded
                severity="danger"
                aria-label="Cancel target edit"
                coreTooltip="Cancel target edit"
                tooltipPosition="above"
                [showDelay]="500"
                (click)="editingKey.set(false)"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  close
                </i>
              </button>
            </span>
          }
        </div>
      </ng-template>

      @if (isOpen() && data()) {
        <core-code-editor
          [text]="data()?.value || ''"
          [placeholderText]="placeholder"
        />
      }
      <ng-template #footer>
        <span class="inline-flex items-center gap-2">
          <button
            coreButton
            text
            aria-label="Format expression as single line"
            coreTooltip="Single Line"
            tooltipPosition="above"
            (click)="flattenToLine()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              remove
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Single Line</span
            >
          </button>
          <button
            coreButton
            text
            aria-label="Beautify expression"
            coreTooltip="Beautify expression"
            tooltipPosition="above"
            (click)="beautify()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              wand_stars
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Beautify</span
            >
          </button>
          <button
            coreButton
            text
            aria-label="Add function block"
            coreTooltip="Add function block"
            tooltipPosition="above"
            (click)="addFunctionBlock()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              code
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Add Function Block</span
            >
          </button>
        </span>
        <button
          coreButton
          (click)="save()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            save
          </i>
          <span coreButtonLabel>Save</span>
        </button>
      </ng-template>
    </core-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "component",
				type: CodeEditor,
				selector: "core-code-editor",
				inputs: [
					"text",
					"placeholderText",
					"mode",
					"editable"
				],
				outputs: ["textChange"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpressionDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-expression-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Dialog,
				CodeEditor,
				FormsModule,
				Tooltip
			],
			template: `
    <core-dialog
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [pt]="dialogPT"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      <ng-template #header>
        <div class="inline-flex items-center justify-center gap-2 text-xl font-semibold">
          <span>Edit expression:</span>

          @if (!editingKey()) {
            <button
              #targetEditButton
              coreButton
              text
              type="button"
              aria-label="Edit expression target"
              (click)="editingKey.set(true)"
            >
              <span class="inline-flex items-center gap-2">
                <span class="ml-2">{{ data()?.key || '<- target ->' }}</span>
                <i class="material-symbols-outlined"> edit </i>
              </span>
            </button>
          } @else {
            <span class="inline-flex gap-2">
              <input
                #nameInput="ngModel"
                #targetInput
                type="text"
                placeholder="e.g., model.myKey"
                coreInput
                aria-label="Expression target"
                [ngModel]="data()?.key || ''"
                (keydown.enter)="setKey(nameInput.value)"
              />
              <button
                coreButton
                text
                rounded
                aria-label="Confirm target"
                coreTooltip="Confirm target"
                tooltipPosition="above"
                [showDelay]="500"
                (click)="setKey(nameInput.value)"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  check
                </i>
              </button>
              <button
                coreButton
                text
                rounded
                severity="danger"
                aria-label="Cancel target edit"
                coreTooltip="Cancel target edit"
                tooltipPosition="above"
                [showDelay]="500"
                (click)="editingKey.set(false)"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  close
                </i>
              </button>
            </span>
          }
        </div>
      </ng-template>

      @if (isOpen() && data()) {
        <core-code-editor
          [text]="data()?.value || ''"
          [placeholderText]="placeholder"
        />
      }
      <ng-template #footer>
        <span class="inline-flex items-center gap-2">
          <button
            coreButton
            text
            aria-label="Format expression as single line"
            coreTooltip="Single Line"
            tooltipPosition="above"
            (click)="flattenToLine()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              remove
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Single Line</span
            >
          </button>
          <button
            coreButton
            text
            aria-label="Beautify expression"
            coreTooltip="Beautify expression"
            tooltipPosition="above"
            (click)="beautify()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              wand_stars
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Beautify</span
            >
          </button>
          <button
            coreButton
            text
            aria-label="Add function block"
            coreTooltip="Add function block"
            tooltipPosition="above"
            (click)="addFunctionBlock()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              code
            </i>
            <span
              class="hidden sm:inline"
              coreButtonLabel
              >Add Function Block</span
            >
          </button>
        </span>
        <button
          coreButton
          (click)="save()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            save
          </i>
          <span coreButtonLabel>Save</span>
        </button>
      </ng-template>
    </core-dialog>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		targetInput: [{
			type: i0.ViewChild,
			args: ["targetInput", { isSignal: true }]
		}],
		targetEditButton: [{
			type: i0.ViewChild,
			args: ["targetEditButton", { isSignal: true }]
		}],
		codeEditor: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => CodeEditor), { isSignal: true }]
		}]
	}
});
var MarkdownDialog = class MarkdownDialog {
	codeEditor = viewChild(CodeEditor, ...ngDevMode ? [{ debugName: "codeEditor" }] : /* istanbul ignore next */ []);
	dialogService = inject(MarkdownDialogService);
	isOpen = this.dialogService.isOpen;
	data = this.dialogService.data;
	dialogPT = {
		content: { style: {
			height: "calc(100% - 10rem)",
			overflow: "hidden"
		} },
		footer: { style: {
			height: "5rem",
			alignItems: "center",
			justifyContent: "flex-end"
		} }
	};
	setValue(value) {
		this.dialogService.setValue(value);
	}
	save() {
		const data = this.data();
		if (data) data.saveCallback(data.value);
		this.dialogService.close();
	}
	cancel() {
		this.dialogService.close();
	}
	updateVisibility(visible) {
		if (!visible) this.cancel();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MarkdownDialog,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: MarkdownDialog,
		isStandalone: true,
		selector: "core-markdown-dialog",
		viewQueries: [{
			propertyName: "codeEditor",
			first: true,
			predicate: CodeEditor,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-dialog
      header="Edit Markdown"
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [pt]="dialogPT"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      @if (isOpen() && data()) {
        <core-code-editor
          mode="markdown"
          placeholderText="Write Markdown content..."
          [text]="data()?.value || ''"
          (textChange)="setValue($event)"
        />
      }
      <ng-template #footer>
        <button
          coreButton
          text
          type="button"
          (click)="cancel()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >close</i
          >
          <span coreButtonLabel>Cancel</span>
        </button>
        <button
          coreButton
          type="button"
          (click)="save()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >save</i
          >
          <span coreButtonLabel>Save</span>
        </button>
      </ng-template>
    </core-dialog>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: CodeEditor,
			selector: "core-code-editor",
			inputs: [
				"text",
				"placeholderText",
				"mode",
				"editable"
			],
			outputs: ["textChange"]
		}, {
			kind: "component",
			type: Dialog,
			selector: "core-dialog",
			inputs: [
				"visible",
				"header",
				"focusOnShow",
				"style",
				"pt",
				"closable",
				"closeOnEscape",
				"role"
			],
			outputs: ["visibleChange", "opened"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MarkdownDialog,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-markdown-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [CodeEditor, Dialog],
			template: `
    <core-dialog
      header="Edit Markdown"
      [style]="{
        width: '800px',
        maxWidth: 'calc(100vw - 32px)',
        height: '600px',
        maxHeight: 'calc(100vh - 32px)',
      }"
      [pt]="dialogPT"
      [visible]="isOpen()"
      (visibleChange)="updateVisibility($event)"
    >
      @if (isOpen() && data()) {
        <core-code-editor
          mode="markdown"
          placeholderText="Write Markdown content..."
          [text]="data()?.value || ''"
          (textChange)="setValue($event)"
        />
      }
      <ng-template #footer>
        <button
          coreButton
          text
          type="button"
          (click)="cancel()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >close</i
          >
          <span coreButtonLabel>Cancel</span>
        </button>
        <button
          coreButton
          type="button"
          (click)="save()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >save</i
          >
          <span coreButtonLabel>Save</span>
        </button>
      </ng-template>
    </core-dialog>
  `
		}]
	}],
	propDecorators: { codeEditor: [{
		type: i0.ViewChild,
		args: [i0.forwardRef(() => CodeEditor), { isSignal: true }]
	}] }
});
var AppDialogs = class AppDialogs {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AppDialogs,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: AppDialogs,
		isStandalone: true,
		selector: "core-app-dialogs",
		host: { classAttribute: "core-root" },
		ngImport: i0,
		template: `
    <core-create-form-dialog />
    <core-field-preset-dialog />
    <core-expression-dialog />
    <core-markdown-dialog />
    <core-form-preview-dialog />
    <core-export-dialog />
    <core-import-dialog />
    <core-field-table-dialog />
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: CreateFormDialog,
				selector: "core-create-form-dialog"
			},
			{
				kind: "component",
				type: FieldPresetDialog,
				selector: "core-field-preset-dialog"
			},
			{
				kind: "component",
				type: ExpressionDialog,
				selector: "core-expression-dialog"
			},
			{
				kind: "component",
				type: MarkdownDialog,
				selector: "core-markdown-dialog"
			},
			{
				kind: "component",
				type: FormPreviewDialog,
				selector: "core-form-preview-dialog"
			},
			{
				kind: "component",
				type: ExportDialog,
				selector: "core-export-dialog"
			},
			{
				kind: "component",
				type: ImportDialog,
				selector: "core-import-dialog"
			},
			{
				kind: "component",
				type: FieldTableDialog,
				selector: "core-field-table-dialog"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AppDialogs,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-app-dialogs",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				CreateFormDialog,
				FieldPresetDialog,
				ExpressionDialog,
				MarkdownDialog,
				FormPreviewDialog,
				ExportDialog,
				ImportDialog,
				FieldTableDialog
			],
			host: { class: "core-root" },
			template: `
    <core-create-form-dialog />
    <core-field-preset-dialog />
    <core-expression-dialog />
    <core-markdown-dialog />
    <core-form-preview-dialog />
    <core-export-dialog />
    <core-import-dialog />
    <core-field-table-dialog />
  `
		}]
	}]
});
export { AppDialogs };

//# sourceMappingURL=ngx-formly-builder-ui-app-dialogs-E0Rxyi5S.mjs.map