import { $ as createSelectProperty, A as CoreLibraryService, B as CORE_EDITOR_CONFIG, C as PanelHeader, D as CreateFormDialogService, E as CORE_THEME, F as createLibrary, G as createValidationMessagesProperty, H as CORE_LIBRARY_CONFIGS, I as defaultTypeOption, J as getDefaultPropertyFromValue, K as getChildPath, L as generateTypeOptionSchema, M as vanillaLibraryConfig, N as nativeFieldConfig, O as CoreFormService, P as nativeFieldTypes, Q as trackByPropertyKey, R as generateTypeOptionSchemaMap, S as Tooltip, U as Dialog, V as CORE_FORM_TEMPLATES, W as createWrappersProperty, X as getPropertySchema, Y as getDefaultPropertyValue, Z as modifyPropertyTarget, _ as JSONSchemaValidator, a as MarkdownDialogService, at as createDateProperty, b as TreeItem, c as ExpressionDialogService, ct as createBooleanProperty, d as ExportDialogService, dt as PropertyType, et as createObjectProperty, f as PreviewDeviceToolbar, g as CORE_BUILDER_FORM, h as FormlyConfigService, i as FieldPresetDialogService, it as createExpressionsProperty, k as CoreFieldService, l as ArrayTableDialogService, lt as createArrayProperty, m as PreviewViewportService, n as FormStoreRecoveryRequiredError, nt as createInputProperty, o as beautifyCode, ot as createCustomValidationProperty, p as FormPreviewContent, q as getDefaultProperty, r as ImportDialogService, rt as createGroupProperty, s as flattenToOneLine, st as createChipsProperty, t as CORE_FORM_STORE, tt as createMarkdownProperty, u as PreviewDialogService, ut as PropertyChangeType, v as JSONFormatValidator, w as Filter, x as MouseInsideService, y as JSONContent, z as PanelService } from "./ngx-formly-builder-ui-types-D0bY_dJC.mjs";
import { BuilderEngineService, BuilderFieldStateService, LocalFormStoreService, addNodeToHierarchy, buildHierarchyFromFlatForms, createEmptyWorkspaceHierarchy, getDescendantNodeIds, isAncestorOf, isLayoutRow, isValidationRuleName, moveNodeInHierarchy, provideFormStore, provideLocalFormStore, recalculateNodePaths, removeNodeFromHierarchy, renameNodeInHierarchy, toggleFolderExpansion } from "@ngx-formly/builder";
import * as i0 from "@angular/core";
import { ChangeDetectionStrategy, Component, DOCUMENT, DestroyRef, Directive, ElementRef, Injectable, InjectionToken, Injector, Input, TemplateRef, ViewContainerRef, afterNextRender, booleanAttribute, computed, contentChild, contentChildren, effect, inject, input, linkedSignal, makeEnvironmentProviders, model, numberAttribute, output, signal, viewChild } from "@angular/core";
import { takeUntilDestroyed, toObservable, toSignal } from "@angular/core/rxjs-interop";
import { AsyncPipe, DOCUMENT as DOCUMENT$1, NgTemplateOutlet } from "@angular/common";
import { BreakpointObserver } from "@angular/cdk/layout";
import { combineLatest, concatMap, debounceTime, defer, filter, finalize, from, map, tap } from "rxjs";
import { get } from "lodash-es";
import * as i1$3 from "@ngx-formly/core";
import { FieldWrapper, FormlyConfig, FormlyField, FormlyForm, FormlyFormBuilder, provideFormlyConfig, provideFormlyCore } from "@ngx-formly/core";
import * as i1$2 from "@angular/forms";
import { FormGroup, FormsModule, NgForm } from "@angular/forms";
import { DndDraggableDirective, DndDropzoneDirective, DndHandleDirective } from "ngx-drag-drop";
import { Overlay } from "@angular/cdk/overlay";
import * as i1$1 from "@angular/material/tabs";
import { MatTabsModule } from "@angular/material/tabs";
import { CdkMenu, CdkMenuItem, CdkMenuTrigger, MENU_STACK, MenuStack } from "@angular/cdk/menu";
import { TemplatePortal } from "@angular/cdk/portal";
import { MatSlideToggle } from "@angular/material/slide-toggle";
import * as i2 from "@angular/material/select";
import { MatSelect, MatSelectModule } from "@angular/material/select";
import { MatOption, provideNativeDateAdapter } from "@angular/material/core";
import * as i1 from "@angular/material/chips";
import { MatChipsModule } from "@angular/material/chips";
import { format, parse } from "date-fns";
import * as i2$1 from "@angular/material/datepicker";
import { MatDatepickerModule } from "@angular/material/datepicker";
import { CdkTrapFocus } from "@angular/cdk/a11y";
import saveAs from "file-saver";
export * from "@ngx-formly/builder";
var Splitter = class Splitter {
	panelSizes = input.required(...ngDevMode ? [{ debugName: "panelSizes" }] : /* istanbul ignore next */ []);
	minSizes = input([], ...ngDevMode ? [{ debugName: "minSizes" }] : /* istanbul ignore next */ []);
	stateKey = input.required(...ngDevMode ? [{ debugName: "stateKey" }] : /* istanbul ignore next */ []);
	panels = contentChildren("panel", ...ngDevMode ? [{ debugName: "panels" }] : /* istanbul ignore next */ []);
	sizes = signal([], ...ngDevMode ? [{ debugName: "sizes" }] : /* istanbul ignore next */ []);
	layout = viewChild.required("layout", ...ngDevMode ? [{ debugName: "layout" }] : /* istanbul ignore next */ []);
	drag;
	constructor() {
		effect(() => {
			const fallback = this.panelSizes();
			let sizes = fallback;
			try {
				const stored = JSON.parse(localStorage.getItem(this.stateKey()) || "null")?.panelSizes;
				if (Array.isArray(stored) && stored.length === fallback.length && stored.every((size) => typeof size === "number" && Number.isFinite(size) && size > 0) && Math.abs(stored.reduce((sum, size) => sum + size, 0) - 100) < .01) sizes = stored;
			} catch {}
			this.sizes.set([...sizes]);
		});
	}
	minimum(index) {
		return this.minSizes()[index] ?? 10;
	}
	start(event, index) {
		if (event.button !== 0) return;
		event.currentTarget.setPointerCapture(event.pointerId);
		this.drag = {
			index,
			start: event.clientX,
			sizes: [...this.sizes()]
		};
		event.preventDefault();
	}
	move(event) {
		if (!this.drag) return;
		const width = this.layout().nativeElement.clientWidth;
		if (width > 0) this.resize(this.drag.index, (event.clientX - this.drag.start) / width * 100, this.drag.sizes);
	}
	finish() {
		this.drag = void 0;
		this.persist();
	}
	resizeWithKeyboard(event, index) {
		if (![
			"ArrowLeft",
			"ArrowRight",
			"Home",
			"End"
		].includes(event.key)) return;
		event.preventDefault();
		const delta = event.key === "Home" ? -100 : event.key === "End" ? 100 : event.key === "ArrowLeft" ? -2 : 2;
		this.resize(index, delta, this.sizes());
		this.persist();
	}
	resize(index, delta, initial) {
		const total = initial[index] + initial[index + 1];
		const left = Math.max(this.minimum(index), Math.min(total - this.minimum(index + 1), initial[index] + delta));
		const sizes = [...initial];
		sizes[index] = left;
		sizes[index + 1] = total - left;
		this.sizes.set(sizes);
	}
	persist() {
		try {
			localStorage.setItem(this.stateKey(), JSON.stringify({ panelSizes: this.sizes() }));
		} catch {}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Splitter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Splitter,
		isStandalone: true,
		selector: "core-splitter",
		inputs: {
			panelSizes: {
				classPropertyName: "panelSizes",
				publicName: "panelSizes",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			minSizes: {
				classPropertyName: "minSizes",
				publicName: "minSizes",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			stateKey: {
				classPropertyName: "stateKey",
				publicName: "stateKey",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: { classAttribute: "block h-full min-h-0" },
		queries: [{
			propertyName: "panels",
			predicate: ["panel"],
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "layout",
			first: true,
			predicate: ["layout"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      #layout
      class="core-splitter"
    >
      @for (panel of panels(); track $index) {
        <div
          class="core-splitter-panel"
          [style.flex-basis.%]="sizes()[$index]"
        >
          <ng-container [ngTemplateOutlet]="panel" />
        </div>
        @if (!$last) {
          <div
            class="core-splitter-handle"
            role="separator"
            tabindex="0"
            aria-orientation="vertical"
            [attr.aria-label]="'Resize panel ' + ($index + 1)"
            [attr.aria-valuenow]="sizes()[$index]"
            [attr.aria-valuemin]="minimum($index)"
            [attr.aria-valuemax]="sizes()[$index] + sizes()[$index + 1] - minimum($index + 1)"
            (pointerdown)="start($event, $index)"
            (pointermove)="move($event)"
            (pointerup)="finish()"
            (pointercancel)="finish()"
            (keydown)="resizeWithKeyboard($event, $index)"
          ></div>
        }
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Splitter,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-splitter",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			host: { class: "block h-full min-h-0" },
			template: `
    <div
      #layout
      class="core-splitter"
    >
      @for (panel of panels(); track $index) {
        <div
          class="core-splitter-panel"
          [style.flex-basis.%]="sizes()[$index]"
        >
          <ng-container [ngTemplateOutlet]="panel" />
        </div>
        @if (!$last) {
          <div
            class="core-splitter-handle"
            role="separator"
            tabindex="0"
            aria-orientation="vertical"
            [attr.aria-label]="'Resize panel ' + ($index + 1)"
            [attr.aria-valuenow]="sizes()[$index]"
            [attr.aria-valuemin]="minimum($index)"
            [attr.aria-valuemax]="sizes()[$index] + sizes()[$index + 1] - minimum($index + 1)"
            (pointerdown)="start($event, $index)"
            (pointermove)="move($event)"
            (pointerup)="finish()"
            (pointercancel)="finish()"
            (keydown)="resizeWithKeyboard($event, $index)"
          ></div>
        }
      }
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		panelSizes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "panelSizes",
				required: true
			}]
		}],
		minSizes: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "minSizes",
				required: false
			}]
		}],
		stateKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "stateKey",
				required: true
			}]
		}],
		panels: [{
			type: i0.ContentChildren,
			args: ["panel", { isSignal: true }]
		}],
		layout: [{
			type: i0.ViewChild,
			args: ["layout", { isSignal: true }]
		}]
	}
});
const MOBILE_BREAKPOINT = "(max-width: 1023.98px)";
const TABLET_BREAKPOINT = "(min-width: 1024px) and (max-width: 1535.98px)";
const DESKTOP_BREAKPOINT = "(min-width: 1536px)";
var CoreResponsiveService = class CoreResponsiveService {
	breakpointObserver = inject(BreakpointObserver);
	isMobile$ = this.breakpointObserver.observe([MOBILE_BREAKPOINT]).pipe(map((result) => result.matches));
	isTablet$ = this.breakpointObserver.observe([TABLET_BREAKPOINT]).pipe(map((result) => result.matches));
	isDesktop$ = this.breakpointObserver.observe([DESKTOP_BREAKPOINT]).pipe(map((result) => result.matches));
	isMobile = toSignal(this.isMobile$, { initialValue: false });
	isTablet = toSignal(this.isTablet$, { initialValue: false });
	isDesktop = toSignal(this.isDesktop$, { initialValue: false });
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreResponsiveService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreResponsiveService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreResponsiveService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var Empty = class Empty {
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	description = input("", ...ngDevMode ? [{ debugName: "description" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Empty,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: Empty,
		isStandalone: true,
		selector: "core-empty",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: { classAttribute: "flex flex-col items-center justify-center p-6 gap-4 text-center" },
		ngImport: i0,
		template: `
    <div class="flex justify-center">
      <i class="material-symbols-outlined">box</i>
    </div>

    <div>
      <div class="text-lg font-medium">{{ label() || 'Nothing here yet' }}</div>
      <div class="text-sm">
        {{ description() || 'Create or select an item to get started.' }}
      </div>
    </div>

    <ng-content />
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Empty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-empty",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "flex flex-col items-center justify-center p-6 gap-4 text-center" },
			template: `
    <div class="flex justify-center">
      <i class="material-symbols-outlined">box</i>
    </div>

    <div>
      <div class="text-lg font-medium">{{ label() || 'Nothing here yet' }}</div>
      <div class="text-sm">
        {{ description() || 'Create or select an item to get started.' }}
      </div>
    </div>

    <ng-content />
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}]
	}
});
var EmptyNoField = class EmptyNoField {
	panelService = inject(PanelService);
	openAddFieldPanel() {
		this.panelService.activeAddFieldTab.set("fields");
		this.panelService.setActiveLHSPanel("add-field");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EmptyNoField,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: EmptyNoField,
		isStandalone: true,
		selector: "core-empty-no-field",
		ngImport: i0,
		template: `
    <core-empty
      label="No field in this form"
      description="Add a field from the Add Field panel"
    >
      <button
        coreButton
        (click)="openAddFieldPanel()"
      >
        <i
          class="material-symbols-outlined"
          aria-hidden="true"
          >open_in_new</i
        >
        Open Add Field Panel
      </button>
    </core-empty>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: Empty,
			selector: "core-empty",
			inputs: ["label", "description"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EmptyNoField,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-empty-no-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Empty],
			template: `
    <core-empty
      label="No field in this form"
      description="Add a field from the Add Field panel"
    >
      <button
        coreButton
        (click)="openAddFieldPanel()"
      >
        <i
          class="material-symbols-outlined"
          aria-hidden="true"
          >open_in_new</i
        >
        Open Add Field Panel
      </button>
    </core-empty>
  `
		}]
	}]
});
var EmptyNoFieldSelected = class EmptyNoFieldSelected {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EmptyNoFieldSelected,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: EmptyNoFieldSelected,
		isStandalone: true,
		selector: "core-empty-no-field-selected",
		ngImport: i0,
		template: `
    <core-empty
      label="No field selected"
      description="Select a field to edit its properties."
    />
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: Empty,
			selector: "core-empty",
			inputs: ["label", "description"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EmptyNoFieldSelected,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-empty-no-field-selected",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Empty],
			template: `
    <core-empty
      label="No field selected"
      description="Select a field to edit its properties."
    />
  `
		}]
	}]
});
var EmptyNoForm = class EmptyNoForm {
	formService = inject(CoreFormService);
	panelService = inject(PanelService);
	createFormDialogService = inject(CreateFormDialogService);
	openFormsPanel() {
		this.panelService.setActiveLHSPanel("forms");
	}
	addNewForm() {
		this.createFormDialogService.open();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: EmptyNoForm,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: EmptyNoForm,
		isStandalone: true,
		selector: "core-empty-no-form",
		ngImport: i0,
		template: `
    <core-empty
      label="No Active form"
      description="Select a form from the Workspace panel, or create a new one to get started"
    >
      <span class="inline-flex flex-wrap items-center justify-center gap-4">
        <button
          coreButton
          severity="secondary"
          (click)="openFormsPanel()"
        >
          <i class="material-symbols-outlined">open_in_new</i>
          Open Workspace Panel
        </button>
        <button
          coreButton
          [disabled]="formService.hasStorageRecoveryIssues()"
          (click)="addNewForm()"
        >
          <i class="material-symbols-outlined">add</i>
          Create Form
        </button>
      </span>
    </core-empty>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: Empty,
			selector: "core-empty",
			inputs: ["label", "description"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: EmptyNoForm,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-empty-no-form",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Empty],
			template: `
    <core-empty
      label="No Active form"
      description="Select a form from the Workspace panel, or create a new one to get started"
    >
      <span class="inline-flex flex-wrap items-center justify-center gap-4">
        <button
          coreButton
          severity="secondary"
          (click)="openFormsPanel()"
        >
          <i class="material-symbols-outlined">open_in_new</i>
          Open Workspace Panel
        </button>
        <button
          coreButton
          [disabled]="formService.hasStorageRecoveryIssues()"
          (click)="addNewForm()"
        >
          <i class="material-symbols-outlined">add</i>
          Create Form
        </button>
      </span>
    </core-empty>
  `
		}]
	}]
});
var DNDService = class DNDService {
	_activeDragData = signal(null, ...ngDevMode ? [{ debugName: "_activeDragData" }] : /* istanbul ignore next */ []);
	activeDragData = this._activeDragData.asReadonly();
	_activeDragOverData = signal(null, ...ngDevMode ? [{ debugName: "_activeDragOverData" }] : /* istanbul ignore next */ []);
	activeDragOverData = this._activeDragOverData.asReadonly();
	setActiveDragData(data) {
		this._activeDragData.set(data);
	}
	setActiveDragOverData(data) {
		this._activeDragOverData.set(data);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DNDService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DNDService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DNDService,
	decorators: [{ type: Injectable }]
});
var DropAction;
(function(DropAction) {
	DropAction["COPY"] = "copy";
	DropAction["MOVE"] = "move";
})(DropAction || (DropAction = {}));
var FormlyTemplate = class FormlyTemplate {
	name = "formly-group";
	ref = inject(TemplateRef);
	ngOnChanges() {
		this.name = this.name || "formly-group";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyTemplate,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FormlyTemplate,
		isStandalone: false,
		selector: "[formlyTemplate]",
		inputs: { name: ["formlyTemplate", "name"] },
		usesOnChanges: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormlyTemplate,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[formlyTemplate]",
			standalone: false
		}]
	}],
	propDecorators: { name: [{
		type: Input,
		args: ["formlyTemplate"]
	}] }
});
var FormlyFieldTemplates = class FormlyFieldTemplates {
	templates;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyFieldTemplates,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyFieldTemplates
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormlyFieldTemplates,
	decorators: [{ type: Injectable }]
});
var CoreFormlyForm = class CoreFormlyForm extends FormlyForm {
	formError = signal("", ...ngDevMode ? [{ debugName: "formError" }] : /* istanbul ignore next */ []);
	constructor(builder, config, ngZone, fieldTemplates) {
		super(builder, config, ngZone, fieldTemplates);
	}
	ngOnChanges(changes) {
		try {
			super.ngOnChanges(changes);
			this.formError.set("");
		} catch (e) {
			this.field.fieldGroup = [];
			const error = e;
			this.formError.set(`Build Error: ${error.message}`);
			console.error(error);
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreFormlyForm,
		deps: [
			{ token: i1$3.FormlyFormBuilder },
			{ token: i1$3.FormlyConfig },
			{ token: i0.NgZone },
			{ token: FormlyFieldTemplates }
		],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CoreFormlyForm,
		isStandalone: true,
		selector: "core-formly-form",
		providers: [FormlyFormBuilder, FormlyFieldTemplates],
		usesInheritance: true,
		usesOnChanges: true,
		ngImport: i0,
		template: `
    @if (formError()) {
      <div
        role="alert"
        class="core-message"
        severity="error"
      >
        <i class="material-symbols-outlined">error</i>

        {{ formError() }}
      </div>
    } @else {
      <formly-field [field]="field" />
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: FormlyField,
			selector: "formly-field",
			inputs: ["field"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreFormlyForm,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-formly-form",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [FormlyFormBuilder, FormlyFieldTemplates],
			imports: [FormlyField],
			template: `
    @if (formError()) {
      <div
        role="alert"
        class="core-message"
        severity="error"
      >
        <i class="material-symbols-outlined">error</i>

        {{ formError() }}
      </div>
    } @else {
      <formly-field [field]="field" />
    }
  `
		}]
	}],
	ctorParameters: () => [
		{ type: i1$3.FormlyFormBuilder },
		{ type: i1$3.FormlyConfig },
		{ type: i0.NgZone },
		{ type: FormlyFieldTemplates }
	]
});
var FormBuilderContent = class FormBuilderContent {
	viewport = inject(PreviewViewportService);
	formService = inject(CoreFormService);
	dndService = inject(DNDService);
	formlyConfig = inject(FormlyConfigService);
	formGroup = new FormGroup({});
	options = {};
	formFields$ = toObservable(this.formService.activeFormFields).pipe(debounceTime(100), tap(() => {
		this.formlyConfig.loadLibraryConfigOptions();
		this.formGroup = new FormGroup({});
		this.options = {};
	}));
	model = this.formService.activeModel;
	onFormModelChanged(model) {
		this.formService.setActiveModel(model);
	}
	onDrop() {
		const dragData = this.dndService.activeDragData();
		if (!dragData || this.dndService.activeDragData()?.action !== DropAction.COPY) return;
		this.formService.addField(dragData.fieldType, void 0, void 0, dragData.preset);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormBuilderContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormBuilderContent,
		isStandalone: true,
		selector: "core-form-builder-content",
		host: {
			properties: { "style.width.px": "viewport.targetWidth()" },
			classAttribute: "block mx-auto"
		},
		providers: [
			provideFormlyCore(),
			FormlyConfigService,
			{
				provide: CORE_BUILDER_FORM,
				useValue: true
			}
		],
		ngImport: i0,
		template: `
    @if (formFields$ | async; as formFields) {
      @if (formFields.length) {
        <core-formly-form
          [fields]="formFields"
          [model]="model()"
          [form]="formGroup"
          [options]="options"
          (modelChange)="onFormModelChanged($event)"
        />
      } @else {
        <core-empty-no-field
          class="block h-full w-full justify-start transition-colors"
          dndDropzone
          dndDragoverClass="bg-green-200/20"
          (dndDrop)="onDrop()"
        />
      }
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: CoreFormlyForm,
				selector: "core-formly-form"
			},
			{
				kind: "directive",
				type: DndDropzoneDirective,
				selector: "[dndDropzone]",
				inputs: [
					"dndDropzone",
					"dndEffectAllowed",
					"dndAllowExternal",
					"dndHorizontal",
					"dndDragoverClass",
					"dndDropzoneDisabledClass",
					"dndDisableIf",
					"dndDisableDropIf"
				],
				outputs: ["dndDragover", "dndDrop"]
			},
			{
				kind: "component",
				type: EmptyNoField,
				selector: "core-empty-no-field"
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormBuilderContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-builder-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				provideFormlyCore(),
				FormlyConfigService,
				{
					provide: CORE_BUILDER_FORM,
					useValue: true
				}
			],
			imports: [
				CoreFormlyForm,
				DndDropzoneDirective,
				EmptyNoField,
				AsyncPipe
			],
			host: {
				class: "block mx-auto",
				"[style.width.px]": "viewport.targetWidth()"
			},
			template: `
    @if (formFields$ | async; as formFields) {
      @if (formFields.length) {
        <core-formly-form
          [fields]="formFields"
          [model]="model()"
          [form]="formGroup"
          [options]="options"
          (modelChange)="onFormModelChanged($event)"
        />
      } @else {
        <core-empty-no-field
          class="block h-full w-full justify-start transition-colors"
          dndDropzone
          dndDragoverClass="bg-green-200/20"
          (dndDrop)="onDrop()"
        />
      }
    }
  `
		}]
	}]
});
var FormTitle = class FormTitle {
	forms = inject(CoreFormService);
	edit = signal(null, ...ngDevMode ? [{ debugName: "edit" }] : /* istanbul ignore next */ []);
	injector = inject(Injector);
	focusTarget = viewChild("focusTarget", ...ngDevMode ? [{ debugName: "focusTarget" }] : /* istanbul ignore next */ []);
	startEdit(formId) {
		this.edit.set({
			formId,
			name: this.forms.activeFormName() ?? ""
		});
		this.focusAfterRender();
	}
	handleKeydown(event, name) {
		if (event.isComposing) return;
		if (event.key === "Enter" || event.key === "Escape") {
			event.preventDefault();
			this.finishEdit(event.key === "Enter" ? name : null, true);
		}
	}
	finishEdit(name, restoreFocus = false) {
		const edit = this.edit();
		this.edit.set(null);
		if (edit && name?.trim() && name !== edit.name) this.forms.setWorkspaceNodeName(edit.formId, name);
		if (restoreFocus) this.focusAfterRender();
	}
	focusAfterRender() {
		afterNextRender({ write: () => this.focusTarget()?.nativeElement.focus() }, { injector: this.injector });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormTitle,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormTitle,
		isStandalone: true,
		selector: "core-form-title",
		host: { classAttribute: "block min-w-0" },
		viewQueries: [{
			propertyName: "focusTarget",
			first: true,
			predicate: ["focusTarget"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (forms.activeFormId(); as formId) {
      @if (edit()?.formId === formId) {
        <input
          #focusTarget
          #nameInput
          type="text"
          aria-label="Form name"
          class="block w-48 max-w-full rounded border border-primary bg-content-background px-1 text-lg font-medium focus-visible:outline-2 focus-visible:outline-primary"
          [value]="edit()?.name ?? ''"
          (blur)="finishEdit(nameInput.value)"
          (keydown)="handleKeydown($event, nameInput.value)"
        />
      } @else {
        <button
          #focusTarget
          type="button"
          class="block max-w-full cursor-pointer truncate rounded px-1 text-lg font-medium hover:underline focus-visible:outline-2 focus-visible:outline-primary"
          [attr.aria-label]="'Rename form: ' + forms.activeFormName()"
          [title]="forms.activeFormName() ?? ''"
          (click)="startEdit(formId)"
        >
          {{ forms.activeFormName() }}
        </button>
      }
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormTitle,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-title",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "block min-w-0" },
			template: `
    @if (forms.activeFormId(); as formId) {
      @if (edit()?.formId === formId) {
        <input
          #focusTarget
          #nameInput
          type="text"
          aria-label="Form name"
          class="block w-48 max-w-full rounded border border-primary bg-content-background px-1 text-lg font-medium focus-visible:outline-2 focus-visible:outline-primary"
          [value]="edit()?.name ?? ''"
          (blur)="finishEdit(nameInput.value)"
          (keydown)="handleKeydown($event, nameInput.value)"
        />
      } @else {
        <button
          #focusTarget
          type="button"
          class="block max-w-full cursor-pointer truncate rounded px-1 text-lg font-medium hover:underline focus-visible:outline-2 focus-visible:outline-primary"
          [attr.aria-label]="'Rename form: ' + forms.activeFormName()"
          [title]="forms.activeFormName() ?? ''"
          (click)="startEdit(formId)"
        >
          {{ forms.activeFormName() }}
        </button>
      }
    }
  `
		}]
	}],
	propDecorators: { focusTarget: [{
		type: i0.ViewChild,
		args: ["focusTarget", { isSignal: true }]
	}] }
});
var FormToolbarComponent = class FormToolbarComponent {
	formService = inject(CoreFormService);
	libraryService = inject(CoreLibraryService);
	previewDialogService = inject(PreviewDialogService);
	exportDialogService = inject(ExportDialogService);
	hideFormTitle = input(false, ...ngDevMode ? [{ debugName: "hideFormTitle" }] : /* istanbul ignore next */ []);
	activeFormDisplayMode = this.formService.activeFormDisplayMode;
	activeFieldCount = this.formService.activeFieldCount;
	saveStatus = this.formService.saveStatus;
	activeLibraryLabel = this.libraryService.activeLibraryLabel;
	displayModeOptions = [
		{
			label: "Builder",
			value: "form"
		},
		{
			label: "Preview",
			value: "preview"
		},
		{
			label: "JSON",
			value: "json"
		}
	];
	cachedDisplayMode = this.formService.activeFormDisplayMode();
	wasPreviewDialogOpen = false;
	constructor() {
		effect(() => {
			const isOpen = this.previewDialogService.isOpen();
			if (this.wasPreviewDialogOpen && !isOpen) this.restoreDisplayMode();
			this.wasPreviewDialogOpen = isOpen;
		});
	}
	saveButtonLabel = () => {
		switch (this.saveStatus()) {
			case "dirty": return "Save*";
			case "saving": return "Saving...";
			case "error": return "Retry save";
			default: return "Save";
		}
	};
	saveActiveForm() {
		this.formService.saveActiveForm();
	}
	clearModel() {
		this.formService.setActiveModel({});
	}
	openPreviewDialog() {
		this.cachedDisplayMode = this.formService.activeFormDisplayMode();
		this.setActiveFormDisplayMode("preview");
		this.previewDialogService.open();
	}
	restoreDisplayMode() {
		this.formService.setActiveFormDisplayMode(this.cachedDisplayMode);
	}
	setActiveFormDisplayMode(mode) {
		if (this.formService.activeFormDisplayMode() === mode) return;
		this.formService.setActiveFormDisplayMode(mode);
	}
	openExportDialog() {
		this.exportDialogService.open();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormToolbarComponent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormToolbarComponent,
		isStandalone: true,
		selector: "core-form-toolbar",
		inputs: { hideFormTitle: {
			classPropertyName: "hideFormTitle",
			publicName: "hideFormTitle",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "flex min-h-(--panel-header-height) items-start px-4 py-2 md:items-center" },
		ngImport: i0,
		template: `
    <div
      class="flex min-w-0 grow flex-col gap-x-4 gap-y-2 md:flex-row md:flex-wrap md:items-center md:justify-between"
    >
      <div class="min-w-0">
        @if (!hideFormTitle()) {
          <core-form-title />
        }
        <span class="flex items-center gap-1.5 text-sm text-muted-color">
          <span>{{ activeLibraryLabel() }}</span>
          <span>&bull;</span>
          <span>{{ activeFieldCount() }} Field{{ activeFieldCount() === 1 ? '' : 's' }}</span>
        </span>
      </div>
      <ng-content />
      <div class="flex min-w-0 flex-wrap items-center gap-2 md:ml-auto md:justify-end md:gap-4">
        <div
          class="core-segmented"
          role="group"
        >
          @for (option of displayModeOptions; track option.value) {
            <button
              coreButton
              text
              type="button"
              [attr.aria-pressed]="activeFormDisplayMode() === option.value"
              (click)="setActiveFormDisplayMode(option.value)"
            >
              {{ option.label }}
            </button>
          }
        </div>
        <div class="flex items-center gap-2 lg:gap-4">
          <div>
            <div role="group">
              <button
                coreButton
                severity="secondary"
                aria-label="Open preview"
                coreTooltip="Open preview"
                tooltipPosition="above"
                (click)="openPreviewDialog()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  fullscreen
                </i>
              </button>
              <button
                coreButton
                severity="secondary"
                aria-label="Clear Model"
                coreTooltip="Clear Model"
                tooltipPosition="above"
                (click)="clearModel()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  restart_alt
                </i>
              </button>
            </div>
          </div>
          <div>
            <div role="group">
              <button
                coreButton
                severity="secondary"
                aria-label="Export Form"
                coreTooltip="Export Form"
                tooltipPosition="above"
                (click)="openExportDialog()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  download
                </i>
              </button>
              <button
                coreButton
                aria-label="Save Form"
                coreTooltip="Save Form"
                tooltipPosition="above"
                [disabled]="saveStatus() === 'saving'"
                [attr.severity]="saveStatus() !== 'saved' ? 'primary' : 'secondary'"
                (click)="saveActiveForm()"
              >
                <i class="material-symbols-outlined"> save </i>
                <span coreButtonLabel>{{ saveButtonLabel() }}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: FormTitle,
				selector: "core-form-title"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormToolbarComponent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-toolbar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				Tooltip,
				FormTitle
			],
			host: { class: "flex min-h-(--panel-header-height) items-start px-4 py-2 md:items-center" },
			template: `
    <div
      class="flex min-w-0 grow flex-col gap-x-4 gap-y-2 md:flex-row md:flex-wrap md:items-center md:justify-between"
    >
      <div class="min-w-0">
        @if (!hideFormTitle()) {
          <core-form-title />
        }
        <span class="flex items-center gap-1.5 text-sm text-muted-color">
          <span>{{ activeLibraryLabel() }}</span>
          <span>&bull;</span>
          <span>{{ activeFieldCount() }} Field{{ activeFieldCount() === 1 ? '' : 's' }}</span>
        </span>
      </div>
      <ng-content />
      <div class="flex min-w-0 flex-wrap items-center gap-2 md:ml-auto md:justify-end md:gap-4">
        <div
          class="core-segmented"
          role="group"
        >
          @for (option of displayModeOptions; track option.value) {
            <button
              coreButton
              text
              type="button"
              [attr.aria-pressed]="activeFormDisplayMode() === option.value"
              (click)="setActiveFormDisplayMode(option.value)"
            >
              {{ option.label }}
            </button>
          }
        </div>
        <div class="flex items-center gap-2 lg:gap-4">
          <div>
            <div role="group">
              <button
                coreButton
                severity="secondary"
                aria-label="Open preview"
                coreTooltip="Open preview"
                tooltipPosition="above"
                (click)="openPreviewDialog()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  fullscreen
                </i>
              </button>
              <button
                coreButton
                severity="secondary"
                aria-label="Clear Model"
                coreTooltip="Clear Model"
                tooltipPosition="above"
                (click)="clearModel()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  restart_alt
                </i>
              </button>
            </div>
          </div>
          <div>
            <div role="group">
              <button
                coreButton
                severity="secondary"
                aria-label="Export Form"
                coreTooltip="Export Form"
                tooltipPosition="above"
                (click)="openExportDialog()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  download
                </i>
              </button>
              <button
                coreButton
                aria-label="Save Form"
                coreTooltip="Save Form"
                tooltipPosition="above"
                [disabled]="saveStatus() === 'saving'"
                [attr.severity]="saveStatus() !== 'saved' ? 'primary' : 'secondary'"
                (click)="saveActiveForm()"
              >
                <i class="material-symbols-outlined"> save </i>
                <span coreButtonLabel>{{ saveButtonLabel() }}</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { hideFormTitle: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hideFormTitle",
			required: false
		}]
	}] }
});
var FormPanel = class FormPanel {
	hideFormTitle = input(false, ...ngDevMode ? [{ debugName: "hideFormTitle" }] : /* istanbul ignore next */ []);
	formService = inject(CoreFormService);
	previewContent = viewChild(FormPreviewContent, ...ngDevMode ? [{ debugName: "previewContent" }] : /* istanbul ignore next */ []);
	activeFormId = this.formService.activeFormId;
	activeFormFieldsJSON = this.formService.activeFormFieldsJSON;
	activeFormDisplayMode = this.formService.activeFormDisplayMode;
	schema = this.formService.activeSchema;
	activePreviewFormFields$ = toObservable(this.formService.activePreviewFormFields).pipe(debounceTime(100));
	displayMode$ = toObservable(this.activeFormDisplayMode);
	previewFields$ = combineLatest([this.displayMode$, this.activePreviewFormFields$]).pipe(filter(([mode]) => mode === "preview"), map(([, fields]) => fields));
	setActiveFormDisplayMode(mode) {
		if (typeof mode === "string") this.formService.setActiveFormDisplayMode(mode);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormPanel,
		isStandalone: true,
		selector: "core-form-panel",
		inputs: { hideFormTitle: {
			classPropertyName: "hideFormTitle",
			publicName: "hideFormTitle",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "flex flex-col h-full" },
		viewQueries: [{
			propertyName: "previewContent",
			first: true,
			predicate: FormPreviewContent,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    @if (formService.loadingFormId()) {
      <p
        role="status"
        class="shrink-0 px-4 py-2"
      >
        Loading form…
      </p>
    }
    @if (formService.formLoadError(); as error) {
      <div
        role="alert"
        class="flex shrink-0 flex-wrap items-center gap-2 px-4 py-2"
      >
        <span>
          @switch (error.reason) {
            @case ('missing-library') {
              This form needs the unavailable library “{{ error.libraryId }}”.
            }
            @case ('not-found') {
              This form could not be found.
            }
            @case ('recovery-required') {
              Recover the stored forms in the Forms panel before opening this form.
            }
            @case ('invalid-form') {
              This form contains data that could not be opened.
            }
            @default {
              This form could not be loaded. Check your connection and try again.
            }
          }
        </span>
        <button
          coreButton
          type="button"
          size="small"
          (click)="formService.setActiveForm(error.formId)"
        >
          Retry load
        </button>
      </div>
    }
    @if (formService.persistenceError(); as error) {
      <div
        role="alert"
        class="shrink-0 px-4 py-2"
      >
        Could not {{ error.action }}.
        @if (error.failedFormIds?.length) {
          Some forms were not deleted. Review the remaining items in the Forms panel before
          retrying.
        }
      </div>
    }
    @if (activeFormId()) {
      <core-form-toolbar
        class="shrink-0"
        [hideFormTitle]="hideFormTitle()"
      >
        @if (activeFormDisplayMode() !== 'json') {
          <core-preview-device-toolbar
            class="md:mr-auto"
            [scale]="activeFormDisplayMode() === 'preview' ? (previewContent()?.scale() ?? 1) : 1"
          />
        }
      </core-form-toolbar>

      <div class="min-h-0 grow overflow-hidden">
        <div
          role="tabpanel"
          class="block h-full overflow-y-auto px-4 pb-4"
          [hidden]="activeFormDisplayMode() !== 'form'"
        >
          <core-form-builder-content class="min-h-full" />
        </div>
        <div
          role="tabpanel"
          class="block h-full overflow-hidden"
          [hidden]="activeFormDisplayMode() !== 'preview'"
        >
          <core-form-preview-content
            class="h-full"
            [formFields]="(previewFields$ | async) ?? []"
          />
        </div>
        <div
          role="tabpanel"
          class="block h-full px-4 pb-4"
          [hidden]="activeFormDisplayMode() !== 'json'"
        >
          <core-json-content
            class="h-full"
            coreJsonFormat
            [coreJsonSchema]="schema()"
            [ngModel]="activeFormFieldsJSON()"
            [editable]="false"
          />
        </div>
      </div>
    } @else {
      <core-empty-no-form />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FormToolbarComponent,
				selector: "core-form-toolbar",
				inputs: ["hideFormTitle"]
			},
			{
				kind: "component",
				type: FormBuilderContent,
				selector: "core-form-builder-content"
			},
			{
				kind: "component",
				type: EmptyNoForm,
				selector: "core-empty-no-form"
			},
			{
				kind: "component",
				type: JSONContent,
				selector: "core-json-content",
				inputs: ["editable"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: JSONFormatValidator,
				selector: "[coreJsonFormat]"
			},
			{
				kind: "directive",
				type: JSONSchemaValidator,
				selector: "[coreJsonSchema]",
				inputs: ["coreJsonSchema"]
			},
			{
				kind: "component",
				type: FormPreviewContent,
				selector: "core-form-preview-content",
				inputs: ["formFields"]
			},
			{
				kind: "component",
				type: PreviewDeviceToolbar,
				selector: "core-preview-device-toolbar",
				inputs: ["scale"]
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AsyncPipe,
				FormToolbarComponent,
				FormBuilderContent,
				EmptyNoForm,
				JSONContent,
				FormsModule,
				JSONFormatValidator,
				JSONSchemaValidator,
				FormPreviewContent,
				PreviewDeviceToolbar
			],
			host: { class: "flex flex-col h-full" },
			template: `
    @if (formService.loadingFormId()) {
      <p
        role="status"
        class="shrink-0 px-4 py-2"
      >
        Loading form…
      </p>
    }
    @if (formService.formLoadError(); as error) {
      <div
        role="alert"
        class="flex shrink-0 flex-wrap items-center gap-2 px-4 py-2"
      >
        <span>
          @switch (error.reason) {
            @case ('missing-library') {
              This form needs the unavailable library “{{ error.libraryId }}”.
            }
            @case ('not-found') {
              This form could not be found.
            }
            @case ('recovery-required') {
              Recover the stored forms in the Forms panel before opening this form.
            }
            @case ('invalid-form') {
              This form contains data that could not be opened.
            }
            @default {
              This form could not be loaded. Check your connection and try again.
            }
          }
        </span>
        <button
          coreButton
          type="button"
          size="small"
          (click)="formService.setActiveForm(error.formId)"
        >
          Retry load
        </button>
      </div>
    }
    @if (formService.persistenceError(); as error) {
      <div
        role="alert"
        class="shrink-0 px-4 py-2"
      >
        Could not {{ error.action }}.
        @if (error.failedFormIds?.length) {
          Some forms were not deleted. Review the remaining items in the Forms panel before
          retrying.
        }
      </div>
    }
    @if (activeFormId()) {
      <core-form-toolbar
        class="shrink-0"
        [hideFormTitle]="hideFormTitle()"
      >
        @if (activeFormDisplayMode() !== 'json') {
          <core-preview-device-toolbar
            class="md:mr-auto"
            [scale]="activeFormDisplayMode() === 'preview' ? (previewContent()?.scale() ?? 1) : 1"
          />
        }
      </core-form-toolbar>

      <div class="min-h-0 grow overflow-hidden">
        <div
          role="tabpanel"
          class="block h-full overflow-y-auto px-4 pb-4"
          [hidden]="activeFormDisplayMode() !== 'form'"
        >
          <core-form-builder-content class="min-h-full" />
        </div>
        <div
          role="tabpanel"
          class="block h-full overflow-hidden"
          [hidden]="activeFormDisplayMode() !== 'preview'"
        >
          <core-form-preview-content
            class="h-full"
            [formFields]="(previewFields$ | async) ?? []"
          />
        </div>
        <div
          role="tabpanel"
          class="block h-full px-4 pb-4"
          [hidden]="activeFormDisplayMode() !== 'json'"
        >
          <core-json-content
            class="h-full"
            coreJsonFormat
            [coreJsonSchema]="schema()"
            [ngModel]="activeFormFieldsJSON()"
            [editable]="false"
          />
        </div>
      </div>
    } @else {
      <core-empty-no-form />
    }
  `
		}]
	}],
	propDecorators: {
		hideFormTitle: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hideFormTitle",
				required: false
			}]
		}],
		previewContent: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => FormPreviewContent), { isSignal: true }]
		}]
	}
});
var AddFieldService = class AddFieldService {
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	addActions = computed(() => {
		const activeField = this.formService.activeField();
		if (!activeField) return [{
			label: "Add to form",
			icon: "add_circle"
		}];
		const fieldInfo = activeField._info;
		const key = this.fieldService.getKey(activeField) || activeField._info.name;
		const actions = [];
		if (fieldInfo.isParent) actions.push({
			label: `Add inside ${key}`,
			parentId: fieldInfo.id,
			icon: "add_box"
		});
		const index = this.formService.getFieldIndex(fieldInfo.id);
		const parentId = fieldInfo.idPath[fieldInfo.idPath.length - 2];
		actions.push({
			label: `Add before ${key}`,
			parentId,
			index: index >= 0 ? index : void 0,
			icon: "chevron_left"
		});
		actions.push({
			label: `Add after ${key}`,
			parentId,
			index: index >= 0 ? index + 1 : void 0,
			icon: "chevron_right"
		});
		return actions;
	}, ...ngDevMode ? [{ debugName: "addActions" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AddFieldService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AddFieldService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AddFieldService,
	decorators: [{ type: Injectable }]
});
var MenuItems = class MenuItems {
	root = input(false, ...ngDevMode ? [{ debugName: "root" }] : /* istanbul ignore next */ []);
	label = input("", ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	destroyRef = inject(DestroyRef);
	menu = viewChild.required(CdkMenu, ...ngDevMode ? [{ debugName: "menu" }] : /* istanbul ignore next */ []);
	ngAfterViewInit() {
		if (this.root()) {
			this.menu().menuStack.push(this.menu());
			this.menu().focusFirstItem();
			this.menu().menuStack.emptied.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.closed.emit());
		}
	}
	items = input([], ...ngDevMode ? [{ debugName: "items" }] : /* istanbul ignore next */ []);
	itemTemplate = input(...ngDevMode ? [void 0, { debugName: "itemTemplate" }] : /* istanbul ignore next */ []);
	closed = output();
	activate(item) {
		if (!item.items?.length && !item.disabled) {
			item.command?.({ item });
			this.closed.emit();
		}
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MenuItems,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: MenuItems,
		isStandalone: true,
		selector: "core-menu-items",
		inputs: {
			root: {
				classPropertyName: "root",
				publicName: "root",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			items: {
				classPropertyName: "items",
				publicName: "items",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			itemTemplate: {
				classPropertyName: "itemTemplate",
				publicName: "itemTemplate",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { closed: "closed" },
		viewQueries: [{
			propertyName: "menu",
			first: true,
			predicate: CdkMenu,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      cdkMenu
      class="core-root core-menu"
      [attr.aria-label]="label() || null"
      (closed)="root() && closed.emit()"
    >
      @for (item of items(); track $index) {
        @if (item.visible !== false) {
          @if (item.separator) {
            <hr role="separator" />
          } @else {
            <button
              cdkMenuItem
              type="button"
              [cdkMenuItemDisabled]="!!item.disabled"
              [cdkMenuTriggerFor]="item.items?.length ? children : null"
              [class]="item.styleClass"
              [attr.aria-label]="item.label"
              (cdkMenuItemTriggered)="activate(item)"
            >
              @if (itemTemplate(); as template) {
                <ng-container
                  [ngTemplateOutlet]="template"
                  [ngTemplateOutletContext]="{ $implicit: item }"
                />
              } @else {
                @if (item.icon) {
                  <i
                    class="material-symbols-outlined"
                    aria-hidden="true"
                    >{{ item.icon }}</i
                  >
                }
                <span>{{ item.label }}</span>
              }
              @if (item.items?.length) {
                <i
                  class="material-symbols-outlined ml-auto"
                  aria-hidden="true"
                  >chevron_right</i
                >
              }
            </button>
            <ng-template #children>
              <core-menu-items
                [items]="item.items || []"
                [itemTemplate]="itemTemplate()"
                (closed)="closed.emit()"
              />
            </ng-template>
          }
        }
      }
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: MenuItems,
				selector: "core-menu-items",
				inputs: [
					"root",
					"label",
					"items",
					"itemTemplate"
				],
				outputs: ["closed"]
			},
			{
				kind: "directive",
				type: CdkMenu,
				selector: "[cdkMenu]",
				outputs: ["closed"],
				exportAs: ["cdkMenu"]
			},
			{
				kind: "directive",
				type: CdkMenuItem,
				selector: "[cdkMenuItem]",
				inputs: ["cdkMenuItemDisabled", "cdkMenuitemTypeaheadLabel"],
				outputs: ["cdkMenuItemTriggered"],
				exportAs: ["cdkMenuItem"]
			},
			{
				kind: "directive",
				type: CdkMenuTrigger,
				selector: "[cdkMenuTriggerFor]",
				inputs: [
					"cdkMenuTriggerFor",
					"cdkMenuPosition",
					"cdkMenuTriggerData",
					"cdkMenuTriggerTransformOriginOn"
				],
				outputs: ["cdkMenuOpened", "cdkMenuClosed"],
				exportAs: ["cdkMenuTriggerFor"]
			},
			{
				kind: "directive",
				type: NgTemplateOutlet,
				selector: "[ngTemplateOutlet]",
				inputs: [
					"ngTemplateOutletContext",
					"ngTemplateOutlet",
					"ngTemplateOutletInjector"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MenuItems,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-menu-items",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				CdkMenu,
				CdkMenuItem,
				CdkMenuTrigger,
				NgTemplateOutlet
			],
			template: `
    <div
      cdkMenu
      class="core-root core-menu"
      [attr.aria-label]="label() || null"
      (closed)="root() && closed.emit()"
    >
      @for (item of items(); track $index) {
        @if (item.visible !== false) {
          @if (item.separator) {
            <hr role="separator" />
          } @else {
            <button
              cdkMenuItem
              type="button"
              [cdkMenuItemDisabled]="!!item.disabled"
              [cdkMenuTriggerFor]="item.items?.length ? children : null"
              [class]="item.styleClass"
              [attr.aria-label]="item.label"
              (cdkMenuItemTriggered)="activate(item)"
            >
              @if (itemTemplate(); as template) {
                <ng-container
                  [ngTemplateOutlet]="template"
                  [ngTemplateOutletContext]="{ $implicit: item }"
                />
              } @else {
                @if (item.icon) {
                  <i
                    class="material-symbols-outlined"
                    aria-hidden="true"
                    >{{ item.icon }}</i
                  >
                }
                <span>{{ item.label }}</span>
              }
              @if (item.items?.length) {
                <i
                  class="material-symbols-outlined ml-auto"
                  aria-hidden="true"
                  >chevron_right</i
                >
              }
            </button>
            <ng-template #children>
              <core-menu-items
                [items]="item.items || []"
                [itemTemplate]="itemTemplate()"
                (closed)="closed.emit()"
              />
            </ng-template>
          }
        }
      }
    </div>
  `
		}]
	}],
	propDecorators: {
		root: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "root",
				required: false
			}]
		}],
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		menu: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => CdkMenu), { isSignal: true }]
		}],
		items: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "items",
				required: false
			}]
		}],
		itemTemplate: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "itemTemplate",
				required: false
			}]
		}],
		closed: [{
			type: i0.Output,
			args: ["closed"]
		}]
	}
});
var Menu = class Menu {
	model = input([], ...ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []);
	ariaLabel = input("", ...ngDevMode ? [{ debugName: "ariaLabel" }] : /* istanbul ignore next */ []);
	opened = output();
	dismissed = output();
	itemTemplate = contentChild("item", ...ngDevMode ? [{ debugName: "itemTemplate" }] : /* istanbul ignore next */ []);
	body = viewChild.required("body", ...ngDevMode ? [{ debugName: "body" }] : /* istanbul ignore next */ []);
	overlay = inject(Overlay);
	viewContainer = inject(ViewContainerRef);
	open = signal(false, ...ngDevMode ? [{ debugName: "open" }] : /* istanbul ignore next */ []);
	ref;
	trigger;
	get visible() {
		return this.open();
	}
	set visible(value) {
		this.open.set(value);
	}
	toggle(event) {
		if (this.visible) this.hide();
		else this.show(event);
	}
	show(event) {
		this.hide();
		const target = event.currentTarget || event.target;
		if (!(target instanceof HTMLElement)) return;
		this.trigger = target;
		const ref = this.overlay.create({
			positionStrategy: this.overlay.position().flexibleConnectedTo(target).withPositions([{
				originX: "start",
				originY: "bottom",
				overlayX: "start",
				overlayY: "top"
			}, {
				originX: "end",
				originY: "top",
				overlayX: "end",
				overlayY: "bottom"
			}]).withPush(true),
			scrollStrategy: this.overlay.scrollStrategies.reposition(),
			hasBackdrop: true,
			backdropClass: "cdk-overlay-transparent-backdrop"
		});
		this.ref = ref;
		ref.attach(new TemplatePortal(this.body(), this.viewContainer));
		this.open.set(true);
		this.opened.emit();
		ref.backdropClick().subscribe(() => this.hide());
		ref.keydownEvents().subscribe((key) => {
			if (key.key === "Escape") this.hide();
		});
	}
	hide() {
		if (!this.ref) return;
		const ref = this.ref;
		this.ref = void 0;
		ref.dispose();
		this.open.set(false);
		this.dismissed.emit();
		this.trigger?.focus();
	}
	ngOnDestroy() {
		this.hide();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Menu,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: Menu,
		isStandalone: true,
		selector: "core-menu",
		inputs: {
			model: {
				classPropertyName: "model",
				publicName: "model",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			ariaLabel: {
				classPropertyName: "ariaLabel",
				publicName: "ariaLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			opened: "opened",
			dismissed: "dismissed"
		},
		providers: [{
			provide: MENU_STACK,
			useFactory: () => new MenuStack()
		}],
		queries: [{
			propertyName: "itemTemplate",
			first: true,
			predicate: ["item"],
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "body",
			first: true,
			predicate: ["body"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `<ng-template #body
    ><core-menu-items
      [root]="true"
      [label]="ariaLabel()"
      [items]="model()"
      [itemTemplate]="itemTemplate()"
      (closed)="hide()"
  /></ng-template>`,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: MenuItems,
			selector: "core-menu-items",
			inputs: [
				"root",
				"label",
				"items",
				"itemTemplate"
			],
			outputs: ["closed"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Menu,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-menu",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [{
				provide: MENU_STACK,
				useFactory: () => new MenuStack()
			}],
			imports: [MenuItems],
			template: `<ng-template #body
    ><core-menu-items
      [root]="true"
      [label]="ariaLabel()"
      [items]="model()"
      [itemTemplate]="itemTemplate()"
      (closed)="hide()"
  /></ng-template>`
		}]
	}],
	propDecorators: {
		model: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "model",
				required: false
			}]
		}],
		ariaLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "ariaLabel",
				required: false
			}]
		}],
		opened: [{
			type: i0.Output,
			args: ["opened"]
		}],
		dismissed: [{
			type: i0.Output,
			args: ["dismissed"]
		}],
		itemTemplate: [{
			type: i0.ContentChild,
			args: ["item", { isSignal: true }]
		}],
		body: [{
			type: i0.ViewChild,
			args: ["body", { isSignal: true }]
		}]
	}
});
var TypeContainer = class TypeContainer {
	fieldType = input.required(...ngDevMode ? [{ debugName: "fieldType" }] : /* istanbul ignore next */ []);
	preset = input(...ngDevMode ? [void 0, { debugName: "preset" }] : /* istanbul ignore next */ []);
	showActions = input(false, ...ngDevMode ? [{ debugName: "showActions" }] : /* istanbul ignore next */ []);
	addMenuChild = viewChild("addMenu", {
		...ngDevMode ? { debugName: "addMenuChild" } : /* istanbul ignore next */ {},
		read: Menu
	});
	addFieldService = inject(AddFieldService);
	dndService = inject(DNDService);
	formService = inject(CoreFormService);
	addActionsWithCommand = computed(() => {
		return this.addFieldService.addActions().map((action) => ({
			...action,
			command: () => this.addField({ ...action })
		}));
	}, ...ngDevMode ? [{ debugName: "addActionsWithCommand" }] : /* istanbul ignore next */ []);
	dragData = computed(() => {
		return {
			action: DropAction.COPY,
			fieldType: this.fieldType(),
			fieldId: "temp",
			preset: this.preset()
		};
	}, ...ngDevMode ? [{ debugName: "dragData" }] : /* istanbul ignore next */ []);
	onDragStart() {
		this.dndService.setActiveDragData(this.dragData());
	}
	onDragEnd() {
		this.dndService.setActiveDragData(null);
		this.dndService.setActiveDragOverData(null);
	}
	addField(action) {
		this.formService.addField(this.fieldType(), action.parentId, action.index, this.preset());
	}
	openAddMenu(event) {
		this.addMenuChild()?.toggle(event);
		event.preventDefault();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TypeContainer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TypeContainer,
		isStandalone: true,
		selector: "core-type-container",
		inputs: {
			fieldType: {
				classPropertyName: "fieldType",
				publicName: "fieldType",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			preset: {
				classPropertyName: "preset",
				publicName: "preset",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showActions: {
				classPropertyName: "showActions",
				publicName: "showActions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		viewQueries: [{
			propertyName: "addMenuChild",
			first: true,
			predicate: ["addMenu"],
			descendants: true,
			read: Menu,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      class="relative flex cursor-grab items-center justify-between gap-2 rounded-lg py-2 text-left text-color transition-colors focus-within:bg-emphasis hover:bg-emphasis"
      dndEffectAllowed="copy"
      [dndDraggable]="dragData()"
      (dndStart)="onDragStart()"
      (dndEnd)="onDragEnd()"
    >
      <ng-content />
      <span
        class="touch-actions-visible inline-flex shrink-0 gap-1 opacity-0 transition-opacity focus-within:opacity-100"
        [class.opacity-100]="showActions() || addMenuChild()?.visible"
      >
        <core-menu
          #addMenu
          [model]="addActionsWithCommand()"
        >
          <ng-template
            #item
            let-item
          >
            <div class="flex cursor-pointer items-center gap-2 px-3 py-1">
              @if (item.icon) {
                <i class="material-symbols-outlined">{{ item.icon }}</i>
              }
              {{ item.label }}
            </div>
          </ng-template>
        </core-menu>
        <button
          coreButton
          text
          rounded
          class="size-8"
          aria-label="Add Field"
          coreTooltip="Add Field"
          tooltipPosition="above"
          (click)="openAddMenu($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            add
          </i>
        </button>
      </span>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: DndDraggableDirective,
				selector: "[dndDraggable]",
				inputs: [
					"dndDraggable",
					"dndEffectAllowed",
					"dndType",
					"dndDraggingClass",
					"dndDraggingSourceClass",
					"dndHideDraggingSource",
					"dndDraggableDisabledClass",
					"dndDragImageOffsetFunction",
					"dndDisableIf",
					"dndDisableDragIf"
				],
				outputs: [
					"dndStart",
					"dndDrag",
					"dndEnd",
					"dndMoved",
					"dndCopied",
					"dndLinked",
					"dndCanceled"
				]
			},
			{
				kind: "component",
				type: Menu,
				selector: "core-menu",
				inputs: ["model", "ariaLabel"],
				outputs: ["opened", "dismissed"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TypeContainer,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-type-container",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				DndDraggableDirective,
				Menu,
				Tooltip
			],
			template: `
    <div
      class="relative flex cursor-grab items-center justify-between gap-2 rounded-lg py-2 text-left text-color transition-colors focus-within:bg-emphasis hover:bg-emphasis"
      dndEffectAllowed="copy"
      [dndDraggable]="dragData()"
      (dndStart)="onDragStart()"
      (dndEnd)="onDragEnd()"
    >
      <ng-content />
      <span
        class="touch-actions-visible inline-flex shrink-0 gap-1 opacity-0 transition-opacity focus-within:opacity-100"
        [class.opacity-100]="showActions() || addMenuChild()?.visible"
      >
        <core-menu
          #addMenu
          [model]="addActionsWithCommand()"
        >
          <ng-template
            #item
            let-item
          >
            <div class="flex cursor-pointer items-center gap-2 px-3 py-1">
              @if (item.icon) {
                <i class="material-symbols-outlined">{{ item.icon }}</i>
              }
              {{ item.label }}
            </div>
          </ng-template>
        </core-menu>
        <button
          coreButton
          text
          rounded
          class="size-8"
          aria-label="Add Field"
          coreTooltip="Add Field"
          tooltipPosition="above"
          (click)="openAddMenu($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            add
          </i>
        </button>
      </span>
    </div>
  `
		}]
	}],
	propDecorators: {
		fieldType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldType",
				required: true
			}]
		}],
		preset: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "preset",
				required: false
			}]
		}],
		showActions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showActions",
				required: false
			}]
		}],
		addMenuChild: [{
			type: i0.ViewChild,
			args: ["addMenu", {
				read: Menu,
				isSignal: true
			}]
		}]
	}
});
var TypeOption = class TypeOption {
	type = input.required(...ngDevMode ? [{ debugName: "type" }] : /* istanbul ignore next */ []);
	isMouseInside = signal(false, ...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TypeOption,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TypeOption,
		isStandalone: true,
		selector: "core-add-field-type-option",
		inputs: { type: {
			classPropertyName: "type",
			publicName: "type",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: {
			"mouseenter": "isMouseInside.set(true)",
			"mouseleave": "isMouseInside.set(false)"
		} },
		ngImport: i0,
		template: `
    <core-type-container
      [fieldType]="type().name"
      [showActions]="isMouseInside()"
    >
      <span class="flex min-w-0 flex-1 items-center gap-3">
        <span
          class="flex size-12 shrink-0 items-center justify-center rounded-xl border border-surface bg-emphasis"
        >
          <i
            aria-hidden="true"
            class="material-symbols-outlined pointer-events-none"
            [class.opacity-30]="isMouseInside()"
            >{{ isMouseInside() ? 'drag_indicator' : type().materialSymbol }}</i
          >
        </span>
        <span class="min-w-0 [overflow-wrap:anywhere]">
          <span class="block leading-snug font-semibold">{{ type().displayName }}</span>
          @if (type().description) {
            <span class="mt-1 block text-sm leading-snug text-muted-color">
              {{ type().description }}
            </span>
          }
        </span>
      </span>
    </core-type-container>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: TypeContainer,
			selector: "core-type-container",
			inputs: [
				"fieldType",
				"preset",
				"showActions"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TypeOption,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-add-field-type-option",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TypeContainer],
			host: {
				"(mouseenter)": "isMouseInside.set(true)",
				"(mouseleave)": "isMouseInside.set(false)"
			},
			template: `
    <core-type-container
      [fieldType]="type().name"
      [showActions]="isMouseInside()"
    >
      <span class="flex min-w-0 flex-1 items-center gap-3">
        <span
          class="flex size-12 shrink-0 items-center justify-center rounded-xl border border-surface bg-emphasis"
        >
          <i
            aria-hidden="true"
            class="material-symbols-outlined pointer-events-none"
            [class.opacity-30]="isMouseInside()"
            >{{ isMouseInside() ? 'drag_indicator' : type().materialSymbol }}</i
          >
        </span>
        <span class="min-w-0 [overflow-wrap:anywhere]">
          <span class="block leading-snug font-semibold">{{ type().displayName }}</span>
          @if (type().description) {
            <span class="mt-1 block text-sm leading-snug text-muted-color">
              {{ type().description }}
            </span>
          }
        </span>
      </span>
    </core-type-container>
  `
		}]
	}],
	propDecorators: { type: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "type",
			required: true
		}]
	}] }
});
var CategoryOption = class CategoryOption {
	category = input.required(...ngDevMode ? [{ debugName: "category" }] : /* istanbul ignore next */ []);
	isFiltering = input(false, {
		...ngDevMode ? { debugName: "isFiltering" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filteredVisibleFieldNames = input.required(...ngDevMode ? [{ debugName: "filteredVisibleFieldNames" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CategoryOption,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CategoryOption,
		isStandalone: true,
		selector: "core-add-field-category-option",
		inputs: {
			category: {
				classPropertyName: "category",
				publicName: "category",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			isFiltering: {
				classPropertyName: "isFiltering",
				publicName: "isFiltering",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filteredVisibleFieldNames: {
				classPropertyName: "filteredVisibleFieldNames",
				publicName: "filteredVisibleFieldNames",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <h3 class="font-medium text-muted-color">
      {{ category().displayName }}
    </h3>
    <ul class="mt-3 flex flex-col gap-2">
      @for (type of category().children; track type.displayName) {
        <li [class.hidden]="isFiltering() && !filteredVisibleFieldNames().includes(type.name)">
          <core-add-field-type-option [type]="type" />
        </li>
      }
    </ul>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: TypeOption,
			selector: "core-add-field-type-option",
			inputs: ["type"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CategoryOption,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-add-field-category-option",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TypeOption],
			template: `
    <h3 class="font-medium text-muted-color">
      {{ category().displayName }}
    </h3>
    <ul class="mt-3 flex flex-col gap-2">
      @for (type of category().children; track type.displayName) {
        <li [class.hidden]="isFiltering() && !filteredVisibleFieldNames().includes(type.name)">
          <core-add-field-type-option [type]="type" />
        </li>
      }
    </ul>
  `
		}]
	}],
	propDecorators: {
		category: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "category",
				required: true
			}]
		}],
		isFiltering: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFiltering",
				required: false
			}]
		}],
		filteredVisibleFieldNames: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filteredVisibleFieldNames",
				required: true
			}]
		}]
	}
});
var FieldsTabContent = class FieldsTabContent {
	fieldService = inject(CoreFieldService);
	fieldCategoryOptions = computed(() => [...this.fieldService.activeFieldCategoryOptions(), {
		displayName: "Misc",
		children: [this.fieldService.defaultTypeOption]
	}], ...ngDevMode ? [{ debugName: "fieldCategoryOptions" }] : /* istanbul ignore next */ []);
	fieldTypeOptions = computed(() => [...this.fieldService.activeFieldTypeOptions(), this.fieldService.defaultTypeOption], ...ngDevMode ? [{ debugName: "fieldTypeOptions" }] : /* istanbul ignore next */ []);
	filterValue = signal("", ...ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []);
	isFiltering = computed(() => !!this.filterValue(), ...ngDevMode ? [{ debugName: "isFiltering" }] : /* istanbul ignore next */ []);
	filteredVisibleFieldNames = computed(() => {
		const query = this.filterValue().trim().toLowerCase();
		if (!query) return [];
		return this.fieldTypeOptions().filter((option) => option.displayName.toLowerCase().includes(query)).map((option) => option.name);
	}, {
		...ngDevMode ? { debugName: "filteredVisibleFieldNames" } : /* istanbul ignore next */ {},
		equal: (a, b) => a.length === b.length && a.every((val, index) => val === b[index])
	});
	clearFilter() {
		this.filterValue.set("");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldsTabContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldsTabContent,
		isStandalone: true,
		selector: "core-fields-tab-content",
		host: { classAttribute: "add-field-tab-content" },
		providers: [MouseInsideService],
		ngImport: i0,
		template: `
    <div class="min-h-(--sub-panel-header-height) shrink-0 px-4">
      <core-filter
        [(value)]="filterValue"
        (clear)="clearFilter()"
      />
    </div>

    @if (isFiltering() && !filteredVisibleFieldNames().length) {
      <core-empty
        label="No fields found"
        description="Try adjusting your filter criteria."
      />
    } @else {
      <ul class="content-list">
        @for (category of fieldCategoryOptions(); track category.displayName) {
          <li>
            <core-add-field-category-option
              [category]="category"
              [isFiltering]="isFiltering()"
              [filteredVisibleFieldNames]="filteredVisibleFieldNames()"
            />
          </li>
        } @empty {
          <li>
            <core-empty
              label="No Field Configured"
              description="There are no field categories configured. Please check your setup."
            />
          </li>
        }
      </ul>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "component",
				type: Filter,
				selector: "core-filter",
				inputs: ["value", "clearLabel"],
				outputs: ["valueChange", "clear"]
			},
			{
				kind: "component",
				type: CategoryOption,
				selector: "core-add-field-category-option",
				inputs: [
					"category",
					"isFiltering",
					"filteredVisibleFieldNames"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldsTabContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-fields-tab-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [MouseInsideService],
			imports: [
				Empty,
				Filter,
				CategoryOption
			],
			host: { class: "add-field-tab-content" },
			template: `
    <div class="min-h-(--sub-panel-header-height) shrink-0 px-4">
      <core-filter
        [(value)]="filterValue"
        (clear)="clearFilter()"
      />
    </div>

    @if (isFiltering() && !filteredVisibleFieldNames().length) {
      <core-empty
        label="No fields found"
        description="Try adjusting your filter criteria."
      />
    } @else {
      <ul class="content-list">
        @for (category of fieldCategoryOptions(); track category.displayName) {
          <li>
            <core-add-field-category-option
              [category]="category"
              [isFiltering]="isFiltering()"
              [filteredVisibleFieldNames]="filteredVisibleFieldNames()"
            />
          </li>
        } @empty {
          <li>
            <core-empty
              label="No Field Configured"
              description="There are no field categories configured. Please check your setup."
            />
          </li>
        }
      </ul>
    }
  `
		}]
	}]
});
var TypePreset = class TypePreset {
	preset = input.required(...ngDevMode ? [{ debugName: "preset" }] : /* istanbul ignore next */ []);
	isMouseInside = signal(false, ...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TypePreset,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TypePreset,
		isStandalone: true,
		selector: "core-add-field-type-preset",
		inputs: { preset: {
			classPropertyName: "preset",
			publicName: "preset",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { listeners: {
			"mouseenter": "isMouseInside.set(true)",
			"mouseleave": "isMouseInside.set(false)"
		} },
		ngImport: i0,
		template: `
    <core-type-container
      [fieldType]="preset().typeOption!.name"
      [preset]="preset()"
      [showActions]="isMouseInside()"
    >
      <span class="flex min-w-0 flex-1 items-center gap-3">
        <span
          class="flex size-12 shrink-0 items-center justify-center rounded-xl border border-surface bg-emphasis"
        >
          <i
            aria-hidden="true"
            class="material-symbols-outlined pointer-events-none"
            [class.opacity-30]="isMouseInside()"
            >{{ isMouseInside() ? 'drag_indicator' : preset().typeOption!.materialSymbol }}</i
          >
        </span>
        <span class="min-w-0 [overflow-wrap:anywhere]">
          <span class="block leading-snug font-semibold">{{ preset().displayName }}</span>
          @if (preset().typeOption?.description) {
            <span class="mt-1 block text-sm leading-snug text-muted-color">
              {{ preset().typeOption!.description }}
            </span>
          }
        </span>
      </span>
    </core-type-container>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: TypeContainer,
			selector: "core-type-container",
			inputs: [
				"fieldType",
				"preset",
				"showActions"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TypePreset,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-add-field-type-preset",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TypeContainer],
			host: {
				"(mouseenter)": "isMouseInside.set(true)",
				"(mouseleave)": "isMouseInside.set(false)"
			},
			template: `
    <core-type-container
      [fieldType]="preset().typeOption!.name"
      [preset]="preset()"
      [showActions]="isMouseInside()"
    >
      <span class="flex min-w-0 flex-1 items-center gap-3">
        <span
          class="flex size-12 shrink-0 items-center justify-center rounded-xl border border-surface bg-emphasis"
        >
          <i
            aria-hidden="true"
            class="material-symbols-outlined pointer-events-none"
            [class.opacity-30]="isMouseInside()"
            >{{ isMouseInside() ? 'drag_indicator' : preset().typeOption!.materialSymbol }}</i
          >
        </span>
        <span class="min-w-0 [overflow-wrap:anywhere]">
          <span class="block leading-snug font-semibold">{{ preset().displayName }}</span>
          @if (preset().typeOption?.description) {
            <span class="mt-1 block text-sm leading-snug text-muted-color">
              {{ preset().typeOption!.description }}
            </span>
          }
        </span>
      </span>
    </core-type-container>
  `
		}]
	}],
	propDecorators: { preset: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "preset",
			required: true
		}]
	}] }
});
var CategoryPreset = class CategoryPreset {
	category = input.required(...ngDevMode ? [{ debugName: "category" }] : /* istanbul ignore next */ []);
	isFiltering = input(false, {
		...ngDevMode ? { debugName: "isFiltering" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filteredVisibleFieldIds = input.required(...ngDevMode ? [{ debugName: "filteredVisibleFieldIds" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CategoryPreset,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CategoryPreset,
		isStandalone: true,
		selector: "core-add-field-category-preset",
		inputs: {
			category: {
				classPropertyName: "category",
				publicName: "category",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			isFiltering: {
				classPropertyName: "isFiltering",
				publicName: "isFiltering",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filteredVisibleFieldIds: {
				classPropertyName: "filteredVisibleFieldIds",
				publicName: "filteredVisibleFieldIds",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <h3 class="font-medium text-muted-color">
      {{ category().displayName }}
    </h3>
    <ul class="mt-3 flex flex-col gap-2">
      @for (preset of category().children; track preset.displayName) {
        <li [class.hidden]="isFiltering() && !filteredVisibleFieldIds().includes(preset.id)">
          <core-add-field-type-preset [preset]="preset" />
        </li>
      }
    </ul>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: TypePreset,
			selector: "core-add-field-type-preset",
			inputs: ["preset"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CategoryPreset,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-add-field-category-preset",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [TypePreset],
			template: `
    <h3 class="font-medium text-muted-color">
      {{ category().displayName }}
    </h3>
    <ul class="mt-3 flex flex-col gap-2">
      @for (preset of category().children; track preset.displayName) {
        <li [class.hidden]="isFiltering() && !filteredVisibleFieldIds().includes(preset.id)">
          <core-add-field-type-preset [preset]="preset" />
        </li>
      }
    </ul>
  `
		}]
	}],
	propDecorators: {
		category: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "category",
				required: true
			}]
		}],
		isFiltering: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFiltering",
				required: false
			}]
		}],
		filteredVisibleFieldIds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filteredVisibleFieldIds",
				required: true
			}]
		}]
	}
});
var PresetsTabContent = class PresetsTabContent {
	fieldService = inject(CoreFieldService);
	fieldCategoryPresets = this.fieldService.fieldCategoryPresets;
	filterValue = signal("", ...ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []);
	isFiltering = computed(() => !!this.filterValue(), ...ngDevMode ? [{ debugName: "isFiltering" }] : /* istanbul ignore next */ []);
	filteredVisibleFieldIds = computed(() => {
		const query = this.filterValue().trim().toLowerCase();
		if (!query) return [];
		return this.fieldCategoryPresets().flatMap((option) => option.children).filter((option) => option.displayName.toLowerCase().includes(query) || option.typeOption?.displayName.toLowerCase().includes(query)).map((option) => option.id);
	}, {
		...ngDevMode ? { debugName: "filteredVisibleFieldIds" } : /* istanbul ignore next */ {},
		equal: (a, b) => a.length === b.length && a.every((val, index) => val === b[index])
	});
	clearFilter() {
		this.filterValue.set("");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PresetsTabContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PresetsTabContent,
		isStandalone: true,
		selector: "core-presets-tab-content",
		host: { classAttribute: "add-field-tab-content" },
		providers: [MouseInsideService],
		ngImport: i0,
		template: `
    <div class="min-h-(--sub-panel-header-height) shrink-0 px-4">
      <core-filter
        [(value)]="filterValue"
        (clear)="clearFilter()"
      />
    </div>

    @if (isFiltering() && !filteredVisibleFieldIds().length) {
      <core-empty
        label="No fields found"
        description="Try adjusting your filter criteria."
      />
    } @else {
      <ul class="content-list">
        @for (category of fieldCategoryPresets(); track category.displayName) {
          <li>
            <core-add-field-category-preset
              [category]="category"
              [isFiltering]="isFiltering()"
              [filteredVisibleFieldIds]="filteredVisibleFieldIds()"
            />
          </li>
        } @empty {
          <li>
            <core-empty
              label="No Field Configured"
              description="There are no field categories configured. Please check your setup."
            />
          </li>
        }
      </ul>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "component",
				type: Filter,
				selector: "core-filter",
				inputs: ["value", "clearLabel"],
				outputs: ["valueChange", "clear"]
			},
			{
				kind: "component",
				type: CategoryPreset,
				selector: "core-add-field-category-preset",
				inputs: [
					"category",
					"isFiltering",
					"filteredVisibleFieldIds"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PresetsTabContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-presets-tab-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [MouseInsideService],
			imports: [
				Empty,
				Filter,
				CategoryPreset
			],
			host: { class: "add-field-tab-content" },
			template: `
    <div class="min-h-(--sub-panel-header-height) shrink-0 px-4">
      <core-filter
        [(value)]="filterValue"
        (clear)="clearFilter()"
      />
    </div>

    @if (isFiltering() && !filteredVisibleFieldIds().length) {
      <core-empty
        label="No fields found"
        description="Try adjusting your filter criteria."
      />
    } @else {
      <ul class="content-list">
        @for (category of fieldCategoryPresets(); track category.displayName) {
          <li>
            <core-add-field-category-preset
              [category]="category"
              [isFiltering]="isFiltering()"
              [filteredVisibleFieldIds]="filteredVisibleFieldIds()"
            />
          </li>
        } @empty {
          <li>
            <core-empty
              label="No Field Configured"
              description="There are no field categories configured. Please check your setup."
            />
          </li>
        }
      </ul>
    }
  `
		}]
	}]
});
var AddFieldPanel = class AddFieldPanel {
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	activeFormId = this.formService.activeFormId;
	activeField = this.formService.activeField;
	fieldCategoryPresets = this.fieldService.fieldCategoryPresets;
	activeTab = inject(PanelService).activeAddFieldTab;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: AddFieldPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: AddFieldPanel,
		isStandalone: true,
		selector: "core-add-field-panel",
		host: { classAttribute: "overflow-hidden h-full block" },
		providers: [AddFieldService],
		ngImport: i0,
		template: `
    <core-panel-header
      header="Add Field"
      subHeader="Add or drag a field into the form"
    />
    @if (activeFormId()) {
      <mat-tab-group
        class="core-tabs min-h-0 flex-1"
        animationDuration="0ms"
        [preserveContent]="true"
        [selectedIndex]="['fields', 'presets'].indexOf(activeTab())"
        (selectedTabChange)="activeTab.set($event.index === 0 ? 'fields' : 'presets')"
        ><mat-tab
          ><ng-template mat-tab-label>
            <i
              class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
              aria-hidden="true"
              >ad</i
            >
            <span>Field</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col gap-2 overflow-hidden">
            <core-fields-tab-content /></div></mat-tab
        ><mat-tab
          ><ng-template mat-tab-label>
            <i
              class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
              aria-hidden="true"
              >tune</i
            >
            <span>Preset</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col overflow-hidden">
            <core-presets-tab-content /></div></mat-tab
      ></mat-tab-group>
    } @else {
      <core-empty-no-form />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: MatTabsModule
			},
			{
				kind: "directive",
				type: i1$1.MatTabLabel,
				selector: "[mat-tab-label], [matTabLabel]"
			},
			{
				kind: "component",
				type: i1$1.MatTab,
				selector: "mat-tab",
				inputs: [
					"disabled",
					"label",
					"aria-label",
					"aria-labelledby",
					"labelClass",
					"bodyClass",
					"id"
				],
				exportAs: ["matTab"]
			},
			{
				kind: "component",
				type: i1$1.MatTabGroup,
				selector: "mat-tab-group",
				inputs: [
					"color",
					"fitInkBarToContent",
					"mat-stretch-tabs",
					"mat-align-tabs",
					"dynamicHeight",
					"selectedIndex",
					"headerPosition",
					"animationDuration",
					"contentTabIndex",
					"disablePagination",
					"disableRipple",
					"preserveContent",
					"backgroundColor",
					"aria-label",
					"aria-labelledby"
				],
				outputs: [
					"selectedIndexChange",
					"focusChange",
					"animationDone",
					"selectedTabChange"
				],
				exportAs: ["matTabGroup"]
			},
			{
				kind: "component",
				type: EmptyNoForm,
				selector: "core-empty-no-form"
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			},
			{
				kind: "component",
				type: FieldsTabContent,
				selector: "core-fields-tab-content"
			},
			{
				kind: "component",
				type: PresetsTabContent,
				selector: "core-presets-tab-content"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: AddFieldPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-add-field-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [AddFieldService],
			imports: [
				MatTabsModule,
				EmptyNoForm,
				PanelHeader,
				FieldsTabContent,
				PresetsTabContent
			],
			host: { class: "overflow-hidden h-full block" },
			template: `
    <core-panel-header
      header="Add Field"
      subHeader="Add or drag a field into the form"
    />
    @if (activeFormId()) {
      <mat-tab-group
        class="core-tabs min-h-0 flex-1"
        animationDuration="0ms"
        [preserveContent]="true"
        [selectedIndex]="['fields', 'presets'].indexOf(activeTab())"
        (selectedTabChange)="activeTab.set($event.index === 0 ? 'fields' : 'presets')"
        ><mat-tab
          ><ng-template mat-tab-label>
            <i
              class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
              aria-hidden="true"
              >ad</i
            >
            <span>Field</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col gap-2 overflow-hidden">
            <core-fields-tab-content /></div></mat-tab
        ><mat-tab
          ><ng-template mat-tab-label>
            <i
              class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
              aria-hidden="true"
              >tune</i
            >
            <span>Preset</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col overflow-hidden">
            <core-presets-tab-content /></div></mat-tab
      ></mat-tab-group>
    } @else {
      <core-empty-no-form />
    }
  `
		}]
	}]
});
var Panel = class Panel {
	header = input("", ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	toggleable = input(false, {
		...ngDevMode ? { debugName: "toggleable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	collapsed = model(false, ...ngDevMode ? [{ debugName: "collapsed" }] : /* istanbul ignore next */ []);
	pt = input({}, ...ngDevMode ? [{ debugName: "pt" }] : /* istanbul ignore next */ []);
	headerTemplate = contentChild("header", ...ngDevMode ? [{ debugName: "headerTemplate" }] : /* istanbul ignore next */ []);
	actions = contentChild("icons", ...ngDevMode ? [{ debugName: "actions" }] : /* istanbul ignore next */ []);
	contentId = `core-panel-${crypto.randomUUID()}`;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Panel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Panel,
		isStandalone: true,
		selector: "core-property-panel",
		inputs: {
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			toggleable: {
				classPropertyName: "toggleable",
				publicName: "toggleable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			collapsed: {
				classPropertyName: "collapsed",
				publicName: "collapsed",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pt: {
				classPropertyName: "pt",
				publicName: "pt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { collapsed: "collapsedChange" },
		host: { classAttribute: "core-property-panel" },
		queries: [{
			propertyName: "headerTemplate",
			first: true,
			predicate: ["header"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "actions",
			first: true,
			predicate: ["icons"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      class="core-property-panel-header"
      [class]="pt().header?.class"
      [style]="pt().header?.style"
    >
      @if (toggleable()) {
        <button
          class="core-property-panel-toggle"
          type="button"
          [attr.aria-expanded]="!collapsed()"
          [attr.aria-controls]="contentId"
          (click)="collapsed.set(!collapsed())"
        >
          <span [id]="contentId + '-title'"><ng-container [ngTemplateOutlet]="title" /></span>
          <i
            class="material-symbols-outlined"
            aria-hidden="true"
            >{{ collapsed() ? 'expand_more' : 'expand_less' }}</i
          >
        </button>
      } @else {
        <div class="font-semibold">
          <span [id]="contentId + '-title'"><ng-container [ngTemplateOutlet]="title" /></span>
        </div>
      }
      <ng-container [ngTemplateOutlet]="actions() || null" />
    </div>
    <div
      class="core-property-panel-content"
      role="region"
      [class]="pt().content?.class"
      [style]="pt().content?.style"
      [attr.aria-labelledby]="contentId + '-title'"
      [id]="contentId"
      [hidden]="toggleable() && collapsed()"
    >
      <ng-content />
    </div>
    <ng-template #title>
      @if (headerTemplate(); as template) {
        <ng-container [ngTemplateOutlet]="template" />
      } @else {
        {{ header() }}
      }
    </ng-template>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Panel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-property-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			host: { class: "core-property-panel" },
			template: `
    <div
      class="core-property-panel-header"
      [class]="pt().header?.class"
      [style]="pt().header?.style"
    >
      @if (toggleable()) {
        <button
          class="core-property-panel-toggle"
          type="button"
          [attr.aria-expanded]="!collapsed()"
          [attr.aria-controls]="contentId"
          (click)="collapsed.set(!collapsed())"
        >
          <span [id]="contentId + '-title'"><ng-container [ngTemplateOutlet]="title" /></span>
          <i
            class="material-symbols-outlined"
            aria-hidden="true"
            >{{ collapsed() ? 'expand_more' : 'expand_less' }}</i
          >
        </button>
      } @else {
        <div class="font-semibold">
          <span [id]="contentId + '-title'"><ng-container [ngTemplateOutlet]="title" /></span>
        </div>
      }
      <ng-container [ngTemplateOutlet]="actions() || null" />
    </div>
    <div
      class="core-property-panel-content"
      role="region"
      [class]="pt().content?.class"
      [style]="pt().content?.style"
      [attr.aria-labelledby]="contentId + '-title'"
      [id]="contentId"
      [hidden]="toggleable() && collapsed()"
    >
      <ng-content />
    </div>
    <ng-template #title>
      @if (headerTemplate(); as template) {
        <ng-container [ngTemplateOutlet]="template" />
      } @else {
        {{ header() }}
      }
    </ng-template>
  `
		}]
	}],
	propDecorators: {
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		toggleable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "toggleable",
				required: false
			}]
		}],
		collapsed: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "collapsed",
				required: false
			}]
		}, {
			type: i0.Output,
			args: ["collapsedChange"]
		}],
		pt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pt",
				required: false
			}]
		}],
		headerTemplate: [{
			type: i0.ContentChild,
			args: ["header", { isSignal: true }]
		}],
		actions: [{
			type: i0.ContentChild,
			args: ["icons", { isSignal: true }]
		}]
	}
});
var BaseProperty = class BaseProperty {
	property = input.required({
		...ngDevMode ? { debugName: "property" } : /* istanbul ignore next */ {},
		transform: (p) => this._getValidProperty(p)
	});
	path = input([], ...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	target = input(void 0, ...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	remove = output();
	keyChanged = output();
	targetChanged = output();
	currentValue = computed(() => this.path().length ? get(this.target(), this.path(), this.defaultValue) : this.target() ?? this.defaultValue, ...ngDevMode ? [{ debugName: "currentValue" }] : /* istanbul ignore next */ []);
	onKeyChanged(newKey) {
		this._modifyKey(this.path(), [...this.path().slice(0, -1), newKey]);
	}
	_modifyKey(currPath, newPath) {
		const change = {
			type: PropertyChangeType.KEY,
			path: currPath,
			newPath
		};
		this.targetChanged.emit(change);
	}
	_modifyValue(value, path = this.path()) {
		const change = {
			type: PropertyChangeType.VALUE,
			path,
			value
		};
		this.targetChanged.emit(change);
	}
	_clear(path = this.path()) {
		const change = {
			type: PropertyChangeType.CLEAR,
			path
		};
		this.targetChanged.emit(change);
	}
	_isBaseProperty(x) {
		return typeof x === "object" && x !== null && "type" in x && x.type === this.propertyType;
	}
	_getValidProperty(x) {
		if (this._isValidProperty(x)) return x;
		throw new Error(`Invalid property config for ${this.constructor.name}`);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BaseProperty,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: BaseProperty,
		isStandalone: true,
		inputs: {
			property: {
				classPropertyName: "property",
				publicName: "property",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			path: {
				classPropertyName: "path",
				publicName: "path",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			remove: "remove",
			keyChanged: "keyChanged",
			targetChanged: "targetChanged"
		},
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BaseProperty,
	decorators: [{ type: Directive }],
	propDecorators: {
		property: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "property",
				required: true
			}]
		}],
		path: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "path",
				required: false
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		remove: [{
			type: i0.Output,
			args: ["remove"]
		}],
		keyChanged: [{
			type: i0.Output,
			args: ["keyChanged"]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}]
	}
});
var ArrayProperty = class ArrayProperty extends BaseProperty {
	defaultValue = [];
	propertyType = PropertyType.ARRAY;
	childProperties = computed(() => this.populateChildren(), ...ngDevMode ? [{ debugName: "childProperties" }] : /* istanbul ignore next */ []);
	onAddChild(type, dataType) {
		const childValue = getDefaultPropertyValue(type || this.property().childProperty?.type || PropertyType.INPUT, dataType);
		const newValue = [...this.currentValue(), childValue];
		this._modifyValue(newValue);
	}
	onRemoveChild(index) {
		const newValue = this.currentValue().filter((_, i) => i !== index);
		this._modifyValue(newValue);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	populateChildren() {
		return this.currentValue().map((childValue, index) => {
			let childProperty;
			if (this.property().childProperty) childProperty = structuredClone(this.property().childProperty);
			else childProperty = getDefaultPropertyFromValue(childValue ?? "");
			if (childProperty) {
				childProperty.label = `${childProperty.label ?? "Item"} ${index + 1}`;
				childProperty.key = index + "";
				childProperty.isKeyEditable = false;
			}
			return childProperty;
		}).filter((v) => !!v);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ArrayProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ArrayProperty,
		isStandalone: true,
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ArrayProperty,
	decorators: [{ type: Directive }]
});
var BooleanProperty = class BooleanProperty extends BaseProperty {
	defaultValue = null;
	propertyType = PropertyType.BOOLEAN;
	onClear() {
		this._clear();
	}
	onValueChange(value) {
		if (value === null && this.property().clearOnEmpty !== false) this._clear();
		else if (value === false && this.property().clearOnFalse !== false) this._clear();
		else this._modifyValue(value);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BooleanProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: BooleanProperty,
		isStandalone: true,
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BooleanProperty,
	decorators: [{ type: Directive }]
});
var FieldPropertyWrapper = class FieldPropertyWrapper {
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	description = input(...ngDevMode ? [void 0, { debugName: "description" }] : /* istanbul ignore next */ []);
	labelForId = input(...ngDevMode ? [void 0, { debugName: "labelForId" }] : /* istanbul ignore next */ []);
	isClearable = input(false, {
		...ngDevMode ? { debugName: "isClearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	clear = output();
	isMouseInside = signal(false, ...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldPropertyWrapper,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldPropertyWrapper,
		isStandalone: true,
		selector: "core-field-property-wrapper",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			description: {
				classPropertyName: "description",
				publicName: "description",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			labelForId: {
				classPropertyName: "labelForId",
				publicName: "labelForId",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isClearable: {
				classPropertyName: "isClearable",
				publicName: "isClearable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { clear: "clear" },
		host: {
			listeners: {
				"mouseenter": "isMouseInside.set(true)",
				"mouseleave": "isMouseInside.set(false)"
			},
			classAttribute: "flex flex-col gap-0.5"
		},
		ngImport: i0,
		template: `
    <div class="flex items-center justify-between gap-2">
      <label
        class="text-sm"
        tooltipPosition="left"
        [for]="labelForId()"
        [coreTooltip]="description()"
      >
        {{ label() }}
      </label>

      @if (isClearable()) {
        <button
          coreButton
          text
          class="touch-actions-visible size-5 opacity-0 transition-opacity"
          rounded
          severity="danger"
          aria-label="Clear"
          coreTooltip="Clear"
          tooltipPosition="above"
          [class.opacity-100]="isMouseInside()"
          (click)="clear.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            style="font-size: 1rem"
          >
            close
          </i>
        </button>
      }
    </div>

    <div class="flex items-center gap-2">
      <span class="inline-flex min-h-10 min-w-0 grow items-center gap-2">
        <ng-content />
      </span>
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Tooltip,
			selector: "[coreTooltip]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldPropertyWrapper,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-property-wrapper",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Tooltip],
			host: {
				class: "flex flex-col gap-0.5",
				"(mouseenter)": "isMouseInside.set(true)",
				"(mouseleave)": "isMouseInside.set(false)"
			},
			template: `
    <div class="flex items-center justify-between gap-2">
      <label
        class="text-sm"
        tooltipPosition="left"
        [for]="labelForId()"
        [coreTooltip]="description()"
      >
        {{ label() }}
      </label>

      @if (isClearable()) {
        <button
          coreButton
          text
          class="touch-actions-visible size-5 opacity-0 transition-opacity"
          rounded
          severity="danger"
          aria-label="Clear"
          coreTooltip="Clear"
          tooltipPosition="above"
          [class.opacity-100]="isMouseInside()"
          (click)="clear.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            style="font-size: 1rem"
          >
            close
          </i>
        </button>
      }
    </div>

    <div class="flex items-center gap-2">
      <span class="inline-flex min-h-10 min-w-0 grow items-center gap-2">
        <ng-content />
      </span>
    </div>
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		description: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "description",
				required: false
			}]
		}],
		labelForId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "labelForId",
				required: false
			}]
		}],
		isClearable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isClearable",
				required: false
			}]
		}],
		clear: [{
			type: i0.Output,
			args: ["clear"]
		}]
	}
});
var FieldBooleanProperty = class FieldBooleanProperty extends BooleanProperty {
	switchId = `boolean-property-switch-${Math.random().toString(36).substring(2, 15)}`;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldBooleanProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FieldBooleanProperty,
		isStandalone: true,
		selector: "core-field-boolean-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="switchId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <mat-slide-toggle
        [id]="switchId"
        [aria-label]="property().label || 'Enabled'"
        [ngModel]="currentValue()"
        (ngModelChange)="onValueChange($event)"
      />
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: MatSlideToggle,
				selector: "mat-slide-toggle",
				inputs: [
					"name",
					"id",
					"labelPosition",
					"aria-label",
					"aria-labelledby",
					"aria-describedby",
					"required",
					"color",
					"disabled",
					"fullWidth",
					"disableRipple",
					"tabIndex",
					"checked",
					"hideIcon",
					"disabledInteractive"
				],
				outputs: ["change", "toggleChange"],
				exportAs: ["matSlideToggle"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldBooleanProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-boolean-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				MatSlideToggle,
				FieldPropertyWrapper
			],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="switchId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <mat-slide-toggle
        [id]="switchId"
        [aria-label]="property().label || 'Enabled'"
        [ngModel]="currentValue()"
        (ngModelChange)="onValueChange($event)"
      />
    </core-field-property-wrapper>
  `
		}]
	}]
});
var InputProperty = class InputProperty extends BaseProperty {
	defaultValue = null;
	propertyType = PropertyType.INPUT;
	onClear() {
		this._clear();
	}
	onValueChange(value) {
		if (this._isEmpty(value) && this.property().clearOnEmpty !== false) this._clear();
		else this._modifyValue(value);
	}
	_isEmpty(value) {
		return value === null || value === "";
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: InputProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: InputProperty,
		isStandalone: true,
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: InputProperty,
	decorators: [{ type: Directive }]
});
var FieldInputProperty = class FieldInputProperty extends InputProperty {
	inputId = `input-property-input-${Math.random().toString(36).substring(2, 15)}`;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldInputProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldInputProperty,
		isStandalone: true,
		selector: "core-field-input-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      @if (property().dataType === 'number') {
        <input
          class="field-property-control"
          coreInput
          type="number"
          [id]="inputId"
          [placeholder]="property().placeholder || ''"
          [ngModel]="currentValue()"
          (ngModelChange)="onValueChange($event)"
        />
      } @else {
        <input
          class="field-property-control"
          coreInput
          [id]="inputId"
          [type]="property().dataType"
          [placeholder]="property().placeholder || ''"
          [ngModel]="currentValue()"
          (ngModelChange)="onValueChange($event)"
        />
      }
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NumberValueAccessor,
				selector: "input[type=number]:not([ngNoCva])[formControlName],input[type=number]:not([ngNoCva])[formControl],input[type=number]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldInputProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-input-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule, FieldPropertyWrapper],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      @if (property().dataType === 'number') {
        <input
          class="field-property-control"
          coreInput
          type="number"
          [id]="inputId"
          [placeholder]="property().placeholder || ''"
          [ngModel]="currentValue()"
          (ngModelChange)="onValueChange($event)"
        />
      } @else {
        <input
          class="field-property-control"
          coreInput
          [id]="inputId"
          [type]="property().dataType"
          [placeholder]="property().placeholder || ''"
          [ngModel]="currentValue()"
          (ngModelChange)="onValueChange($event)"
        />
      }
    </core-field-property-wrapper>
  `
		}]
	}]
});
var ObjectProperty = class ObjectProperty extends BaseProperty {
	defaultValue = {};
	propertyType = PropertyType.OBJECT;
	childProperties = computed(() => this.populateChildren(), ...ngDevMode ? [{ debugName: "childProperties" }] : /* istanbul ignore next */ []);
	onAddChild(type, dataType) {
		const childValue = getDefaultPropertyValue(type, dataType);
		this._modifyValue(childValue, [...this.path(), ""]);
	}
	onRemoveChild(index) {
		const childProperty = this.childProperties()[index];
		if (childProperty.key !== void 0) this._clear([...this.path(), childProperty.key + ""]);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x) && "childProperties" in x && Array.isArray(x.childProperties);
	}
	populateChildren() {
		if (this.property().populateChildrenFromTarget) return this.populateChildrenFromTarget();
		return this.populateChildrenFromProperty();
	}
	populateChildrenFromProperty() {
		return [...this.property().childProperties];
	}
	populateChildrenFromTarget() {
		const newChildProperties = [];
		Object.entries(this.currentValue()).forEach(([key, value]) => {
			const childProperty = getDefaultPropertyFromValue(value, key);
			if (childProperty) newChildProperties.push(childProperty);
		});
		return newChildProperties;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ObjectProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ObjectProperty,
		isStandalone: true,
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ObjectProperty,
	decorators: [{ type: Directive }]
});
var FieldSelectProperty = class FieldSelectProperty extends BaseProperty {
	isClearable = input(true, {
		...ngDevMode ? { debugName: "isClearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	selectId = `select-property-select-${Math.random().toString(36).substring(2, 15)}`;
	defaultValue = null;
	propertyType = PropertyType.SELECT;
	controlValue = computed(() => this.currentValue(), ...ngDevMode ? [{ debugName: "controlValue" }] : /* istanbul ignore next */ []);
	onClear() {
		this._clear();
	}
	onValueChange(value) {
		if (value === null && this.property().clearOnEmpty !== false) this._clear();
		else this._modifyValue(value);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x) && "options" in x && Array.isArray(x.options) && x.options.every(isValidOption$1);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldSelectProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldSelectProperty,
		isStandalone: true,
		selector: "core-field-select-property",
		inputs: { isClearable: {
			classPropertyName: "isClearable",
			publicName: "isClearable",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="selectId"
      [isClearable]="isClearable()"
      (clear)="onClear()"
    >
      <mat-select
        class="field-property-control"
        [id]="selectId"
        [aria-label]="property().label || 'Select option'"
        [placeholder]="property().placeholder || 'Select option'"
        [ngModel]="controlValue()"
        (ngModelChange)="onValueChange($event)"
      >
        @for (option of property().options; track $index) {
          <mat-option [value]="option.value">{{ option.label }}</mat-option>
        }
      </mat-select>
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldSelectProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-select-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				MatSelect,
				MatOption,
				FieldPropertyWrapper
			],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="selectId"
      [isClearable]="isClearable()"
      (clear)="onClear()"
    >
      <mat-select
        class="field-property-control"
        [id]="selectId"
        [aria-label]="property().label || 'Select option'"
        [placeholder]="property().placeholder || 'Select option'"
        [ngModel]="controlValue()"
        (ngModelChange)="onValueChange($event)"
      >
        @for (option of property().options; track $index) {
          <mat-option [value]="option.value">{{ option.label }}</mat-option>
        }
      </mat-select>
    </core-field-property-wrapper>
  `
		}]
	}],
	propDecorators: { isClearable: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "isClearable",
			required: false
		}]
	}] }
});
function isValidOption$1(x) {
	return typeof x === "object" && x !== null && "label" in x && "value" in x && ["string", "number"].includes(typeof x.value);
}
var FieldObjectProperty = class FieldObjectProperty extends ObjectProperty {
	isCollapsible = input(true, {
		...ngDevMode ? { debugName: "isCollapsible" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	isCollapsed = signal(true, ...ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []);
	combinedIsCollpasible = computed(() => typeof this.property().isCollapsible === "boolean" ? this.property().isCollapsible : this.isCollapsible(), ...ngDevMode ? [{ debugName: "combinedIsCollpasible" }] : /* istanbul ignore next */ []);
	panelPT = computed(() => ({ header: { class: this.isCollapsible() ? "cursor-pointer" : "" } }), ...ngDevMode ? [{ debugName: "panelPT" }] : /* istanbul ignore next */ []);
	typeofProperty = PropertyType;
	getChildPath = getChildPath;
	trackByPropertyKey = trackByPropertyKey;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldObjectProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldObjectProperty,
		isStandalone: true,
		selector: "core-field-object-property",
		inputs: { isCollapsible: {
			classPropertyName: "isCollapsible",
			publicName: "isCollapsible",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "flex flex-col gap-1" },
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT()"
      [toggleable]="combinedIsCollpasible()"
      [collapsed]="combinedIsCollpasible() ? isCollapsed() : false"
      (collapsedChange)="isCollapsed.set(!!$event)"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
        </span>
      </ng-template>
      @if (combinedIsCollpasible()) {
        <ng-template #headericons>
          <i class="material-symbols-outlined">{{
            isCollapsed() ? 'expand_more' : 'expand_less'
          }}</i>
        </ng-template>
      }
      @if (property().isRemovable) {
        <ng-template #icons>
          <button
            coreButton
            text
            rounded
            severity="danger"
            aria-label="Remove"
            coreTooltip="Remove"
            tooltipPosition="above"
            (click)="remove.emit()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              >remove</i
            >
          </button>
        </ng-template>
      }
      <div class="field-property-grid">
        @for (child of childProperties(); track trackByPropertyKey($index, child)) {
          <div
            [class.col-span-1]="child.colSpan === 1"
            [class.col-span-2]="child.colSpan !== 1"
          >
            @switch (child.type) {
              @case (typeofProperty.BOOLEAN) {
                <core-field-boolean-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.INPUT) {
                <core-field-input-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.SELECT) {
                <core-field-select-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
            }
          </div>
        }
      </div>
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldSelectProperty,
				selector: "core-field-select-property",
				inputs: ["isClearable"]
			},
			{
				kind: "component",
				type: FieldBooleanProperty,
				selector: "core-field-boolean-property"
			},
			{
				kind: "component",
				type: FieldInputProperty,
				selector: "core-field-input-property"
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldObjectProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-object-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldSelectProperty,
				FieldBooleanProperty,
				FieldInputProperty,
				Panel,
				Tooltip
			],
			host: { class: "flex flex-col gap-1" },
			template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT()"
      [toggleable]="combinedIsCollpasible()"
      [collapsed]="combinedIsCollpasible() ? isCollapsed() : false"
      (collapsedChange)="isCollapsed.set(!!$event)"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
        </span>
      </ng-template>
      @if (combinedIsCollpasible()) {
        <ng-template #headericons>
          <i class="material-symbols-outlined">{{
            isCollapsed() ? 'expand_more' : 'expand_less'
          }}</i>
        </ng-template>
      }
      @if (property().isRemovable) {
        <ng-template #icons>
          <button
            coreButton
            text
            rounded
            severity="danger"
            aria-label="Remove"
            coreTooltip="Remove"
            tooltipPosition="above"
            (click)="remove.emit()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              >remove</i
            >
          </button>
        </ng-template>
      }
      <div class="field-property-grid">
        @for (child of childProperties(); track trackByPropertyKey($index, child)) {
          <div
            [class.col-span-1]="child.colSpan === 1"
            [class.col-span-2]="child.colSpan !== 1"
          >
            @switch (child.type) {
              @case (typeofProperty.BOOLEAN) {
                <core-field-boolean-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.INPUT) {
                <core-field-input-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.SELECT) {
                <core-field-select-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
            }
          </div>
        }
      </div>
    </core-property-panel>
  `
		}]
	}],
	propDecorators: { isCollapsible: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "isCollapsible",
			required: false
		}]
	}] }
});
const TABLE_COLUMN_TYPES = /* @__PURE__ */ new Set([
	PropertyType.BOOLEAN,
	PropertyType.INPUT,
	PropertyType.SELECT
]);
function isTableDialogProperty(property) {
	if (property.type !== PropertyType.ARRAY) return false;
	const arrayProperty = property;
	if (arrayProperty.useTableDialog !== true || arrayProperty.childProperty?.type !== PropertyType.OBJECT) return false;
	const childProperties = arrayProperty.childProperty.childProperties;
	return Array.isArray(childProperties) && childProperties.length > 0 && childProperties.every((childProperty) => typeof childProperty.key === "string" && childProperty.key.length > 0 && TABLE_COLUMN_TYPES.has(childProperty.type));
}
function isTableRow(value) {
	return typeof value === "object" && value !== null && !Array.isArray(value);
}
var FieldArrayProperty = class FieldArrayProperty extends ArrayProperty {
	dialogService = inject(ArrayTableDialogService, { optional: true });
	isCollapsible = input(true, {
		...ngDevMode ? { debugName: "isCollapsible" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	isCollapsed = signal(true, ...ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []);
	combinedIsCollpasible = computed(() => typeof this.property().isCollapsible === "boolean" ? this.property().isCollapsible : this.isCollapsible(), ...ngDevMode ? [{ debugName: "combinedIsCollpasible" }] : /* istanbul ignore next */ []);
	panelPT = computed(() => ({ header: { class: this.isCollapsible() ? "cursor-pointer" : "" } }), ...ngDevMode ? [{ debugName: "panelPT" }] : /* istanbul ignore next */ []);
	canUseTableDialog = computed(() => isTableDialogProperty(this.property()) && this.currentValue().every(isTableRow), ...ngDevMode ? [{ debugName: "canUseTableDialog" }] : /* istanbul ignore next */ []);
	openTable() {
		const property = this.property();
		const rows = this.currentValue();
		if (!isTableDialogProperty(property) || !rows.every(isTableRow)) return;
		if (!this.dialogService) return;
		this.dialogService.open({
			title: property.label ?? "Edit items",
			childProperties: property.childProperty.childProperties,
			rows,
			canAdd: property.canAdd !== false,
			canRemove: property.childProperty.isRemovable === true,
			saveCallback: (updatedRows) => this._modifyValue(updatedRows)
		});
	}
	typeofProperty = PropertyType;
	getChildPath = getChildPath;
	trackByPropertyKey = trackByPropertyKey;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldArrayProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldArrayProperty,
		isStandalone: true,
		selector: "core-field-array-property",
		inputs: { isCollapsible: {
			classPropertyName: "isCollapsible",
			publicName: "isCollapsible",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT()"
      [toggleable]="combinedIsCollpasible()"
      [collapsed]="combinedIsCollpasible() ? isCollapsed() : false"
      (collapsedChange)="isCollapsed.set(!!$event)"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '[' + childProperties().length + ']' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add item"
          coreTooltip="Add item"
          tooltipPosition="above"
          [style.opacity]="isCollapsed() ? '0' : '1'"
          [style.pointerEvents]="isCollapsed() ? 'none' : 'auto'"
          (click)="$event.stopPropagation(); onAddChild()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >add</i
          >
        </button>
        @if (canUseTableDialog()) {
          <button
            coreButton
            text
            rounded
            aria-label="Edit items as table"
            coreTooltip="Edit items as table"
            tooltipPosition="above"
            (click)="$event.stopPropagation(); openTable()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              >table</i
            >
          </button>
        }
      </ng-template>

      @if (combinedIsCollpasible()) {
        <ng-template #headericons>
          <i class="material-symbols-outlined">{{
            isCollapsed() ? 'expand_more' : 'expand_less'
          }}</i>
        </ng-template>
      }
      <div class="field-property-grid">
        @for (child of childProperties(); track trackByPropertyKey($index, child)) {
          <div
            [class.col-span-1]="child.colSpan === 1"
            [class.col-span-2]="child.colSpan !== 1"
          >
            @switch (child.type) {
              @case (typeofProperty.BOOLEAN) {
                <core-field-boolean-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.INPUT) {
                <core-field-input-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.SELECT) {
                <core-field-select-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.OBJECT) {
                <core-field-object-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
            }
          </div>
        } @empty {
          <core-empty
            class="col-span-2"
            label="No items yet"
            description="Click the + button to add an item."
          />
        }
      </div>
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldSelectProperty,
				selector: "core-field-select-property",
				inputs: ["isClearable"]
			},
			{
				kind: "component",
				type: FieldBooleanProperty,
				selector: "core-field-boolean-property"
			},
			{
				kind: "component",
				type: FieldInputProperty,
				selector: "core-field-input-property"
			},
			{
				kind: "component",
				type: FieldObjectProperty,
				selector: "core-field-object-property",
				inputs: ["isCollapsible"]
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldArrayProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-array-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldSelectProperty,
				FieldBooleanProperty,
				FieldInputProperty,
				FieldObjectProperty,
				Panel,
				Empty,
				Tooltip
			],
			template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT()"
      [toggleable]="combinedIsCollpasible()"
      [collapsed]="combinedIsCollpasible() ? isCollapsed() : false"
      (collapsedChange)="isCollapsed.set(!!$event)"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '[' + childProperties().length + ']' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add item"
          coreTooltip="Add item"
          tooltipPosition="above"
          [style.opacity]="isCollapsed() ? '0' : '1'"
          [style.pointerEvents]="isCollapsed() ? 'none' : 'auto'"
          (click)="$event.stopPropagation(); onAddChild()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >add</i
          >
        </button>
        @if (canUseTableDialog()) {
          <button
            coreButton
            text
            rounded
            aria-label="Edit items as table"
            coreTooltip="Edit items as table"
            tooltipPosition="above"
            (click)="$event.stopPropagation(); openTable()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              >table</i
            >
          </button>
        }
      </ng-template>

      @if (combinedIsCollpasible()) {
        <ng-template #headericons>
          <i class="material-symbols-outlined">{{
            isCollapsed() ? 'expand_more' : 'expand_less'
          }}</i>
        </ng-template>
      }
      <div class="field-property-grid">
        @for (child of childProperties(); track trackByPropertyKey($index, child)) {
          <div
            [class.col-span-1]="child.colSpan === 1"
            [class.col-span-2]="child.colSpan !== 1"
          >
            @switch (child.type) {
              @case (typeofProperty.BOOLEAN) {
                <core-field-boolean-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.INPUT) {
                <core-field-input-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.SELECT) {
                <core-field-select-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (typeofProperty.OBJECT) {
                <core-field-object-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (remove)="onRemoveChild($index)"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
            }
          </div>
        } @empty {
          <core-empty
            class="col-span-2"
            label="No items yet"
            description="Click the + button to add an item."
          />
        }
      </div>
    </core-property-panel>
  `
		}]
	}],
	propDecorators: { isCollapsible: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "isCollapsible",
			required: false
		}]
	}] }
});
var FieldChipsProperty = class FieldChipsProperty extends BaseProperty {
	inputId = `chips-property-input-${Math.random().toString(36).substring(2, 15)}`;
	defaultValue = null;
	propertyType = PropertyType.CHIPS;
	controlValue = computed(() => {
		const outputString = this.property().outputString;
		return (outputString ? this.currentValue()?.split(outputString.separator).filter((v) => !!v) : this.currentValue()) ?? [];
	}, ...ngDevMode ? [{ debugName: "controlValue" }] : /* istanbul ignore next */ []);
	onClear() {
		this._clear();
	}
	addChip(event) {
		const value = event.value.trim();
		if (value) this.onValueChange([...this.controlValue(), value]);
		event.chipInput.clear();
	}
	removeChip(index) {
		this.onValueChange(this.controlValue().filter((_, itemIndex) => itemIndex !== index));
	}
	onValueChange(value) {
		const outputString = this.property().outputString;
		if (outputString) {
			const strValue = value?.length ? value.join(outputString.separator) : null;
			this._modifyValue(strValue);
		} else this._modifyValue(value);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldChipsProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldChipsProperty,
		isStandalone: true,
		selector: "core-field-chips-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <mat-chip-grid
        #chips
        [attr.aria-label]="property().label || 'Values'"
      >
        @for (value of controlValue(); track $index) {
          <mat-chip-row (removed)="removeChip($index)">
            {{ value }}
            <button
              matChipRemove
              type="button"
              [attr.aria-label]="'Remove ' + value"
            >
              <i
                class="material-symbols-outlined"
                aria-hidden="true"
                >close</i
              >
            </button>
          </mat-chip-row>
        }
      </mat-chip-grid>
      <input
        coreInput
        class="field-property-control"
        [id]="inputId"
        [placeholder]="property().placeholder || ''"
        [matChipInputFor]="chips"
        [matChipInputAddOnBlur]="true"
        (matChipInputTokenEnd)="addChip($event)"
      />
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: MatChipsModule
			},
			{
				kind: "component",
				type: i1.MatChipGrid,
				selector: "mat-chip-grid",
				inputs: [
					"disabled",
					"placeholder",
					"required",
					"value",
					"errorStateMatcher"
				],
				outputs: ["change", "valueChange"]
			},
			{
				kind: "directive",
				type: i1.MatChipInput,
				selector: "input[matChipInputFor]",
				inputs: [
					"matChipInputFor",
					"matChipInputAddOnBlur",
					"matChipInputSeparatorKeyCodes",
					"placeholder",
					"id",
					"disabled",
					"readonly",
					"matChipInputDisabledInteractive"
				],
				outputs: ["matChipInputTokenEnd"],
				exportAs: ["matChipInput", "matChipInputFor"]
			},
			{
				kind: "directive",
				type: i1.MatChipRemove,
				selector: "[matChipRemove]"
			},
			{
				kind: "component",
				type: i1.MatChipRow,
				selector: "mat-chip-row, [mat-chip-row], mat-basic-chip-row, [mat-basic-chip-row]",
				inputs: ["editable"],
				outputs: ["edited"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldChipsProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-chips-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [MatChipsModule, FieldPropertyWrapper],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <mat-chip-grid
        #chips
        [attr.aria-label]="property().label || 'Values'"
      >
        @for (value of controlValue(); track $index) {
          <mat-chip-row (removed)="removeChip($index)">
            {{ value }}
            <button
              matChipRemove
              type="button"
              [attr.aria-label]="'Remove ' + value"
            >
              <i
                class="material-symbols-outlined"
                aria-hidden="true"
                >close</i
              >
            </button>
          </mat-chip-row>
        }
      </mat-chip-grid>
      <input
        coreInput
        class="field-property-control"
        [id]="inputId"
        [placeholder]="property().placeholder || ''"
        [matChipInputFor]="chips"
        [matChipInputAddOnBlur]="true"
        (matChipInputTokenEnd)="addChip($event)"
      />
    </core-field-property-wrapper>
  `
		}]
	}]
});
var ValidationMessageInput = class ValidationMessageInput {
	validatorName = input.required(...ngDevMode ? [{ debugName: "validatorName" }] : /* istanbul ignore next */ []);
	validatorLabel = input(...ngDevMode ? [void 0, { debugName: "validatorLabel" }] : /* istanbul ignore next */ []);
	target = input.required(...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	targetChanged = output();
	fieldService = inject(CoreFieldService);
	messagesPath = this.fieldService.validationMessagesPath;
	inputId = `validation-message-${Math.random().toString(36).substring(2, 15)}`;
	label = computed(() => `${this.validatorLabel() ? this.validatorLabel() + " " : ""}Message`, ...ngDevMode ? [{ debugName: "label" }] : /* istanbul ignore next */ []);
	path = computed(() => [...this.messagesPath, this.validatorName()], ...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	value = computed(() => get(this.target(), this.path()), ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	message = computed(() => typeof this.value() === "string" ? this.value() : "", ...ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []);
	setMessage(value) {
		if (!value) {
			this.clearMessage();
			return;
		}
		this.targetChanged.emit({
			type: PropertyChangeType.VALUE,
			path: this.path(),
			value
		});
	}
	clearMessage() {
		this.targetChanged.emit({
			type: PropertyChangeType.CLEAR,
			path: this.path()
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ValidationMessageInput,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: ValidationMessageInput,
		isStandalone: true,
		selector: "core-validation-message-input",
		inputs: {
			validatorName: {
				classPropertyName: "validatorName",
				publicName: "validatorName",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			validatorLabel: {
				classPropertyName: "validatorLabel",
				publicName: "validatorLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { targetChanged: "targetChanged" },
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      isClearable
      [label]="label()"
      [labelForId]="inputId"
      (clear)="clearMessage()"
    >
      <textarea
        class="field-property-control resize-y placeholder:whitespace-nowrap"
        coreInput
        rows="1"
        placeholder="Defaults to global message"
        [id]="inputId"
        [ngModel]="message()"
        (ngModelChange)="setMessage($event)"
      ></textarea>
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ValidationMessageInput,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-validation-message-input",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FieldPropertyWrapper, FormsModule],
			template: `
    <core-field-property-wrapper
      isClearable
      [label]="label()"
      [labelForId]="inputId"
      (clear)="clearMessage()"
    >
      <textarea
        class="field-property-control resize-y placeholder:whitespace-nowrap"
        coreInput
        rows="1"
        placeholder="Defaults to global message"
        [id]="inputId"
        [ngModel]="message()"
        (ngModelChange)="setMessage($event)"
      ></textarea>
    </core-field-property-wrapper>
  `
		}]
	}],
	propDecorators: {
		validatorName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validatorName",
				required: true
			}]
		}],
		validatorLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validatorLabel",
				required: false
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: true
			}]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}]
	}
});
var CustomValidationItem = class CustomValidationItem {
	path = input.required(...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	target = input(void 0, ...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	targetChanged = output();
	name = input(...ngDevMode ? [void 0, { debugName: "name" }] : /* istanbul ignore next */ []);
	validationOptions = input.required(...ngDevMode ? [{ debugName: "validationOptions" }] : /* istanbul ignore next */ []);
	remove = output();
	messageTarget = computed(() => {
		const target = this.target();
		return target && !Array.isArray(target) ? target : void 0;
	}, ...ngDevMode ? [{ debugName: "messageTarget" }] : /* istanbul ignore next */ []);
	selectedOption = computed(() => this.validationOptions().find(({ value }) => value === this.name()), ...ngDevMode ? [{ debugName: "selectedOption" }] : /* istanbul ignore next */ []);
	optionsPath = computed(() => [...this.path(), "options"], ...ngDevMode ? [{ debugName: "optionsPath" }] : /* istanbul ignore next */ []);
	optionsProperty = computed(() => {
		const optionProperties = this.selectedOption()?.optionProperties;
		if (optionProperties?.length) return createObjectProperty({
			label: "Options",
			key: "options",
			childProperties: optionProperties,
			description: "Additional configuration options for the selected validator."
		});
		return null;
	}, ...ngDevMode ? [{ debugName: "optionsProperty" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CustomValidationItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: CustomValidationItem,
		isStandalone: true,
		selector: "core-custom-validation-item",
		inputs: {
			path: {
				classPropertyName: "path",
				publicName: "path",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			name: {
				classPropertyName: "name",
				publicName: "name",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			validationOptions: {
				classPropertyName: "validationOptions",
				publicName: "validationOptions",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: {
			targetChanged: "targetChanged",
			remove: "remove"
		},
		ngImport: i0,
		template: `
    <core-property-panel [header]="selectedOption()?.label || name() || 'Validation'">
      <ng-template #icons>
        <button
          coreButton
          text
          rounded
          severity="danger"
          aria-label="Remove validation"
          coreTooltip="Remove validation"
          tooltipPosition="above"
          (click)="remove.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >remove</i
          >
        </button>
      </ng-template>

      <div class="flex flex-col gap-2">
        @if (!selectedOption()) {
          <p
            role="status"
            class="text-sm text-muted-color"
          >
            Unavailable in the active library.
          </p>
        }
        @if (messageTarget(); as currentTarget) {
          <core-validation-message-input
            [validatorName]="name() || ''"
            [target]="currentTarget"
            (targetChanged)="targetChanged.emit($event)"
          />
        }
        @if (optionsProperty(); as property) {
          <core-field-object-property
            [isCollapsible]="false"
            [path]="optionsPath()"
            [property]="property"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        }
      </div>
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: FieldObjectProperty,
				selector: "core-field-object-property",
				inputs: ["isCollapsible"]
			},
			{
				kind: "component",
				type: ValidationMessageInput,
				selector: "core-validation-message-input",
				inputs: [
					"validatorName",
					"validatorLabel",
					"target"
				],
				outputs: ["targetChanged"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CustomValidationItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-custom-validation-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Panel,
				FieldObjectProperty,
				ValidationMessageInput,
				Tooltip
			],
			template: `
    <core-property-panel [header]="selectedOption()?.label || name() || 'Validation'">
      <ng-template #icons>
        <button
          coreButton
          text
          rounded
          severity="danger"
          aria-label="Remove validation"
          coreTooltip="Remove validation"
          tooltipPosition="above"
          (click)="remove.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >remove</i
          >
        </button>
      </ng-template>

      <div class="flex flex-col gap-2">
        @if (!selectedOption()) {
          <p
            role="status"
            class="text-sm text-muted-color"
          >
            Unavailable in the active library.
          </p>
        }
        @if (messageTarget(); as currentTarget) {
          <core-validation-message-input
            [validatorName]="name() || ''"
            [target]="currentTarget"
            (targetChanged)="targetChanged.emit($event)"
          />
        }
        @if (optionsProperty(); as property) {
          <core-field-object-property
            [isCollapsible]="false"
            [path]="optionsPath()"
            [property]="property"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        }
      </div>
    </core-property-panel>
  `
		}]
	}],
	propDecorators: {
		path: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "path",
				required: true
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: false
			}]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}],
		name: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "name",
				required: false
			}]
		}],
		validationOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validationOptions",
				required: true
			}]
		}],
		remove: [{
			type: i0.Output,
			args: ["remove"]
		}]
	}
});
var ValidationExpressionEditor = class ValidationExpressionEditor {
	originalName = input("", ...ngDevMode ? [{ debugName: "originalName" }] : /* istanbul ignore next */ []);
	rule = input(...ngDevMode ? [void 0, { debugName: "rule" }] : /* istanbul ignore next */ []);
	reservedNames = input([], ...ngDevMode ? [{ debugName: "reservedNames" }] : /* istanbul ignore next */ []);
	saving = input(false, ...ngDevMode ? [{ debugName: "saving" }] : /* istanbul ignore next */ []);
	saved = output();
	cancelled = output();
	id = `validation-expression-${Math.random().toString(36).slice(2)}`;
	name = signal("", ...ngDevMode ? [{ debugName: "name" }] : /* istanbul ignore next */ []);
	expression = signal("", ...ngDevMode ? [{ debugName: "expression" }] : /* istanbul ignore next */ []);
	message = signal("", ...ngDevMode ? [{ debugName: "message" }] : /* istanbul ignore next */ []);
	error = signal("", ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	builder = inject(FormlyFormBuilder);
	constructor() {
		effect(() => {
			this.name.set(this.originalName());
			this.expression.set(this.rule()?.expression ?? "");
			this.message.set(this.rule()?.message ?? "");
			this.error.set("");
		});
	}
	save() {
		if (this.saving()) return;
		const name = this.name().trim();
		const expression = this.expression().trim();
		const message = this.message().trim();
		if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(name)) {
			this.error.set("Start the rule name with a letter and use only letters, numbers, or underscores.");
			return;
		}
		if (!isValidationRuleName(name) || name !== this.originalName() && this.reservedNames().includes(name)) {
			this.error.set("This rule name is already used or reserved. Choose another name.");
			return;
		}
		if (!expression || !message) {
			this.error.set("Enter a condition and an error message before saving.");
			return;
		}
		try {
			this.builder.buildForm(new FormGroup({}), [{
				key: "value",
				validators: { [name]: { expression } }
			}], {}, {});
		} catch {
			this.error.set("This condition is not supported. Use comparisons such as control.value >= 18; function calls and assignments are not allowed.");
			return;
		}
		this.saved.emit({
			name,
			rule: {
				expression,
				message
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ValidationExpressionEditor,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ValidationExpressionEditor,
		isStandalone: true,
		selector: "core-validation-expression-editor",
		inputs: {
			originalName: {
				classPropertyName: "originalName",
				publicName: "originalName",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			rule: {
				classPropertyName: "rule",
				publicName: "rule",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			reservedNames: {
				classPropertyName: "reservedNames",
				publicName: "reservedNames",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			saving: {
				classPropertyName: "saving",
				publicName: "saving",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			saved: "saved",
			cancelled: "cancelled"
		},
		host: { classAttribute: "flex min-w-0 flex-col gap-3" },
		providers: [FormlyFormBuilder],
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      label="Rule name"
      [labelForId]="id + '-name'"
    >
      <input
        coreInput
        class="field-property-control"
        placeholder="e.g., minimumAge"
        [id]="id + '-name'"
        [disabled]="saving()"
        [(ngModel)]="name"
      />
    </core-field-property-wrapper>
    <core-field-property-wrapper
      label="Valid when"
      [labelForId]="id + '-expression'"
    >
      <textarea
        coreInput
        class="field-property-control resize-y"
        rows="3"
        placeholder="control.value >= 18"
        [id]="id + '-expression'"
        [attr.aria-describedby]="id + '-help'"
        [disabled]="saving()"
        [(ngModel)]="expression"
      ></textarea>
    </core-field-property-wrapper>
    <p
      class="text-sm"
      [id]="id + '-help'"
    >
      Write a condition that is true for valid values. Use control.value for this field or
      model.fieldKey for another value. Comparisons and &&, ||, ! are supported; function calls are
      not.
    </p>
    <core-field-property-wrapper
      label="Error message"
      [labelForId]="id + '-message'"
    >
      <textarea
        coreInput
        class="field-property-control resize-y"
        rows="2"
        placeholder="Enter an age of at least 18."
        [id]="id + '-message'"
        [disabled]="saving()"
        [(ngModel)]="message"
      ></textarea>
    </core-field-property-wrapper>
    @if (error()) {
      <p
        role="alert"
        class="text-sm text-red-700 dark:text-red-300"
      >
        {{ error() }}
      </p>
    }
    <div class="flex flex-wrap justify-end gap-2">
      <button
        coreButton
        text
        [disabled]="saving()"
        (click)="cancelled.emit()"
      >
        <span coreButtonLabel>Cancel</span>
      </button>
      <button
        coreButton
        [disabled]="saving()"
        (click)="save()"
      >
        <span coreButtonLabel>Save validation</span>
      </button>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ValidationExpressionEditor,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-validation-expression-editor",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [FormlyFormBuilder],
			imports: [FormsModule, FieldPropertyWrapper],
			host: { class: "flex min-w-0 flex-col gap-3" },
			template: `
    <core-field-property-wrapper
      label="Rule name"
      [labelForId]="id + '-name'"
    >
      <input
        coreInput
        class="field-property-control"
        placeholder="e.g., minimumAge"
        [id]="id + '-name'"
        [disabled]="saving()"
        [(ngModel)]="name"
      />
    </core-field-property-wrapper>
    <core-field-property-wrapper
      label="Valid when"
      [labelForId]="id + '-expression'"
    >
      <textarea
        coreInput
        class="field-property-control resize-y"
        rows="3"
        placeholder="control.value >= 18"
        [id]="id + '-expression'"
        [attr.aria-describedby]="id + '-help'"
        [disabled]="saving()"
        [(ngModel)]="expression"
      ></textarea>
    </core-field-property-wrapper>
    <p
      class="text-sm"
      [id]="id + '-help'"
    >
      Write a condition that is true for valid values. Use control.value for this field or
      model.fieldKey for another value. Comparisons and &&, ||, ! are supported; function calls are
      not.
    </p>
    <core-field-property-wrapper
      label="Error message"
      [labelForId]="id + '-message'"
    >
      <textarea
        coreInput
        class="field-property-control resize-y"
        rows="2"
        placeholder="Enter an age of at least 18."
        [id]="id + '-message'"
        [disabled]="saving()"
        [(ngModel)]="message"
      ></textarea>
    </core-field-property-wrapper>
    @if (error()) {
      <p
        role="alert"
        class="text-sm text-red-700 dark:text-red-300"
      >
        {{ error() }}
      </p>
    }
    <div class="flex flex-wrap justify-end gap-2">
      <button
        coreButton
        text
        [disabled]="saving()"
        (click)="cancelled.emit()"
      >
        <span coreButtonLabel>Cancel</span>
      </button>
      <button
        coreButton
        [disabled]="saving()"
        (click)="save()"
      >
        <span coreButtonLabel>Save validation</span>
      </button>
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		originalName: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "originalName",
				required: false
			}]
		}],
		rule: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "rule",
				required: false
			}]
		}],
		reservedNames: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "reservedNames",
				required: false
			}]
		}],
		saving: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "saving",
				required: false
			}]
		}],
		saved: [{
			type: i0.Output,
			args: ["saved"]
		}],
		cancelled: [{
			type: i0.Output,
			args: ["cancelled"]
		}]
	}
});
var FieldCustomValidationProperty = class FieldCustomValidationProperty extends BaseProperty {
	panelPT = { header: { class: "cursor-pointer" } };
	defaultValue = [];
	propertyType = PropertyType.CUSTOM_VALIDATION;
	isCollapsed = signal(true, ...ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []);
	forms = inject(CoreFormService, { optional: true });
	formlyConfig = inject(FormlyConfig, { optional: true });
	availableWorkspaceValidations = computed(() => this.isSynchronous() && !this.forms?.validationsLoadError() ? (this.forms?.validations() ?? []).filter((rule) => !this.reservedNames().includes(rule.name)) : [], ...ngDevMode ? [{ debugName: "availableWorkspaceValidations" }] : /* istanbul ignore next */ []);
	editingName = signal(null, ...ngDevMode ? [{ debugName: "editingName" }] : /* istanbul ignore next */ []);
	fieldId = computed(() => get(this.target(), ["_info", "id"]), ...ngDevMode ? [{ debugName: "fieldId" }] : /* istanbul ignore next */ []);
	isSynchronous = computed(() => this.property().key === "validators.validation", ...ngDevMode ? [{ debugName: "isSynchronous" }] : /* istanbul ignore next */ []);
	validators = computed(() => get(this.target(), ["validators"]) ?? {}, ...ngDevMode ? [{ debugName: "validators" }] : /* istanbul ignore next */ []);
	expressionRules = computed(() => this.isSynchronous() ? Object.entries(this.validators()).flatMap(([name, rule]) => name !== "validation" && rule && typeof rule === "object" && "expression" in rule && typeof rule.expression === "string" ? [{
		name,
		rule
	}] : []) : [], ...ngDevMode ? [{ debugName: "expressionRules" }] : /* istanbul ignore next */ []);
	reservedNames = computed(() => [
		...Object.keys(this.formlyConfig?.validators ?? {}),
		...Object.keys(this.validators()),
		...Object.keys(get(this.target(), ["asyncValidators"]) ?? {}),
		...get(this.target(), ["asyncValidators", "validation"], []).map((rule) => typeof rule === "string" ? rule : rule.name),
		...this.property().validationOptions.map(({ value }) => value),
		...this.childProperties().map(({ name }) => name)
	], ...ngDevMode ? [{ debugName: "reservedNames" }] : /* istanbul ignore next */ []);
	childProperties = computed(() => this.currentValue().map((item) => typeof item === "string" ? { name: item } : item), ...ngDevMode ? [{ debugName: "childProperties" }] : /* istanbul ignore next */ []);
	availableOptions = computed(() => {
		const selected = [...this.childProperties().map(({ name }) => name), ...this.expressionRules().map(({ name }) => name)];
		return this.property().validationOptions.filter(({ value }) => !selected.includes(value));
	}, ...ngDevMode ? [{ debugName: "availableOptions" }] : /* istanbul ignore next */ []);
	addMenuItems = computed(() => {
		const items = this.availableOptions().map(({ label, value }) => ({
			label,
			command: () => this.addValidation(value)
		}));
		if (this.isSynchronous()) {
			items.push(...this.availableWorkspaceValidations().map((rule) => ({
				label: rule.name,
				icon: "rule",
				command: () => this.addWorkspaceValidation(rule.id)
			})));
			items.push({
				label: "Create validation",
				icon: "add",
				command: () => this.editingName.set("")
			});
		}
		return items;
	}, ...ngDevMode ? [{ debugName: "addMenuItems" }] : /* istanbul ignore next */ []);
	getChildPath = getChildPath;
	constructor() {
		super();
		effect(() => {
			this.fieldId();
			this.editingName.set(null);
		});
	}
	addValidation(name) {
		if (!this.availableOptions().some(({ value }) => value === name)) return;
		this._modifyValue([...this.currentValue(), { name }]);
	}
	addWorkspaceValidation(id) {
		const rule = this.availableWorkspaceValidations().find((entry) => entry.id === id);
		if (!rule) return;
		this.saveExpression("", {
			name: rule.name,
			rule: {
				expression: rule.expression,
				message: rule.message
			}
		});
	}
	onRemoveChild(index) {
		const newValue = this.currentValue().filter((_, i) => i !== index);
		this._modifyValue(newValue);
	}
	saveExpression(originalName, { name, rule }) {
		const validators = { ...this.validators() };
		const original = originalName ? validators[originalName] : void 0;
		if (originalName) delete validators[originalName];
		validators[name] = {
			...original && typeof original === "object" ? original : {},
			...rule
		};
		this._modifyValue(validators, ["validators"]);
		this.editingName.set(null);
	}
	removeExpression(name) {
		this._clear(["validators", name]);
		if (this.editingName() === name) this.editingName.set(null);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x) && "validationOptions" in x && Array.isArray(x.validationOptions);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldCustomValidationProperty,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldCustomValidationProperty,
		isStandalone: true,
		selector: "core-field-custom-validation-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT"
      [toggleable]="true"
      [(collapsed)]="isCollapsed"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '[' + (childProperties().length + expressionRules().length) + ']' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <core-menu
          #addMenu
          ariaLabel="Add validation"
          [model]="addMenuItems()"
        >
          <ng-template
            #item
            let-item
          >
            <div class="flex cursor-pointer items-center gap-2 px-3 py-2">
              @if (item.icon) {
                <i
                  class="material-symbols-outlined"
                  aria-hidden="true"
                  >{{ item.icon }}</i
                >
              }
              {{ item.label }}
            </div>
          </ng-template>
        </core-menu>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add custom validation"
          aria-haspopup="menu"
          coreTooltip="Add custom validation"
          tooltipPosition="above"
          [attr.aria-expanded]="!!addMenu.visible"
          [disabled]="!addMenuItems().length || editingName() !== null"
          (click)="$event.stopPropagation(); isCollapsed.set(false); addMenu.toggle($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            aria-hidden="true"
            >add</i
          >
        </button>
      </ng-template>
      <ng-template #headericons>
        <i class="material-symbols-outlined">{{ isCollapsed() ? 'expand_more' : 'expand_less' }}</i>
      </ng-template>
      @for (customValidation of childProperties(); track $index) {
        <core-custom-validation-item
          [validationOptions]="property().validationOptions"
          [path]="getChildPath(path(), $index)"
          [name]="customValidation.name"
          [target]="target()"
          (remove)="onRemoveChild($index)"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @for (entry of expressionRules(); track entry.name) {
        <core-property-panel [header]="entry.name">
          <ng-template #icons>
            <button
              coreButton
              text
              rounded
              coreTooltip="Edit validation"
              [attr.aria-label]="'Edit validation ' + entry.name"
              (click)="editingName.set(entry.name)"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >edit</i
              >
            </button>
            <button
              coreButton
              text
              rounded
              severity="danger"
              coreTooltip="Remove validation"
              [attr.aria-label]="'Remove validation ' + entry.name"
              (click)="removeExpression(entry.name)"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >remove</i
              >
            </button>
          </ng-template>
          @if (editingName() === entry.name) {
            <core-validation-expression-editor
              [originalName]="entry.name"
              [rule]="entry.rule"
              [reservedNames]="reservedNames()"
              (saved)="saveExpression(entry.name, $event)"
              (cancelled)="editingName.set(null)"
            />
          } @else {
            <p class="font-mono text-sm break-words">{{ entry.rule.expression }}</p>
            <p class="mt-2 text-sm break-words">{{ entry.rule.message }}</p>
          }
        </core-property-panel>
      }
      @if (editingName() === '') {
        <core-validation-expression-editor
          [reservedNames]="reservedNames()"
          (saved)="saveExpression('', $event)"
          (cancelled)="editingName.set(null)"
        />
      }
      @if (!childProperties().length && !expressionRules().length && editingName() === null) {
        <core-empty
          label="No custom validations"
          [description]="
            isSynchronous()
              ? 'Click + to choose a validation or create your own.'
              : 'Click the + button to add a custom validation.'
          "
        />
      }
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Menu,
				selector: "core-menu",
				inputs: ["model", "ariaLabel"],
				outputs: ["opened", "dismissed"]
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: CustomValidationItem,
				selector: "core-custom-validation-item",
				inputs: [
					"path",
					"target",
					"name",
					"validationOptions"
				],
				outputs: ["targetChanged", "remove"]
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: ValidationExpressionEditor,
				selector: "core-validation-expression-editor",
				inputs: [
					"originalName",
					"rule",
					"reservedNames",
					"saving"
				],
				outputs: ["saved", "cancelled"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldCustomValidationProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-custom-validation-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Menu,
				Panel,
				CustomValidationItem,
				Empty,
				Tooltip,
				ValidationExpressionEditor
			],
			template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT"
      [toggleable]="true"
      [(collapsed)]="isCollapsed"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '[' + (childProperties().length + expressionRules().length) + ']' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <core-menu
          #addMenu
          ariaLabel="Add validation"
          [model]="addMenuItems()"
        >
          <ng-template
            #item
            let-item
          >
            <div class="flex cursor-pointer items-center gap-2 px-3 py-2">
              @if (item.icon) {
                <i
                  class="material-symbols-outlined"
                  aria-hidden="true"
                  >{{ item.icon }}</i
                >
              }
              {{ item.label }}
            </div>
          </ng-template>
        </core-menu>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add custom validation"
          aria-haspopup="menu"
          coreTooltip="Add custom validation"
          tooltipPosition="above"
          [attr.aria-expanded]="!!addMenu.visible"
          [disabled]="!addMenuItems().length || editingName() !== null"
          (click)="$event.stopPropagation(); isCollapsed.set(false); addMenu.toggle($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            aria-hidden="true"
            >add</i
          >
        </button>
      </ng-template>
      <ng-template #headericons>
        <i class="material-symbols-outlined">{{ isCollapsed() ? 'expand_more' : 'expand_less' }}</i>
      </ng-template>
      @for (customValidation of childProperties(); track $index) {
        <core-custom-validation-item
          [validationOptions]="property().validationOptions"
          [path]="getChildPath(path(), $index)"
          [name]="customValidation.name"
          [target]="target()"
          (remove)="onRemoveChild($index)"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @for (entry of expressionRules(); track entry.name) {
        <core-property-panel [header]="entry.name">
          <ng-template #icons>
            <button
              coreButton
              text
              rounded
              coreTooltip="Edit validation"
              [attr.aria-label]="'Edit validation ' + entry.name"
              (click)="editingName.set(entry.name)"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >edit</i
              >
            </button>
            <button
              coreButton
              text
              rounded
              severity="danger"
              coreTooltip="Remove validation"
              [attr.aria-label]="'Remove validation ' + entry.name"
              (click)="removeExpression(entry.name)"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >remove</i
              >
            </button>
          </ng-template>
          @if (editingName() === entry.name) {
            <core-validation-expression-editor
              [originalName]="entry.name"
              [rule]="entry.rule"
              [reservedNames]="reservedNames()"
              (saved)="saveExpression(entry.name, $event)"
              (cancelled)="editingName.set(null)"
            />
          } @else {
            <p class="font-mono text-sm break-words">{{ entry.rule.expression }}</p>
            <p class="mt-2 text-sm break-words">{{ entry.rule.message }}</p>
          }
        </core-property-panel>
      }
      @if (editingName() === '') {
        <core-validation-expression-editor
          [reservedNames]="reservedNames()"
          (saved)="saveExpression('', $event)"
          (cancelled)="editingName.set(null)"
        />
      }
      @if (!childProperties().length && !expressionRules().length && editingName() === null) {
        <core-empty
          label="No custom validations"
          [description]="
            isSynchronous()
              ? 'Click + to choose a validation or create your own.'
              : 'Click the + button to add a custom validation.'
          "
        />
      }
    </core-property-panel>
  `
		}]
	}],
	ctorParameters: () => []
});
var DateProperty = class DateProperty extends BaseProperty {
	defaultValue = null;
	propertyType = PropertyType.DATE;
	onClear() {
		this._clear();
	}
	onValueChange(value) {
		if (!value) {
			if (this.property().clearOnEmpty !== false) this._clear();
			return;
		}
		this._modifyValue(value);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: DateProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: DateProperty,
		isStandalone: true,
		usesInheritance: true,
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: DateProperty,
	decorators: [{ type: Directive }]
});
var FieldDateProperty = class FieldDateProperty extends DateProperty {
	inputId = `date-property-input-${Math.random().toString(36).substring(2, 15)}`;
	currentDateValue = computed(() => {
		const stringValue = this.currentValue();
		if (stringValue instanceof Date) throw new Error("Field date property value must be a string");
		return stringValue ? parse(stringValue, "yyyy-MM-dd", /* @__PURE__ */ new Date()) : null;
	}, ...ngDevMode ? [{ debugName: "currentDateValue" }] : /* istanbul ignore next */ []);
	onDateValueChange(value) {
		if (!value) return;
		const stringValue = format(value, "yyyy-MM-dd");
		this.onValueChange(stringValue);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldDateProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FieldDateProperty,
		isStandalone: true,
		selector: "core-field-date-property",
		providers: [provideNativeDateAdapter()],
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <span class="flex min-w-0 items-center"
        ><input
          coreInput
          class="field-property-control"
          [matDatepicker]="calendar"
          [id]="inputId"
          [ngModel]="currentDateValue()"
          (ngModelChange)="onDateValueChange($event)" /><mat-datepicker-toggle
          [for]="calendar" /><mat-datepicker #calendar
      /></span>
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			},
			{
				kind: "ngmodule",
				type: MatDatepickerModule
			},
			{
				kind: "component",
				type: i2$1.MatDatepicker,
				selector: "mat-datepicker",
				exportAs: ["matDatepicker"]
			},
			{
				kind: "directive",
				type: i2$1.MatDatepickerInput,
				selector: "input[matDatepicker]",
				inputs: [
					"matDatepicker",
					"min",
					"max",
					"matDatepickerFilter"
				],
				exportAs: ["matDatepickerInput"]
			},
			{
				kind: "component",
				type: i2$1.MatDatepickerToggle,
				selector: "mat-datepicker-toggle",
				inputs: [
					"for",
					"tabIndex",
					"aria-label",
					"disabled",
					"disableRipple"
				],
				exportAs: ["matDatepickerToggle"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldDateProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-date-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [provideNativeDateAdapter()],
			imports: [
				FormsModule,
				FieldPropertyWrapper,
				MatDatepickerModule
			],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <span class="flex min-w-0 items-center"
        ><input
          coreInput
          class="field-property-control"
          [matDatepicker]="calendar"
          [id]="inputId"
          [ngModel]="currentDateValue()"
          (ngModelChange)="onDateValueChange($event)" /><mat-datepicker-toggle
          [for]="calendar" /><mat-datepicker #calendar
      /></span>
    </core-field-property-wrapper>
  `
		}]
	}]
});
var ExpressionItem = class ExpressionItem {
	index = input.required(...ngDevMode ? [{ debugName: "index" }] : /* istanbul ignore next */ []);
	key = input(...ngDevMode ? [void 0, { debugName: "key" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	keyChange = output();
	valueChange = output();
	expressionChange = output();
	remove = output();
	dialogService = inject(ExpressionDialogService);
	keyInputId = `expression-item-key-input-${Math.random().toString(36).substring(2, 15)}`;
	valueInputId = `expression-item-value-input-${Math.random().toString(36).substring(2, 15)}`;
	openEditor() {
		if (!this.dialogService) return;
		const beautifiedText = beautifyCode(this.value() || "");
		this.dialogService.open({
			key: this.key() || "",
			value: beautifiedText,
			saveCallback: async (key, value) => {
				const singleLineText = await flattenToOneLine(value);
				this.expressionChange.emit({
					key,
					value: singleLineText
				});
			}
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpressionItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ExpressionItem,
		isStandalone: true,
		selector: "core-expression-item",
		inputs: {
			index: {
				classPropertyName: "index",
				publicName: "index",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			key: {
				classPropertyName: "key",
				publicName: "key",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			keyChange: "keyChange",
			valueChange: "valueChange",
			expressionChange: "expressionChange",
			remove: "remove"
		},
		ngImport: i0,
		template: `
    <core-property-panel [header]="'Expression ' + (index() + 1)">
      <ng-template #icons>
        <span class="inline-flex items-center gap-2">
          @if (dialogService) {
            <button
              coreButton
              text
              rounded
              aria-label="Open expression editor"
              coreTooltip="Open expression editor"
              tooltipPosition="left"
              (click)="openEditor()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >code_blocks</i
              >
            </button>
          }
          <button
            coreButton
            text
            rounded
            severity="danger"
            aria-label="Remove expression"
            coreTooltip="Remove expression"
            tooltipPosition="above"
            (click)="remove.emit()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              >remove</i
            >
          </button>
        </span>
      </ng-template>

      <div class="flex flex-col gap-1">
        <core-field-property-wrapper
          label="Target"
          description="Target model path (e.g. model.myKey)"
          [labelForId]="keyInputId"
        >
          <input
            coreInput
            class="field-property-control"
            type="text"
            placeholder="e.g., model.myKey"
            [id]="keyInputId"
            [ngModel]="key()"
            [ngModelOptions]="{ updateOn: 'blur' }"
            (ngModelChange)="keyChange.emit($event)"
          />
        </core-field-property-wrapper>
        <core-field-property-wrapper
          label="Expression"
          description="JS expression — can use model, formState, field"
          [labelForId]="valueInputId"
        >
          <textarea
            class="field-property-control"
            rows="3"
            coreInput
            placeholder="e.g., model.siblingKey.nested + 68"
            [id]="valueInputId"
            [ngModel]="value()"
            [ngModelOptions]="{ updateOn: 'blur' }"
            (ngModelChange)="valueChange.emit($event)"
          ></textarea>
        </core-field-property-wrapper>
      </div>
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpressionItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-expression-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Panel,
				FormsModule,
				Tooltip,
				FieldPropertyWrapper
			],
			template: `
    <core-property-panel [header]="'Expression ' + (index() + 1)">
      <ng-template #icons>
        <span class="inline-flex items-center gap-2">
          @if (dialogService) {
            <button
              coreButton
              text
              rounded
              aria-label="Open expression editor"
              coreTooltip="Open expression editor"
              tooltipPosition="left"
              (click)="openEditor()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                >code_blocks</i
              >
            </button>
          }
          <button
            coreButton
            text
            rounded
            severity="danger"
            aria-label="Remove expression"
            coreTooltip="Remove expression"
            tooltipPosition="above"
            (click)="remove.emit()"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              >remove</i
            >
          </button>
        </span>
      </ng-template>

      <div class="flex flex-col gap-1">
        <core-field-property-wrapper
          label="Target"
          description="Target model path (e.g. model.myKey)"
          [labelForId]="keyInputId"
        >
          <input
            coreInput
            class="field-property-control"
            type="text"
            placeholder="e.g., model.myKey"
            [id]="keyInputId"
            [ngModel]="key()"
            [ngModelOptions]="{ updateOn: 'blur' }"
            (ngModelChange)="keyChange.emit($event)"
          />
        </core-field-property-wrapper>
        <core-field-property-wrapper
          label="Expression"
          description="JS expression — can use model, formState, field"
          [labelForId]="valueInputId"
        >
          <textarea
            class="field-property-control"
            rows="3"
            coreInput
            placeholder="e.g., model.siblingKey.nested + 68"
            [id]="valueInputId"
            [ngModel]="value()"
            [ngModelOptions]="{ updateOn: 'blur' }"
            (ngModelChange)="valueChange.emit($event)"
          ></textarea>
        </core-field-property-wrapper>
      </div>
    </core-property-panel>
  `
		}]
	}],
	propDecorators: {
		index: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "index",
				required: true
			}]
		}],
		key: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "key",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		keyChange: [{
			type: i0.Output,
			args: ["keyChange"]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}],
		expressionChange: [{
			type: i0.Output,
			args: ["expressionChange"]
		}],
		remove: [{
			type: i0.Output,
			args: ["remove"]
		}]
	}
});
var FieldExpressionsProperty = class FieldExpressionsProperty extends BaseProperty {
	panelPT = { header: { class: "cursor-pointer" } };
	defaultValue = {};
	propertyType = PropertyType.EXPRESSIONS;
	isCollapsed = signal(true, ...ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []);
	childProperties = computed(() => Object.entries(this.currentValue()).map(([key, value]) => ({
		key,
		value
	})), ...ngDevMode ? [{ debugName: "childProperties" }] : /* istanbul ignore next */ []);
	onAddChild(event) {
		event.stopPropagation();
		this.onChildValueChanged("", "");
	}
	onRemoveChild(key) {
		this._clear([...this.path(), key]);
	}
	onChildKeyChanged(currKey, newKey) {
		this._modifyKey([...this.path(), currKey], [...this.path(), newKey]);
	}
	onChildValueChanged(key, value) {
		this._modifyValue(value, [...this.path(), key]);
	}
	onChildExpressionChanged(key, expression) {
		this.onChildKeyChanged(key, expression.key);
		this.onChildValueChanged(expression.key, expression.value);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldExpressionsProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldExpressionsProperty,
		isStandalone: true,
		selector: "core-field-expressions-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT"
      [toggleable]="true"
      [(collapsed)]="isCollapsed"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '{' + childProperties().length + '}' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add expression"
          coreTooltip="Add expression"
          tooltipPosition="above"
          [style.opacity]="isCollapsed() ? '0' : '1'"
          [style.pointerEvents]="isCollapsed() ? 'none' : 'auto'"
          (click)="onAddChild($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >add</i
          >
        </button>
      </ng-template>
      <ng-template #headericons>
        <i class="material-symbols-outlined">{{ isCollapsed() ? 'expand_more' : 'expand_less' }}</i>
      </ng-template>
      @for (expression of childProperties(); track expression.key) {
        <core-expression-item
          [index]="$index"
          [key]="expression.key"
          [value]="expression.value"
          (keyChange)="onChildKeyChanged(expression.key, $event)"
          (valueChange)="onChildValueChanged(expression.key, $event)"
          (expressionChange)="onChildExpressionChanged(expression.key, $event)"
          (remove)="onRemoveChild(expression.key)"
        />
      } @empty {
        <core-empty
          label="No expressions yet"
          description="Click the + button to add an expression."
        />
      }
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: ExpressionItem,
				selector: "core-expression-item",
				inputs: [
					"index",
					"key",
					"value"
				],
				outputs: [
					"keyChange",
					"valueChange",
					"expressionChange",
					"remove"
				]
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldExpressionsProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-expressions-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Panel,
				ExpressionItem,
				Empty,
				Tooltip
			],
			template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT"
      [toggleable]="true"
      [(collapsed)]="isCollapsed"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '{' + childProperties().length + '}' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add expression"
          coreTooltip="Add expression"
          tooltipPosition="above"
          [style.opacity]="isCollapsed() ? '0' : '1'"
          [style.pointerEvents]="isCollapsed() ? 'none' : 'auto'"
          (click)="onAddChild($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >add</i
          >
        </button>
      </ng-template>
      <ng-template #headericons>
        <i class="material-symbols-outlined">{{ isCollapsed() ? 'expand_more' : 'expand_less' }}</i>
      </ng-template>
      @for (expression of childProperties(); track expression.key) {
        <core-expression-item
          [index]="$index"
          [key]="expression.key"
          [value]="expression.value"
          (keyChange)="onChildKeyChanged(expression.key, $event)"
          (valueChange)="onChildValueChanged(expression.key, $event)"
          (expressionChange)="onChildExpressionChanged(expression.key, $event)"
          (remove)="onRemoveChild(expression.key)"
        />
      } @empty {
        <core-empty
          label="No expressions yet"
          description="Click the + button to add an expression."
        />
      }
    </core-property-panel>
  `
		}]
	}]
});
var FieldGroupProperty = class FieldGroupProperty {
	property = input.required({
		...ngDevMode ? { debugName: "property" } : /* istanbul ignore next */ {},
		transform: (property) => {
			if (property.type !== PropertyType.GROUP) throw new Error("Invalid property config for FieldGroupProperty");
			return property;
		}
	});
	path = input.required(...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	target = input.required(...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	targetChanged = output();
	propertyType = PropertyType;
	getChildPath = getChildPath;
	trackByPropertyKey = trackByPropertyKey;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldGroupProperty,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldGroupProperty,
		isStandalone: true,
		selector: "core-field-group-property",
		inputs: {
			property: {
				classPropertyName: "property",
				publicName: "property",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			path: {
				classPropertyName: "path",
				publicName: "path",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { targetChanged: "targetChanged" },
		host: { classAttribute: "flex flex-col gap-1" },
		ngImport: i0,
		template: `
    <core-property-panel [toggleable]="false">
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
        </span>
      </ng-template>

      <div class="field-property-grid">
        @for (child of property().childProperties; track trackByPropertyKey($index, child)) {
          <div
            [class.col-span-1]="child.colSpan === 1"
            [class.col-span-2]="child.colSpan !== 1"
          >
            @switch (child.type) {
              @case (propertyType.BOOLEAN) {
                <core-field-boolean-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (propertyType.INPUT) {
                <core-field-input-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (propertyType.SELECT) {
                <core-field-select-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
            }
          </div>
        }
      </div>
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldBooleanProperty,
				selector: "core-field-boolean-property"
			},
			{
				kind: "component",
				type: FieldInputProperty,
				selector: "core-field-input-property"
			},
			{
				kind: "component",
				type: FieldSelectProperty,
				selector: "core-field-select-property",
				inputs: ["isClearable"]
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldGroupProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-group-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldBooleanProperty,
				FieldInputProperty,
				FieldSelectProperty,
				Panel,
				Tooltip
			],
			host: { class: "flex flex-col gap-1" },
			template: `
    <core-property-panel [toggleable]="false">
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
        </span>
      </ng-template>

      <div class="field-property-grid">
        @for (child of property().childProperties; track trackByPropertyKey($index, child)) {
          <div
            [class.col-span-1]="child.colSpan === 1"
            [class.col-span-2]="child.colSpan !== 1"
          >
            @switch (child.type) {
              @case (propertyType.BOOLEAN) {
                <core-field-boolean-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (propertyType.INPUT) {
                <core-field-input-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
              @case (propertyType.SELECT) {
                <core-field-select-property
                  [path]="getChildPath(path(), child.key)"
                  [property]="child"
                  [target]="target()"
                  (targetChanged)="targetChanged.emit($event)"
                />
              }
            }
          </div>
        }
      </div>
    </core-property-panel>
  `
		}]
	}],
	propDecorators: {
		property: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "property",
				required: true
			}]
		}],
		path: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "path",
				required: true
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: true
			}]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}]
	}
});
var FieldMarkdownProperty = class FieldMarkdownProperty extends BaseProperty {
	dialogService = inject(MarkdownDialogService);
	defaultValue = "";
	propertyType = PropertyType.MARKDOWN;
	textareaId = `markdown-property-textarea-${Math.random().toString(36).substring(2, 15)}`;
	onClear() {
		this._clear();
	}
	onValueChange(value) {
		if (value === "" && this.property().clearOnEmpty !== false) this._clear();
		else this._modifyValue(value);
	}
	openEditor() {
		this.dialogService.open({
			value: this.currentValue(),
			saveCallback: (value) => this.onValueChange(value)
		});
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldMarkdownProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: FieldMarkdownProperty,
		isStandalone: true,
		selector: "core-field-markdown-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="textareaId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <span class="inline-flex w-full items-start gap-2">
        <textarea
          coreInput
          class="field-property-control"
          rows="5"
          [id]="textareaId"
          [placeholder]="property().placeholder || ''"
          [ngModel]="currentValue()"
          (ngModelChange)="onValueChange($event)"
        ></textarea>
        <button
          class="shrink-0"
          coreButton
          text
          rounded
          type="button"
          aria-label="Open Markdown editor"
          coreTooltip="Open Markdown editor"
          tooltipPosition="above"
          (click)="openEditor()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >code_blocks</i
          >
        </button>
      </span>
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldMarkdownProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-markdown-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldPropertyWrapper,
				FormsModule,
				Tooltip
			],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="textareaId"
      [isClearable]="true"
      (clear)="onClear()"
    >
      <span class="inline-flex w-full items-start gap-2">
        <textarea
          coreInput
          class="field-property-control"
          rows="5"
          [id]="textareaId"
          [placeholder]="property().placeholder || ''"
          [ngModel]="currentValue()"
          (ngModelChange)="onValueChange($event)"
        ></textarea>
        <button
          class="shrink-0"
          coreButton
          text
          rounded
          type="button"
          aria-label="Open Markdown editor"
          coreTooltip="Open Markdown editor"
          tooltipPosition="above"
          (click)="openEditor()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >code_blocks</i
          >
        </button>
      </span>
    </core-field-property-wrapper>
  `
		}]
	}]
});
var ValidationMessageItem = class ValidationMessageItem {
	index = input.required(...ngDevMode ? [{ debugName: "index" }] : /* istanbul ignore next */ []);
	key = input(...ngDevMode ? [void 0, { debugName: "key" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	validationOptions = input.required(...ngDevMode ? [{ debugName: "validationOptions" }] : /* istanbul ignore next */ []);
	keyChange = output();
	valueChange = output();
	remove = output();
	keyInputId = `validation-message-item-key-input-${Math.random().toString(36).substring(2, 15)}`;
	valueInputId = `validation-message-item-value-input-${Math.random().toString(36).substring(2, 15)}`;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ValidationMessageItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ValidationMessageItem,
		isStandalone: true,
		selector: "core-validation-message-item",
		inputs: {
			index: {
				classPropertyName: "index",
				publicName: "index",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			key: {
				classPropertyName: "key",
				publicName: "key",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			validationOptions: {
				classPropertyName: "validationOptions",
				publicName: "validationOptions",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: {
			keyChange: "keyChange",
			valueChange: "valueChange",
			remove: "remove"
		},
		ngImport: i0,
		template: `
    <core-property-panel [header]="'Message ' + (index() + 1)">
      <ng-template #icons>
        <button
          coreButton
          text
          rounded
          severity="danger"
          aria-label="Remove message"
          coreTooltip="Remove message"
          tooltipPosition="above"
          (click)="remove.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >remove</i
          >
        </button>
      </ng-template>

      <div class="flex flex-col gap-1">
        <core-field-property-wrapper
          label="Validation"
          description="Validator (e.g., required, minLength)"
          [labelForId]="keyInputId"
        >
          <mat-select
            class="field-property-control"
            placeholder="Select validation"
            aria-label="Validation"
            [id]="keyInputId"
            [ngModel]="key()"
            (ngModelChange)="keyChange.emit($event)"
          >
            @for (option of validationOptions(); track $index) {
              <mat-option [value]="option.value">{{ option.label }}</mat-option>
            }
          </mat-select>
        </core-field-property-wrapper>
        <core-field-property-wrapper
          label="Message"
          description="Error message shown when validation fails"
          [labelForId]="valueInputId"
        >
          <input
            class="field-property-control"
            coreInput
            type="text"
            placeholder="e.g., Invalid field!"
            [id]="valueInputId"
            [ngModel]="value()"
            (ngModelChange)="valueChange.emit($event)"
          />
        </core-field-property-wrapper>
      </div>
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ValidationMessageItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-validation-message-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Panel,
				MatSelect,
				MatOption,
				FormsModule,
				Tooltip,
				FieldPropertyWrapper
			],
			template: `
    <core-property-panel [header]="'Message ' + (index() + 1)">
      <ng-template #icons>
        <button
          coreButton
          text
          rounded
          severity="danger"
          aria-label="Remove message"
          coreTooltip="Remove message"
          tooltipPosition="above"
          (click)="remove.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >remove</i
          >
        </button>
      </ng-template>

      <div class="flex flex-col gap-1">
        <core-field-property-wrapper
          label="Validation"
          description="Validator (e.g., required, minLength)"
          [labelForId]="keyInputId"
        >
          <mat-select
            class="field-property-control"
            placeholder="Select validation"
            aria-label="Validation"
            [id]="keyInputId"
            [ngModel]="key()"
            (ngModelChange)="keyChange.emit($event)"
          >
            @for (option of validationOptions(); track $index) {
              <mat-option [value]="option.value">{{ option.label }}</mat-option>
            }
          </mat-select>
        </core-field-property-wrapper>
        <core-field-property-wrapper
          label="Message"
          description="Error message shown when validation fails"
          [labelForId]="valueInputId"
        >
          <input
            class="field-property-control"
            coreInput
            type="text"
            placeholder="e.g., Invalid field!"
            [id]="valueInputId"
            [ngModel]="value()"
            (ngModelChange)="valueChange.emit($event)"
          />
        </core-field-property-wrapper>
      </div>
    </core-property-panel>
  `
		}]
	}],
	propDecorators: {
		index: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "index",
				required: true
			}]
		}],
		key: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "key",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		validationOptions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "validationOptions",
				required: true
			}]
		}],
		keyChange: [{
			type: i0.Output,
			args: ["keyChange"]
		}],
		valueChange: [{
			type: i0.Output,
			args: ["valueChange"]
		}],
		remove: [{
			type: i0.Output,
			args: ["remove"]
		}]
	}
});
var FieldValidationMessagesProperty = class FieldValidationMessagesProperty extends BaseProperty {
	panelPT = { header: { class: "cursor-pointer" } };
	defaultValue = {};
	propertyType = PropertyType.VALIDATION_MESSAGES;
	isCollapsed = signal(true, ...ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []);
	childProperties = computed(() => Object.entries(this.currentValue()).map(([key, value]) => ({
		key,
		value
	})), ...ngDevMode ? [{ debugName: "childProperties" }] : /* istanbul ignore next */ []);
	onAddChild(event) {
		event.stopPropagation();
		this.onChildValueChanged("", "");
	}
	onRemoveChild(key) {
		this._clear([...this.path(), key]);
	}
	onChildKeyChanged(currKey, newKey) {
		this._modifyKey([...this.path(), currKey], [...this.path(), newKey]);
	}
	onChildValueChanged(key, value) {
		this._modifyValue(value, [...this.path(), key]);
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x) && "validationOptions" in x && Array.isArray(x.validationOptions);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldValidationMessagesProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldValidationMessagesProperty,
		isStandalone: true,
		selector: "core-field-validation-messages-property",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT"
      [toggleable]="true"
      [(collapsed)]="isCollapsed"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '{' + childProperties().length + '}' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add message"
          coreTooltip="Add message"
          tooltipPosition="above"
          [style.opacity]="isCollapsed() ? '0' : '1'"
          [style.pointerEvents]="isCollapsed() ? 'none' : 'auto'"
          (click)="onAddChild($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >add</i
          >
        </button>
      </ng-template>
      <ng-template #headericons>
        <i class="material-symbols-outlined">{{ isCollapsed() ? 'expand_more' : 'expand_less' }}</i>
      </ng-template>
      @for (validationMessage of childProperties(); track validationMessage.key) {
        <core-validation-message-item
          [index]="$index"
          [key]="validationMessage.key"
          [value]="validationMessage.value"
          [validationOptions]="property().validationOptions"
          (keyChange)="onChildKeyChanged(validationMessage.key, $event)"
          (valueChange)="onChildValueChanged(validationMessage.key, $event)"
          (remove)="onRemoveChild(validationMessage.key)"
        />
      } @empty {
        <core-empty
          label="No messages yet"
          description="Click the + button to add a message."
        />
      }
    </core-property-panel>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: ValidationMessageItem,
				selector: "core-validation-message-item",
				inputs: [
					"index",
					"key",
					"value",
					"validationOptions"
				],
				outputs: [
					"keyChange",
					"valueChange",
					"remove"
				]
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldValidationMessagesProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-validation-messages-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Panel,
				ValidationMessageItem,
				Empty,
				Tooltip
			],
			template: `
    <core-property-panel
      toggler="header"
      [pt]="panelPT"
      [toggleable]="true"
      [(collapsed)]="isCollapsed"
    >
      <ng-template #header>
        <span
          class="core-property-panel-title"
          tooltipPosition="left"
          [coreTooltip]="property().description"
        >
          {{ property().label }}
          {{ '{' + childProperties().length + '}' }}
        </span>
      </ng-template>
      <ng-template #icons>
        <button
          class="mr-2"
          coreButton
          text
          rounded
          aria-label="Add message"
          coreTooltip="Add message"
          tooltipPosition="above"
          [style.opacity]="isCollapsed() ? '0' : '1'"
          [style.pointerEvents]="isCollapsed() ? 'none' : 'auto'"
          (click)="onAddChild($event)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            >add</i
          >
        </button>
      </ng-template>
      <ng-template #headericons>
        <i class="material-symbols-outlined">{{ isCollapsed() ? 'expand_more' : 'expand_less' }}</i>
      </ng-template>
      @for (validationMessage of childProperties(); track validationMessage.key) {
        <core-validation-message-item
          [index]="$index"
          [key]="validationMessage.key"
          [value]="validationMessage.value"
          [validationOptions]="property().validationOptions"
          (keyChange)="onChildKeyChanged(validationMessage.key, $event)"
          (valueChange)="onChildValueChanged(validationMessage.key, $event)"
          (remove)="onRemoveChild(validationMessage.key)"
        />
      } @empty {
        <core-empty
          label="No messages yet"
          description="Click the + button to add a message."
        />
      }
    </core-property-panel>
  `
		}]
	}]
});
var FieldWrappersProperty = class FieldWrappersProperty extends BaseProperty {
	isClearable = input(true, {
		...ngDevMode ? { debugName: "isClearable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filter = signal("", ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	orderedValue = computed(() => orderValues(this.currentValue() ?? [], this.property().options), ...ngDevMode ? [{ debugName: "orderedValue" }] : /* istanbul ignore next */ []);
	inputId = `wrappers-property-select-${Math.random().toString(36).substring(2, 15)}`;
	defaultValue = null;
	propertyType = PropertyType.WRAPPERS;
	onClear() {
		this._clear();
	}
	onValueChange(value) {
		if ((!value || value.length === 0) && this.property().clearOnEmpty !== false) this._clear();
		else this._modifyValue(orderValues(value ?? [], this.property().options));
	}
	_isValidProperty(x) {
		return this._isBaseProperty(x) && "options" in x && Array.isArray(x.options) && x.options.every(isValidOption);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldWrappersProperty,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldWrappersProperty,
		isStandalone: true,
		selector: "core-field-wrappers-property",
		inputs: { isClearable: {
			classPropertyName: "isClearable",
			publicName: "isClearable",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		usesInheritance: true,
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="isClearable()"
      (clear)="onClear()"
    >
      <input
        coreInput
        class="mb-1 w-full"
        aria-label="Filter wrappers"
        placeholder="Filter wrappers"
        [ngModel]="filter()"
        (ngModelChange)="filter.set($event)"
      />
      <mat-select
        class="field-property-control"
        multiple
        [id]="inputId"
        [aria-label]="property().label || 'Wrappers'"
        [placeholder]="property().placeholder || 'Select Wrappers'"
        [ngModel]="orderedValue()"
        (ngModelChange)="onValueChange($event)"
      >
        @for (option of property().options; track option.value) {
          <mat-option
            [value]="option.value"
            [hidden]="!option.label.toLowerCase().includes(filter().toLowerCase())"
            >{{ option.label }}</mat-option
          >
        }
      </mat-select>
    </core-field-property-wrapper>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "ngmodule",
				type: MatSelectModule
			},
			{
				kind: "component",
				type: i2.MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: i2.MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldWrappersProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-wrappers-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				MatSelectModule,
				FieldPropertyWrapper
			],
			template: `
    <core-field-property-wrapper
      [label]="property().label"
      [description]="property().description"
      [labelForId]="inputId"
      [isClearable]="isClearable()"
      (clear)="onClear()"
    >
      <input
        coreInput
        class="mb-1 w-full"
        aria-label="Filter wrappers"
        placeholder="Filter wrappers"
        [ngModel]="filter()"
        (ngModelChange)="filter.set($event)"
      />
      <mat-select
        class="field-property-control"
        multiple
        [id]="inputId"
        [aria-label]="property().label || 'Wrappers'"
        [placeholder]="property().placeholder || 'Select Wrappers'"
        [ngModel]="orderedValue()"
        (ngModelChange)="onValueChange($event)"
      >
        @for (option of property().options; track option.value) {
          <mat-option
            [value]="option.value"
            [hidden]="!option.label.toLowerCase().includes(filter().toLowerCase())"
            >{{ option.label }}</mat-option
          >
        }
      </mat-select>
    </core-field-property-wrapper>
  `
		}]
	}],
	propDecorators: { isClearable: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "isClearable",
			required: false
		}]
	}] }
});
function orderValues(selectedValues, options) {
	const optionOrder = new Map(options.map(({ value: optionValue }, index) => [optionValue, index]));
	return selectedValues.map((selectedValue, index) => ({
		selectedValue,
		index
	})).sort((a, b) => {
		return (optionOrder.get(a.selectedValue) ?? options.length + a.index) - (optionOrder.get(b.selectedValue) ?? options.length + b.index);
	}).map(({ selectedValue }) => selectedValue);
}
function isValidOption(x) {
	return typeof x === "object" && x !== null && "label" in x && typeof x.label === "string" && "value" in x && typeof x.value === "string";
}
var FieldProperty = class FieldProperty {
	property = input.required(...ngDevMode ? [{ debugName: "property" }] : /* istanbul ignore next */ []);
	path = input.required(...ngDevMode ? [{ debugName: "path" }] : /* istanbul ignore next */ []);
	target = input.required(...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	targetChanged = output();
	propertyType = PropertyType;
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldProperty,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldProperty,
		isStandalone: true,
		selector: "core-field-property",
		inputs: {
			property: {
				classPropertyName: "property",
				publicName: "property",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			path: {
				classPropertyName: "path",
				publicName: "path",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { targetChanged: "targetChanged" },
		ngImport: i0,
		template: `
    @switch (property().type) {
      @case (propertyType.BOOLEAN) {
        <core-field-boolean-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.INPUT) {
        <core-field-input-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.MARKDOWN) {
        <core-field-markdown-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.DATE) {
        <core-field-date-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.SELECT) {
        <core-field-select-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.CHIPS) {
        <core-field-chips-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.WRAPPERS) {
        <core-field-wrappers-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.OBJECT) {
        <core-field-object-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.GROUP) {
        <core-field-group-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.ARRAY) {
        <core-field-array-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.EXPRESSIONS) {
        <core-field-expressions-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.CUSTOM_VALIDATION) {
        <core-field-custom-validation-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.VALIDATION_MESSAGES) {
        <core-field-validation-messages-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldArrayProperty,
				selector: "core-field-array-property",
				inputs: ["isCollapsible"]
			},
			{
				kind: "component",
				type: FieldBooleanProperty,
				selector: "core-field-boolean-property"
			},
			{
				kind: "component",
				type: FieldChipsProperty,
				selector: "core-field-chips-property"
			},
			{
				kind: "component",
				type: FieldCustomValidationProperty,
				selector: "core-field-custom-validation-property"
			},
			{
				kind: "component",
				type: FieldDateProperty,
				selector: "core-field-date-property"
			},
			{
				kind: "component",
				type: FieldExpressionsProperty,
				selector: "core-field-expressions-property"
			},
			{
				kind: "component",
				type: FieldGroupProperty,
				selector: "core-field-group-property",
				inputs: [
					"property",
					"path",
					"target"
				],
				outputs: ["targetChanged"]
			},
			{
				kind: "component",
				type: FieldInputProperty,
				selector: "core-field-input-property"
			},
			{
				kind: "component",
				type: FieldMarkdownProperty,
				selector: "core-field-markdown-property"
			},
			{
				kind: "component",
				type: FieldObjectProperty,
				selector: "core-field-object-property",
				inputs: ["isCollapsible"]
			},
			{
				kind: "component",
				type: FieldSelectProperty,
				selector: "core-field-select-property",
				inputs: ["isClearable"]
			},
			{
				kind: "component",
				type: FieldValidationMessagesProperty,
				selector: "core-field-validation-messages-property"
			},
			{
				kind: "component",
				type: FieldWrappersProperty,
				selector: "core-field-wrappers-property",
				inputs: ["isClearable"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldProperty,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-property",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldArrayProperty,
				FieldBooleanProperty,
				FieldChipsProperty,
				FieldCustomValidationProperty,
				FieldDateProperty,
				FieldExpressionsProperty,
				FieldGroupProperty,
				FieldInputProperty,
				FieldMarkdownProperty,
				FieldObjectProperty,
				FieldSelectProperty,
				FieldValidationMessagesProperty,
				FieldWrappersProperty
			],
			template: `
    @switch (property().type) {
      @case (propertyType.BOOLEAN) {
        <core-field-boolean-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.INPUT) {
        <core-field-input-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.MARKDOWN) {
        <core-field-markdown-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.DATE) {
        <core-field-date-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.SELECT) {
        <core-field-select-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.CHIPS) {
        <core-field-chips-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.WRAPPERS) {
        <core-field-wrappers-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.OBJECT) {
        <core-field-object-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.GROUP) {
        <core-field-group-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.ARRAY) {
        <core-field-array-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.EXPRESSIONS) {
        <core-field-expressions-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.CUSTOM_VALIDATION) {
        <core-field-custom-validation-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
      @case (propertyType.VALIDATION_MESSAGES) {
        <core-field-validation-messages-property
          [property]="property()"
          [path]="path()"
          [target]="target()"
          (targetChanged)="targetChanged.emit($event)"
        />
      }
    }
  `
		}]
	}],
	propDecorators: {
		property: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "property",
				required: true
			}]
		}],
		path: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "path",
				required: true
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: true
			}]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}]
	}
});
var FieldPropertyList = class FieldPropertyList {
	properties = input.required(...ngDevMode ? [{ debugName: "properties" }] : /* istanbul ignore next */ []);
	target = input.required(...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	targetChanged = output();
	leafPropertyTypes = [
		PropertyType.BOOLEAN,
		PropertyType.DATE,
		PropertyType.INPUT,
		PropertyType.SELECT,
		PropertyType.CHIPS,
		PropertyType.WRAPPERS
	];
	resolvedProperties = computed(() => this.properties().map((config) => ({
		config,
		path: config.type === PropertyType.GROUP ? [] : this.getPropertyPath(config.key)
	})), ...ngDevMode ? [{ debugName: "resolvedProperties" }] : /* istanbul ignore next */ []);
	leafProperties = computed(() => this.resolvedProperties().filter(({ config }) => this.leafPropertyTypes.includes(config.type)), ...ngDevMode ? [{ debugName: "leafProperties" }] : /* istanbul ignore next */ []);
	nestedProperties = computed(() => this.resolvedProperties().filter(({ config }) => !this.leafPropertyTypes.includes(config.type)), ...ngDevMode ? [{ debugName: "nestedProperties" }] : /* istanbul ignore next */ []);
	getPropertyPath(key) {
		if (key === void 0) throw new Error("key is undefined");
		return key.toString().split(".");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldPropertyList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldPropertyList,
		isStandalone: true,
		selector: "core-field-property-list",
		inputs: {
			properties: {
				classPropertyName: "properties",
				publicName: "properties",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { targetChanged: "targetChanged" },
		host: { classAttribute: "flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto px-4 pb-4" },
		ngImport: i0,
		template: `
    <ul class="grid grid-cols-2 gap-2">
      @for (property of leafProperties(); track property.config.key) {
        <li
          [class.col-span-1]="property.config.colSpan === 1"
          [class.col-span-2]="property.config.colSpan !== 1"
        >
          <core-field-property
            [property]="property.config"
            [path]="property.path"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        </li>
      }
      @for (property of nestedProperties(); track property.config.key) {
        <li
          [class.col-span-1]="property.config.colSpan === 1"
          [class.col-span-2]="property.config.colSpan !== 1"
        >
          <core-field-property
            [property]="property.config"
            [path]="property.path"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        </li>
      }
    </ul>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: FieldProperty,
			selector: "core-field-property",
			inputs: [
				"property",
				"path",
				"target"
			],
			outputs: ["targetChanged"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldPropertyList,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-property-list",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FieldProperty],
			host: { class: "flex min-h-0 min-w-0 flex-1 flex-col overflow-y-auto px-4 pb-4" },
			template: `
    <ul class="grid grid-cols-2 gap-2">
      @for (property of leafProperties(); track property.config.key) {
        <li
          [class.col-span-1]="property.config.colSpan === 1"
          [class.col-span-2]="property.config.colSpan !== 1"
        >
          <core-field-property
            [property]="property.config"
            [path]="property.path"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        </li>
      }
      @for (property of nestedProperties(); track property.config.key) {
        <li
          [class.col-span-1]="property.config.colSpan === 1"
          [class.col-span-2]="property.config.colSpan !== 1"
        >
          <core-field-property
            [property]="property.config"
            [path]="property.path"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        </li>
      }
    </ul>
  `
		}]
	}],
	propDecorators: {
		properties: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "properties",
				required: true
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: true
			}]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}]
	}
});
var FieldEditPanel = class FieldEditPanel {
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	activeField = this.formService.activeField;
	activeFieldMap = this.formService.activeFieldMap;
	headerTitle = computed(() => {
		const activeField = this.activeField();
		if (!activeField) return "Field Edit";
		return `Field Edit - ${this.fieldService.getKey(activeField) || activeField._info.name}`;
	}, ...ngDevMode ? [{ debugName: "headerTitle" }] : /* istanbul ignore next */ []);
	parentField = computed(() => {
		const field = this.activeField();
		if (!field) return null;
		const parentId = field._info.idPath[field._info.idPath.length - 2];
		return this.activeFieldMap()[parentId] || null;
	}, ...ngDevMode ? [{ debugName: "parentField" }] : /* istanbul ignore next */ []);
	activeFieldByType = computed(() => this.activeField(), {
		...ngDevMode ? { debugName: "activeFieldByType" } : /* istanbul ignore next */ {},
		equal: (a, b) => !!(a && b && this.fieldService.isFieldEqual(a, b))
	});
	properties = computed(() => {
		const field = this.activeFieldByType();
		return field ? this.fieldService.getProperties(field) : [];
	}, ...ngDevMode ? [{ debugName: "properties" }] : /* istanbul ignore next */ []);
	keyPath = computed(() => {
		const activeField = this.formService.activeField();
		if (!activeField) return "";
		return this.fieldService.getKey(activeField);
	}, ...ngDevMode ? [{ debugName: "keyPath" }] : /* istanbul ignore next */ []);
	onFieldChanged(change) {
		this.formService.modifyActiveField(change);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldEditPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldEditPanel,
		isStandalone: true,
		selector: "core-field-edit-panel",
		host: { classAttribute: "overflow-hidden" },
		ngImport: i0,
		template: `
    <core-panel-header
      header="Field Edit"
      subHeader="Edit the selected field's properties"
    />
    @if (activeField(); as field) {
      @if (properties().length) {
        <core-field-property-list
          [properties]="properties()"
          [target]="field"
          (targetChanged)="onFieldChanged($event)"
        />
      } @else {
        <core-empty
          label="No editable properties"
          description="This field has no editable properties."
        />
      }
    } @else {
      <core-empty-no-field-selected />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "component",
				type: FieldPropertyList,
				selector: "core-field-property-list",
				inputs: ["properties", "target"],
				outputs: ["targetChanged"]
			},
			{
				kind: "component",
				type: EmptyNoFieldSelected,
				selector: "core-empty-no-field-selected"
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldEditPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-edit-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Empty,
				FieldPropertyList,
				EmptyNoFieldSelected,
				PanelHeader
			],
			host: { class: "overflow-hidden" },
			template: `
    <core-panel-header
      header="Field Edit"
      subHeader="Edit the selected field's properties"
    />
    @if (activeField(); as field) {
      @if (properties().length) {
        <core-field-property-list
          [properties]="properties()"
          [target]="field"
          (targetChanged)="onFieldChanged($event)"
        />
      } @else {
        <core-empty
          label="No editable properties"
          description="This field has no editable properties."
        />
      }
    } @else {
      <core-empty-no-field-selected />
    }
  `
		}]
	}]
});
var FieldItem = class FieldItem {
	fieldId = input.required(...ngDevMode ? [{ debugName: "fieldId" }] : /* istanbul ignore next */ []);
	isFiltering = input(false, {
		...ngDevMode ? { debugName: "isFiltering" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filteredVisibleFieldIds = input.required(...ngDevMode ? [{ debugName: "filteredVisibleFieldIds" }] : /* istanbul ignore next */ []);
	level = input(0, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	isTabRoot = input(false, {
		...ngDevMode ? { debugName: "isTabRoot" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	expandParent = output();
	optionsMenu = viewChild("optionsMenu", {
		...ngDevMode ? { debugName: "optionsMenu" } : /* istanbul ignore next */ {},
		read: Menu
	});
	document = inject(DOCUMENT);
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	presetDialogService = inject(FieldPresetDialogService);
	linePaddingLeft = `calc(var(--spacing) * 3.75)`;
	isCollapsed = signal(false, ...ngDevMode ? [{ debugName: "isCollapsed" }] : /* istanbul ignore next */ []);
	optionsMenuVisible = signal(false, ...ngDevMode ? [{ debugName: "optionsMenuVisible" }] : /* istanbul ignore next */ []);
	field = computed(() => {
		return this.formService.activeFieldMap()[this.fieldId()];
	}, ...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	fieldInfo = computed(() => this.field()._info, ...ngDevMode ? [{ debugName: "fieldInfo" }] : /* istanbul ignore next */ []);
	fieldKey = computed(() => this.fieldService.getKey(this.field()), ...ngDevMode ? [{ debugName: "fieldKey" }] : /* istanbul ignore next */ []);
	childIds = computed(() => {
		return this.fieldService.getChildIds(this.fieldInfo());
	}, ...ngDevMode ? [{ debugName: "childIds" }] : /* istanbul ignore next */ []);
	hasChildren = computed(() => this.childIds().length > 0, ...ngDevMode ? [{ debugName: "hasChildren" }] : /* istanbul ignore next */ []);
	isParent = computed(() => this.fieldInfo().isParent, ...ngDevMode ? [{ debugName: "isParent" }] : /* istanbul ignore next */ []);
	isActiveField = computed(() => {
		return this.fieldId() === this.formService.activeFieldId();
	}, ...ngDevMode ? [{ debugName: "isActiveField" }] : /* istanbul ignore next */ []);
	isHidden = computed(() => {
		return this.field().hide;
	}, ...ngDevMode ? [{ debugName: "isHidden" }] : /* istanbul ignore next */ []);
	fieldIcon = computed(() => {
		return this.fieldService.getFieldIcon(this.field());
	}, ...ngDevMode ? [{ debugName: "fieldIcon" }] : /* istanbul ignore next */ []);
	alwaysShowActions = computed(() => this.optionsMenuVisible(), ...ngDevMode ? [{ debugName: "alwaysShowActions" }] : /* istanbul ignore next */ []);
	addOptions = computed(() => this.formService.getAddOptions(this.fieldInfo()), ...ngDevMode ? [{ debugName: "addOptions" }] : /* istanbul ignore next */ []);
	replaceOptions = computed(() => this.formService.getReplaceOptions(this.fieldInfo()), ...ngDevMode ? [{ debugName: "replaceOptions" }] : /* istanbul ignore next */ []);
	otherOptions = computed(() => {
		const options = [];
		if (!this.fieldInfo().isRoot) options.push({
			label: "Save as Preset",
			matIcon: "save",
			command: () => this.openPresetDialog()
		}, {
			label: "Remove",
			matIcon: "delete",
			warn: true,
			command: () => this.removeField()
		});
		return options;
	}, ...ngDevMode ? [{ debugName: "otherOptions" }] : /* istanbul ignore next */ []);
	menuOptions = computed(() => {
		const options = [];
		const addOptions = this.addOptions();
		const replaceOptions = this.replaceOptions();
		if (addOptions.length) options.push({
			label: "Add Field",
			matIcon: "add",
			items: addOptions
		});
		if (replaceOptions.length) options.push({
			label: "Replace Field",
			matIcon: "swap_horiz",
			items: replaceOptions
		});
		options.push(...this.otherOptions());
		return options;
	}, ...ngDevMode ? [{ debugName: "menuOptions" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			if (this.isActiveField()) this.expandParent.emit();
		});
	}
	setActive(event) {
		if (event.defaultPrevented) return;
		if (this.isActiveField()) this.toggleCollapsed(event);
		else {
			this.formService.setActiveField(this.fieldId());
			this.isCollapsed.set(false);
			this.scrollToField();
		}
		event.preventDefault();
	}
	toggleCollapsed(event) {
		if (event.defaultPrevented) return;
		this.isCollapsed.set(!this.isCollapsed());
		event.preventDefault();
	}
	onExpandParent() {
		this.isCollapsed.set(false);
		this.expandParent.emit();
	}
	removeField() {
		this.formService.removeField(this.fieldInfo().id);
	}
	openOptionsMenu(event) {
		this.optionsMenu()?.show(event);
		event.preventDefault();
	}
	openPresetDialog() {
		const fieldMap = this.formService.activeFieldMap();
		const field = this.formService.buildField(this.fieldInfo().id, fieldMap);
		this.formService.cleanField(field);
		const fieldJSON = JSON.stringify(field, null, 2);
		this.presetDialogService.open({
			name: `My ${this.fieldInfo().name}`,
			json: fieldJSON
		});
	}
	scrollToField() {
		const element = this.document.getElementById(this.fieldId());
		if (element) element.scrollIntoView({
			behavior: "smooth",
			block: "nearest"
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldItem,
		isStandalone: true,
		selector: "core-panel-field-item",
		inputs: {
			fieldId: {
				classPropertyName: "fieldId",
				publicName: "fieldId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			isFiltering: {
				classPropertyName: "isFiltering",
				publicName: "isFiltering",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filteredVisibleFieldIds: {
				classPropertyName: "filteredVisibleFieldIds",
				publicName: "filteredVisibleFieldIds",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isTabRoot: {
				classPropertyName: "isTabRoot",
				publicName: "isTabRoot",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { expandParent: "expandParent" },
		viewQueries: [{
			propertyName: "optionsMenu",
			first: true,
			predicate: ["optionsMenu"],
			descendants: true,
			read: Menu,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-tree-item
      #folderTreeItem
      [isParent]="isParent()"
      [level]="level()"
      [isActive]="isActiveField()"
      [isExpanded]="!isCollapsed()"
      [alwaysShowActions]="alwaysShowActions()"
      (click)="setActive($event)"
      (keydown.enter)="setActive($event)"
      (toggleClicked)="toggleCollapsed($event)"
    >
      <span class="inline-flex items-center gap-2 overflow-hidden">
        <span
          class="inline-flex items-center gap-2 truncate"
          [class.font-medium]="isParent()"
        >
          @if (fieldIcon(); as icon) {
            <i
              class="material-symbols-outlined text-muted-color"
              tooltipPosition="above"
              [style.fontSize]="'1.25rem'"
              [coreTooltip]="fieldInfo().name"
              >{{ icon }}</i
            >
          }
          <span>{{ fieldKey() || fieldInfo().name }} </span>
          @if (isParent()) {
            <span class="text-xs text-muted-color">[{{ childIds().length }}]</span>
          }
        </span>
        @if (isHidden()) {
          <i class="material-symbols-outlined"> visibility_off </i>
        }
        @if (fieldInfo().badges; as badges) {
          @for (badge of badges; track badge.label) {
            <span
              class="core-chip"
              tooltipPosition="above"
              [coreTooltip]="badge.description"
              >{{ badge.label }}</span
            >
          }
        }
      </span>

      <ng-container actions>
        @if (menuOptions().length) {
          <span class="inline-flex">
            <core-menu
              #optionsMenu
              [model]="menuOptions()"
              (opened)="optionsMenuVisible.set(true)"
              (dismissed)="optionsMenuVisible.set(false)"
            >
              <ng-template
                #item
                let-item
              >
                <div
                  class="flex cursor-pointer items-center gap-2 px-3 py-1"
                  [class.text-button-text-danger]="item.warn"
                >
                  @if (item.matIcon) {
                    <i class="material-symbols-outlined">
                      {{ item.matIcon }}
                    </i>
                  }
                  {{ item.label }}
                </div>
              </ng-template>
            </core-menu>
            <button
              coreButton
              text
              rounded
              class="size-8"
              aria-label="Field options"
              coreTooltip="Field options"
              tooltipPosition="above"
              (click)="openOptionsMenu($event)"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
              >
                more_horiz
              </i>
            </button>
          </span>
        }
      </ng-container>
    </core-tree-item>

    @if (hasChildren()) {
      <ul>
        @for (childId of childIds(); track childId) {
          <li
            [class.hidden]="
              isCollapsed() || (isFiltering() && !filteredVisibleFieldIds().includes(childId))
            "
            [class.block]="!isCollapsed()"
          >
            <core-panel-field-item
              [fieldId]="childId"
              [level]="level() + 1"
              [isFiltering]="isFiltering()"
              [filteredVisibleFieldIds]="filteredVisibleFieldIds()"
              (expandParent)="onExpandParent()"
            />
          </li>
        }
      </ul>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldItem,
				selector: "core-panel-field-item",
				inputs: [
					"fieldId",
					"isFiltering",
					"filteredVisibleFieldIds",
					"level",
					"isTabRoot"
				],
				outputs: ["expandParent"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: Menu,
				selector: "core-menu",
				inputs: ["model", "ariaLabel"],
				outputs: ["opened", "dismissed"]
			},
			{
				kind: "component",
				type: TreeItem,
				selector: "core-tree-item",
				inputs: [
					"level",
					"isTabRoot",
					"isExpanded",
					"isParent",
					"isActive",
					"canInteract",
					"alwaysShowActions",
					"selectionLabel",
					"iconTile",
					"isSelected",
					"selectionDisabled"
				],
				outputs: ["toggleClicked", "selectionToggled"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-panel-field-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Tooltip,
				Menu,
				TreeItem
			],
			template: `
    <core-tree-item
      #folderTreeItem
      [isParent]="isParent()"
      [level]="level()"
      [isActive]="isActiveField()"
      [isExpanded]="!isCollapsed()"
      [alwaysShowActions]="alwaysShowActions()"
      (click)="setActive($event)"
      (keydown.enter)="setActive($event)"
      (toggleClicked)="toggleCollapsed($event)"
    >
      <span class="inline-flex items-center gap-2 overflow-hidden">
        <span
          class="inline-flex items-center gap-2 truncate"
          [class.font-medium]="isParent()"
        >
          @if (fieldIcon(); as icon) {
            <i
              class="material-symbols-outlined text-muted-color"
              tooltipPosition="above"
              [style.fontSize]="'1.25rem'"
              [coreTooltip]="fieldInfo().name"
              >{{ icon }}</i
            >
          }
          <span>{{ fieldKey() || fieldInfo().name }} </span>
          @if (isParent()) {
            <span class="text-xs text-muted-color">[{{ childIds().length }}]</span>
          }
        </span>
        @if (isHidden()) {
          <i class="material-symbols-outlined"> visibility_off </i>
        }
        @if (fieldInfo().badges; as badges) {
          @for (badge of badges; track badge.label) {
            <span
              class="core-chip"
              tooltipPosition="above"
              [coreTooltip]="badge.description"
              >{{ badge.label }}</span
            >
          }
        }
      </span>

      <ng-container actions>
        @if (menuOptions().length) {
          <span class="inline-flex">
            <core-menu
              #optionsMenu
              [model]="menuOptions()"
              (opened)="optionsMenuVisible.set(true)"
              (dismissed)="optionsMenuVisible.set(false)"
            >
              <ng-template
                #item
                let-item
              >
                <div
                  class="flex cursor-pointer items-center gap-2 px-3 py-1"
                  [class.text-button-text-danger]="item.warn"
                >
                  @if (item.matIcon) {
                    <i class="material-symbols-outlined">
                      {{ item.matIcon }}
                    </i>
                  }
                  {{ item.label }}
                </div>
              </ng-template>
            </core-menu>
            <button
              coreButton
              text
              rounded
              class="size-8"
              aria-label="Field options"
              coreTooltip="Field options"
              tooltipPosition="above"
              (click)="openOptionsMenu($event)"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
              >
                more_horiz
              </i>
            </button>
          </span>
        }
      </ng-container>
    </core-tree-item>

    @if (hasChildren()) {
      <ul>
        @for (childId of childIds(); track childId) {
          <li
            [class.hidden]="
              isCollapsed() || (isFiltering() && !filteredVisibleFieldIds().includes(childId))
            "
            [class.block]="!isCollapsed()"
          >
            <core-panel-field-item
              [fieldId]="childId"
              [level]="level() + 1"
              [isFiltering]="isFiltering()"
              [filteredVisibleFieldIds]="filteredVisibleFieldIds()"
              (expandParent)="onExpandParent()"
            />
          </li>
        }
      </ul>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		fieldId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldId",
				required: true
			}]
		}],
		isFiltering: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFiltering",
				required: false
			}]
		}],
		filteredVisibleFieldIds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filteredVisibleFieldIds",
				required: true
			}]
		}],
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		isTabRoot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isTabRoot",
				required: false
			}]
		}],
		expandParent: [{
			type: i0.Output,
			args: ["expandParent"]
		}],
		optionsMenu: [{
			type: i0.ViewChild,
			args: ["optionsMenu", {
				read: Menu,
				isSignal: true
			}]
		}]
	}
});
var FieldsPanel = class FieldsPanel {
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	panelService = inject(PanelService);
	mouseInsideService = inject(MouseInsideService);
	filterValue = signal("", ...ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []);
	isFiltering = computed(() => !!this.filterValue(), ...ngDevMode ? [{ debugName: "isFiltering" }] : /* istanbul ignore next */ []);
	filteredVisibleFieldIds = computed(() => {
		const query = this.filterValue().trim().toLowerCase();
		if (!query) return [];
		const fields = Object.values(this.formService.activeFieldMap());
		const visibleFieldIds = /* @__PURE__ */ new Set();
		fields.filter((field) => this.fieldService.filterPaths.some((path) => String(get(field, path) ?? "").toLowerCase().includes(query))).forEach((field) => field._info.idPath.forEach((id) => visibleFieldIds.add(id)));
		return Array.from(visibleFieldIds);
	}, {
		...ngDevMode ? { debugName: "filteredVisibleFieldIds" } : /* istanbul ignore next */ {},
		equal: (a, b) => a.length === b.length && a.every((val, index) => val === b[index])
	});
	activeFormId = this.formService.activeFormId;
	rootFieldIds = this.formService.activeRootFieldIds;
	openFormsPanel() {
		this.panelService.setActiveLHSPanel("forms");
	}
	setMouseInside(isInside) {
		this.mouseInsideService.setMouseInside(isInside);
	}
	clearFilter() {
		this.filterValue.set("");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldsPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FieldsPanel,
		isStandalone: true,
		selector: "core-fields-panel",
		host: { classAttribute: "overflow-hidden h-full block" },
		providers: [MouseInsideService],
		ngImport: i0,
		template: `
    <core-panel-header
      header="Fields"
      subHeader="Browse and filter fields in the active form"
    />

    @if (activeFormId()) {
      @if (rootFieldIds().length) {
        <div class="flex min-h-0 flex-1 flex-col">
          <div class="min-h-(--sub-panel-header-height) shrink-0 px-4">
            <core-filter
              [(value)]="filterValue"
              (clear)="clearFilter()"
            />
          </div>

          @if (isFiltering() && !filteredVisibleFieldIds().length) {
            <core-empty
              label="No fields found"
              description="Try adjusting your filter criteria."
            />
          }

          <ul
            class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4"
            (mouseenter)="setMouseInside(true)"
            (mouseleave)="setMouseInside(false)"
          >
            @for (fieldId of rootFieldIds(); track fieldId) {
              <li [class.hidden]="isFiltering() && !filteredVisibleFieldIds().includes(fieldId)">
                <core-panel-field-item
                  [fieldId]="fieldId"
                  [isTabRoot]="$first"
                  [isFiltering]="isFiltering()"
                  [filteredVisibleFieldIds]="filteredVisibleFieldIds()"
                />
              </li>
            }
          </ul>
        </div>
      } @else {
        <core-empty-no-field />
      }
    } @else {
      <core-empty-no-form />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldItem,
				selector: "core-panel-field-item",
				inputs: [
					"fieldId",
					"isFiltering",
					"filteredVisibleFieldIds",
					"level",
					"isTabRoot"
				],
				outputs: ["expandParent"]
			},
			{
				kind: "component",
				type: EmptyNoForm,
				selector: "core-empty-no-form"
			},
			{
				kind: "component",
				type: EmptyNoField,
				selector: "core-empty-no-field"
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "component",
				type: Filter,
				selector: "core-filter",
				inputs: ["value", "clearLabel"],
				outputs: ["valueChange", "clear"]
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldsPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-fields-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [MouseInsideService],
			imports: [
				FieldItem,
				EmptyNoForm,
				EmptyNoField,
				Empty,
				Filter,
				PanelHeader
			],
			host: { class: "overflow-hidden h-full block" },
			template: `
    <core-panel-header
      header="Fields"
      subHeader="Browse and filter fields in the active form"
    />

    @if (activeFormId()) {
      @if (rootFieldIds().length) {
        <div class="flex min-h-0 flex-1 flex-col">
          <div class="min-h-(--sub-panel-header-height) shrink-0 px-4">
            <core-filter
              [(value)]="filterValue"
              (clear)="clearFilter()"
            />
          </div>

          @if (isFiltering() && !filteredVisibleFieldIds().length) {
            <core-empty
              label="No fields found"
              description="Try adjusting your filter criteria."
            />
          }

          <ul
            class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4"
            (mouseenter)="setMouseInside(true)"
            (mouseleave)="setMouseInside(false)"
          >
            @for (fieldId of rootFieldIds(); track fieldId) {
              <li [class.hidden]="isFiltering() && !filteredVisibleFieldIds().includes(fieldId)">
                <core-panel-field-item
                  [fieldId]="fieldId"
                  [isTabRoot]="$first"
                  [isFiltering]="isFiltering()"
                  [filteredVisibleFieldIds]="filteredVisibleFieldIds()"
                />
              </li>
            }
          </ul>
        </div>
      } @else {
        <core-empty-no-field />
      }
    } @else {
      <core-empty-no-form />
    }
  `
		}]
	}]
});
var WorkspaceToolbar = class WorkspaceToolbar {
	canSearch = input.required(...ngDevMode ? [{ debugName: "canSearch" }] : /* istanbul ignore next */ []);
	searchLabel = input.required(...ngDevMode ? [{ debugName: "searchLabel" }] : /* istanbul ignore next */ []);
	deleteLabel = input.required(...ngDevMode ? [{ debugName: "deleteLabel" }] : /* istanbul ignore next */ []);
	selectedCount = input.required(...ngDevMode ? [{ debugName: "selectedCount" }] : /* istanbul ignore next */ []);
	deleteUnavailable = input(false, ...ngDevMode ? [{ debugName: "deleteUnavailable" }] : /* istanbul ignore next */ []);
	filterValue = model.required(...ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []);
	deleteSelected = output();
	searchOpen = signal(false, ...ngDevMode ? [{ debugName: "searchOpen" }] : /* istanbul ignore next */ []);
	deleteDisabled = computed(() => !this.selectedCount() || this.deleteUnavailable(), ...ngDevMode ? [{ debugName: "deleteDisabled" }] : /* istanbul ignore next */ []);
	injector = inject(Injector);
	filter = viewChild(Filter, ...ngDevMode ? [{ debugName: "filter" }] : /* istanbul ignore next */ []);
	searchButton = viewChild("searchButton", ...ngDevMode ? [{ debugName: "searchButton" }] : /* istanbul ignore next */ []);
	createButton = contentChild("createButton", ...ngDevMode ? [{ debugName: "createButton" }] : /* istanbul ignore next */ []);
	setSearchOpen(open) {
		this.searchOpen.set(open);
		if (!open) this.filterValue.set("");
		afterNextRender({ write: () => {
			if (open) this.filter()?.focus();
			else (this.searchButton() ?? this.createButton())?.nativeElement.focus();
		} }, { injector: this.injector });
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WorkspaceToolbar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: WorkspaceToolbar,
		isStandalone: true,
		selector: "core-workspace-toolbar",
		inputs: {
			canSearch: {
				classPropertyName: "canSearch",
				publicName: "canSearch",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			searchLabel: {
				classPropertyName: "searchLabel",
				publicName: "searchLabel",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			deleteLabel: {
				classPropertyName: "deleteLabel",
				publicName: "deleteLabel",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			selectedCount: {
				classPropertyName: "selectedCount",
				publicName: "selectedCount",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			deleteUnavailable: {
				classPropertyName: "deleteUnavailable",
				publicName: "deleteUnavailable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filterValue: {
				classPropertyName: "filterValue",
				publicName: "filterValue",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: {
			filterValue: "filterValueChange",
			deleteSelected: "deleteSelected"
		},
		host: { classAttribute: "flex shrink-0 items-center gap-1 px-4 pt-1" },
		queries: [{
			propertyName: "createButton",
			first: true,
			predicate: ["createButton"],
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "filter",
			first: true,
			predicate: Filter,
			descendants: true,
			isSignal: true
		}, {
			propertyName: "searchButton",
			first: true,
			predicate: ["searchButton"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div class="@container relative flex min-w-0 flex-1 items-center justify-between gap-1">
      <div
        class="flex min-w-0"
        [class.invisible]="searchOpen()"
      >
        <ng-content />
      </div>
      @if (canSearch()) {
        <button
          #searchButton
          coreButton
          type="button"
          class="shrink-0"
          severity="secondary"
          text
          tooltipPosition="above"
          [attr.aria-label]="searchLabel()"
          [coreTooltip]="searchLabel()"
          [class.invisible]="searchOpen()"
          (click)="setSearchOpen(true)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            aria-hidden="true"
            >search</i
          >
        </button>
      }
      @if (searchOpen()) {
        <core-filter
          class="absolute inset-x-0"
          clearLabel="Close search"
          [(value)]="filterValue"
          (clear)="setSearchOpen(false)"
        />
      }
    </div>
    <button
      coreButton
      type="button"
      class="shrink-0 px-2"
      text
      tooltipPosition="above"
      [attr.severity]="deleteDisabled() ? 'secondary' : 'danger'"
      [coreTooltip]="deleteLabel()"
      [attr.aria-label]="deleteLabel() + ' (' + selectedCount() + ')'"
      [disabled]="deleteDisabled()"
      (click)="deleteSelected.emit()"
    >
      <i
        coreButtonIcon
        class="material-symbols-outlined"
        aria-hidden="true"
        >delete</i
      >
      <span
        coreButtonLabel
        class="tabular-nums"
        >{{ selectedCount() }}</span
      >
    </button>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: Filter,
			selector: "core-filter",
			inputs: ["value", "clearLabel"],
			outputs: ["valueChange", "clear"]
		}, {
			kind: "directive",
			type: Tooltip,
			selector: "[coreTooltip]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WorkspaceToolbar,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-workspace-toolbar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Filter, Tooltip],
			host: { class: "flex shrink-0 items-center gap-1 px-4 pt-1" },
			template: `
    <div class="@container relative flex min-w-0 flex-1 items-center justify-between gap-1">
      <div
        class="flex min-w-0"
        [class.invisible]="searchOpen()"
      >
        <ng-content />
      </div>
      @if (canSearch()) {
        <button
          #searchButton
          coreButton
          type="button"
          class="shrink-0"
          severity="secondary"
          text
          tooltipPosition="above"
          [attr.aria-label]="searchLabel()"
          [coreTooltip]="searchLabel()"
          [class.invisible]="searchOpen()"
          (click)="setSearchOpen(true)"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            aria-hidden="true"
            >search</i
          >
        </button>
      }
      @if (searchOpen()) {
        <core-filter
          class="absolute inset-x-0"
          clearLabel="Close search"
          [(value)]="filterValue"
          (clear)="setSearchOpen(false)"
        />
      }
    </div>
    <button
      coreButton
      type="button"
      class="shrink-0 px-2"
      text
      tooltipPosition="above"
      [attr.severity]="deleteDisabled() ? 'secondary' : 'danger'"
      [coreTooltip]="deleteLabel()"
      [attr.aria-label]="deleteLabel() + ' (' + selectedCount() + ')'"
      [disabled]="deleteDisabled()"
      (click)="deleteSelected.emit()"
    >
      <i
        coreButtonIcon
        class="material-symbols-outlined"
        aria-hidden="true"
        >delete</i
      >
      <span
        coreButtonLabel
        class="tabular-nums"
        >{{ selectedCount() }}</span
      >
    </button>
  `
		}]
	}],
	propDecorators: {
		canSearch: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canSearch",
				required: true
			}]
		}],
		searchLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "searchLabel",
				required: true
			}]
		}],
		deleteLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "deleteLabel",
				required: true
			}]
		}],
		selectedCount: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectedCount",
				required: true
			}]
		}],
		deleteUnavailable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "deleteUnavailable",
				required: false
			}]
		}],
		filterValue: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filterValue",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["filterValueChange"]
		}],
		deleteSelected: [{
			type: i0.Output,
			args: ["deleteSelected"]
		}],
		filter: [{
			type: i0.ViewChild,
			args: [i0.forwardRef(() => Filter), { isSignal: true }]
		}],
		searchButton: [{
			type: i0.ViewChild,
			args: ["searchButton", { isSignal: true }]
		}],
		createButton: [{
			type: i0.ContentChild,
			args: ["createButton", { isSignal: true }]
		}]
	}
});
var NameEditPopover = class NameEditPopover {
	value = model.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	title = input.required(...ngDevMode ? [{ debugName: "title" }] : /* istanbul ignore next */ []);
	placeholder = input.required(...ngDevMode ? [{ debugName: "placeholder" }] : /* istanbul ignore next */ []);
	save = output();
	visibleChange = output();
	popover = viewChild.required("popover", ...ngDevMode ? [{ debugName: "popover" }] : /* istanbul ignore next */ []);
	overlay = inject(Overlay);
	viewContainer = inject(ViewContainerRef);
	ref;
	show(target) {
		this.hide();
		const ref = this.overlay.create({
			positionStrategy: this.overlay.position().flexibleConnectedTo(target).withPositions([{
				originX: "start",
				originY: "bottom",
				overlayX: "start",
				overlayY: "top"
			}, {
				originX: "end",
				originY: "top",
				overlayX: "end",
				overlayY: "bottom"
			}]).withPush(true),
			scrollStrategy: this.overlay.scrollStrategies.reposition(),
			hasBackdrop: true,
			backdropClass: "cdk-overlay-transparent-backdrop"
		});
		this.ref = ref;
		ref.attach(new TemplatePortal(this.popover(), this.viewContainer));
		ref.backdropClick().subscribe(() => this.hide());
		ref.keydownEvents().subscribe((event) => {
			if (event.key === "Escape") this.hide();
		});
		this.visibleChange.emit(true);
	}
	hide() {
		if (!this.ref) return;
		const ref = this.ref;
		this.ref = void 0;
		ref.dispose();
		this.visibleChange.emit(false);
	}
	ngOnDestroy() {
		this.hide();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: NameEditPopover,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: NameEditPopover,
		isStandalone: true,
		selector: "core-name-edit-popover",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			title: {
				classPropertyName: "title",
				publicName: "title",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			placeholder: {
				classPropertyName: "placeholder",
				publicName: "placeholder",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			save: "save",
			visibleChange: "visibleChange"
		},
		viewQueries: [{
			propertyName: "popover",
			first: true,
			predicate: ["popover"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #popover>
      <div
        class="core-root core-popover"
        role="dialog"
        cdkTrapFocus
        [attr.aria-label]="title()"
        [cdkTrapFocusAutoCapture]="true"
      >
        <div class="flex w-full max-w-72 flex-col gap-2">
          <div class="flex items-center justify-between">
            <span class="font-semibold">{{ title() }}</span>
          </div>
          <input
            type="text"
            coreInput
            [attr.aria-label]="title()"
            [placeholder]="placeholder()"
            [(ngModel)]="value"
            (keydown.enter)="save.emit()"
          />
          <div class="flex w-full items-center justify-end">
            <div class="flex items-center gap-2">
              <button
                type="button"
                coreButton
                severity="secondary"
                variant="outlined"
                size="small"
                (click)="hide()"
              >
                Cancel
              </button>
              <button
                type="button"
                coreButton
                size="small"
                (click)="save.emit()"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </ng-template>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: CdkTrapFocus,
				selector: "[cdkTrapFocus]",
				inputs: ["cdkTrapFocus", "cdkTrapFocusAutoCapture"],
				exportAs: ["cdkTrapFocus"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: NameEditPopover,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-name-edit-popover",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [CdkTrapFocus, FormsModule],
			template: `
    <ng-template #popover>
      <div
        class="core-root core-popover"
        role="dialog"
        cdkTrapFocus
        [attr.aria-label]="title()"
        [cdkTrapFocusAutoCapture]="true"
      >
        <div class="flex w-full max-w-72 flex-col gap-2">
          <div class="flex items-center justify-between">
            <span class="font-semibold">{{ title() }}</span>
          </div>
          <input
            type="text"
            coreInput
            [attr.aria-label]="title()"
            [placeholder]="placeholder()"
            [(ngModel)]="value"
            (keydown.enter)="save.emit()"
          />
          <div class="flex w-full items-center justify-end">
            <div class="flex items-center gap-2">
              <button
                type="button"
                coreButton
                severity="secondary"
                variant="outlined"
                size="small"
                (click)="hide()"
              >
                Cancel
              </button>
              <button
                type="button"
                coreButton
                size="small"
                (click)="save.emit()"
              >
                Save
              </button>
            </div>
          </div>
        </div>
      </div>
    </ng-template>
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		title: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "title",
				required: true
			}]
		}],
		placeholder: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholder",
				required: true
			}]
		}],
		save: [{
			type: i0.Output,
			args: ["save"]
		}],
		visibleChange: [{
			type: i0.Output,
			args: ["visibleChange"]
		}],
		popover: [{
			type: i0.ViewChild,
			args: ["popover", { isSignal: true }]
		}]
	}
});
var WorkspaceTreeItem = class WorkspaceTreeItem {
	panels = inject(PanelService);
	nodeId = input.required(...ngDevMode ? [{ debugName: "nodeId" }] : /* istanbul ignore next */ []);
	level = input(0, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	isFiltering = input(false, {
		...ngDevMode ? { debugName: "isFiltering" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	filteredVisibleNodeIds = input([], ...ngDevMode ? [{ debugName: "filteredVisibleNodeIds" }] : /* istanbul ignore next */ []);
	selectedNodeIds = input([], ...ngDevMode ? [{ debugName: "selectedNodeIds" }] : /* istanbul ignore next */ []);
	nodeSelectionToggled = output();
	formTreeItemRef = viewChild("formTreeItem", {
		...ngDevMode ? { debugName: "formTreeItemRef" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	folderTreeItemRef = viewChild("folderTreeItem", {
		...ngDevMode ? { debugName: "folderTreeItemRef" } : /* istanbul ignore next */ {},
		read: ElementRef
	});
	formNamePopover = viewChild("formNamePopover", {
		...ngDevMode ? { debugName: "formNamePopover" } : /* istanbul ignore next */ {},
		read: NameEditPopover
	});
	folderNamePopover = viewChild("folderNamePopover", {
		...ngDevMode ? { debugName: "folderNamePopover" } : /* istanbul ignore next */ {},
		read: NameEditPopover
	});
	formService = inject(CoreFormService);
	libraryService = inject(CoreLibraryService);
	mouseInsideService = inject(MouseInsideService);
	createFormDialogService = inject(CreateFormDialogService);
	isMouseInsideRoot = this.mouseInsideService.isMouseInside;
	hasStorageRecoveryIssues = this.formService.hasStorageRecoveryIssues;
	hasFormStorageRecoveryIssue = this.formService.hasFormStorageRecoveryIssue;
	linePaddingLeft = `calc(var(--spacing) * 3.75)`;
	folderMenuItems = [
		{
			label: "Add Folder",
			matIcon: "create_new_folder",
			command: () => this.addFolderInFolder()
		},
		{
			label: "Add Form",
			matIcon: "note_add",
			command: () => this.addFormInFolder()
		},
		{
			label: "Edit Name",
			matIcon: "edit",
			command: () => {
				this.folderNameEditValue.set(this.node()?.name ?? "");
				this.folderNamePopover()?.show(this.folderTreeItemRef()?.nativeElement);
			}
		},
		{
			label: "Delete",
			matIcon: "delete",
			warn: true,
			command: () => this.deleteNode()
		}
	];
	isMouseInside = signal(false, ...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	formNameEditValue = signal("", ...ngDevMode ? [{ debugName: "formNameEditValue" }] : /* istanbul ignore next */ []);
	formNamePopoverVisible = signal(false, ...ngDevMode ? [{ debugName: "formNamePopoverVisible" }] : /* istanbul ignore next */ []);
	folderNameEditValue = signal("", ...ngDevMode ? [{ debugName: "folderNameEditValue" }] : /* istanbul ignore next */ []);
	folderMenuVisible = signal(false, ...ngDevMode ? [{ debugName: "folderMenuVisible" }] : /* istanbul ignore next */ []);
	folderPopoverVisible = signal(false, ...ngDevMode ? [{ debugName: "folderPopoverVisible" }] : /* istanbul ignore next */ []);
	alwaysShowFolderActions = computed(() => this.folderMenuVisible() || this.folderPopoverVisible(), ...ngDevMode ? [{ debugName: "alwaysShowFolderActions" }] : /* istanbul ignore next */ []);
	node = computed(() => {
		return this.formService.hierarchyNodeMap()[this.nodeId()];
	}, ...ngDevMode ? [{ debugName: "node" }] : /* istanbul ignore next */ []);
	isExpanded = computed(() => {
		const n = this.node();
		return n && n.type === "folder" ? !!n.isExpanded : false;
	}, ...ngDevMode ? [{ debugName: "isExpanded" }] : /* istanbul ignore next */ []);
	childIds = computed(() => {
		const n = this.node();
		return n && n.type === "folder" ? n.childIds : [];
	}, ...ngDevMode ? [{ debugName: "childIds" }] : /* istanbul ignore next */ []);
	hasChildren = computed(() => this.childIds().length > 0, ...ngDevMode ? [{ debugName: "hasChildren" }] : /* istanbul ignore next */ []);
	formFieldCount = computed(() => {
		const n = this.node();
		return n && n.type === "form" ? n.fieldCount : void 0;
	}, ...ngDevMode ? [{ debugName: "formFieldCount" }] : /* istanbul ignore next */ []);
	uiConfigLabel = computed(() => {
		const n = this.node();
		if (n && n.type === "form" && n.libraryId) return this.libraryService.getLibraryLabel(n.libraryId) ?? null;
		return null;
	}, ...ngDevMode ? [{ debugName: "uiConfigLabel" }] : /* istanbul ignore next */ []);
	isActiveForm = computed(() => {
		const n = this.node();
		return n && n.type === "form" ? this.formService.activeFormId() === n.id : false;
	}, ...ngDevMode ? [{ debugName: "isActiveForm" }] : /* istanbul ignore next */ []);
	lines = computed(() => Array.from({ length: this.level() }, (_, i) => i), ...ngDevMode ? [{ debugName: "lines" }] : /* istanbul ignore next */ []);
	paddingLeft = computed(() => `calc(((var(--spacing) * 4) * ${this.level()}) + var(--spacing))`, ...ngDevMode ? [{ debugName: "paddingLeft" }] : /* istanbul ignore next */ []);
	toggleFolder(event) {
		if (event.defaultPrevented) return;
		event.preventDefault();
		this.formService.toggleFolderExpansion(this.nodeId());
	}
	selectForm(event) {
		if (event.defaultPrevented) return;
		event.preventDefault();
		const n = this.node();
		if (n && n.type === "form") {
			if (this.isActiveForm()) this.panels.setActiveLHSPanel("fields");
			else this.formService.setActiveForm(n.id);
		}
	}
	addFolderInFolder() {
		this.formService.createFolder?.("New Folder", this.nodeId());
	}
	addFormInFolder() {
		this.createFormDialogService.open(this.nodeId());
	}
	deleteNode() {
		this.formService.deleteWorkspaceNode(this.nodeId());
	}
	editFormName() {
		this.formNameEditValue.set(this.node()?.name ?? "");
		this.formNamePopover()?.show(this.formTreeItemRef()?.nativeElement);
	}
	setFormName() {
		const newName = this.formNameEditValue();
		this.formNameEditValue.set("");
		this.formNamePopover()?.hide();
		if (!newName.trim()) return;
		this.formService.setWorkspaceNodeName(this.nodeId(), newName);
	}
	setFolderName() {
		const newName = this.folderNameEditValue();
		this.folderNameEditValue.set("");
		this.folderNamePopover()?.hide();
		if (!newName.trim()) return;
		this.formService.setWorkspaceNodeName(this.nodeId(), newName);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: WorkspaceTreeItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: WorkspaceTreeItem,
		isStandalone: true,
		selector: "core-workspace-tree-item",
		inputs: {
			nodeId: {
				classPropertyName: "nodeId",
				publicName: "nodeId",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isFiltering: {
				classPropertyName: "isFiltering",
				publicName: "isFiltering",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			filteredVisibleNodeIds: {
				classPropertyName: "filteredVisibleNodeIds",
				publicName: "filteredVisibleNodeIds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectedNodeIds: {
				classPropertyName: "selectedNodeIds",
				publicName: "selectedNodeIds",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { nodeSelectionToggled: "nodeSelectionToggled" },
		viewQueries: [
			{
				propertyName: "formTreeItemRef",
				first: true,
				predicate: ["formTreeItem"],
				descendants: true,
				read: ElementRef,
				isSignal: true
			},
			{
				propertyName: "folderTreeItemRef",
				first: true,
				predicate: ["folderTreeItem"],
				descendants: true,
				read: ElementRef,
				isSignal: true
			},
			{
				propertyName: "formNamePopover",
				first: true,
				predicate: ["formNamePopover"],
				descendants: true,
				read: NameEditPopover,
				isSignal: true
			},
			{
				propertyName: "folderNamePopover",
				first: true,
				predicate: ["folderNamePopover"],
				descendants: true,
				read: NameEditPopover,
				isSignal: true
			}
		],
		ngImport: i0,
		template: `
    @if (node(); as workspaceNode) {
      @if (workspaceNode.type === 'folder') {
        <div class="flex flex-col">
          <core-tree-item
            #folderTreeItem
            isParent
            [level]="level()"
            [isExpanded]="isExpanded()"
            [alwaysShowActions]="alwaysShowFolderActions()"
            [selectionLabel]="'Select folder ' + workspaceNode.name"
            [isSelected]="selectedNodeIds().includes(nodeId())"
            [selectionDisabled]="hasStorageRecoveryIssues()"
            (selectionToggled)="nodeSelectionToggled.emit(nodeId())"
            (click)="toggleFolder($event)"
            (toggleClicked)="toggleFolder($event)"
          >
            <i
              itemIcon
              class="material-symbols-outlined text-primary"
            >
              {{ isExpanded() ? 'folder_open' : 'folder' }}
            </i>
            <span class="truncate font-medium">{{ workspaceNode.name }}</span>

            <ng-container actions>
              <button
                coreButton
                text
                class="size-8"
                rounded
                aria-label="Options"
                coreTooltip="Options"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="$event.preventDefault(); folderMenu.toggle($event)"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  more_vert
                </i>
              </button>
            </ng-container>
          </core-tree-item>

          <core-menu
            #folderMenu
            [model]="folderMenuItems"
            (opened)="folderMenuVisible.set(true)"
            (dismissed)="folderMenuVisible.set(false)"
          >
            <ng-template
              #item
              let-item
            >
              <button
                type="button"
                tabindex="-1"
                class="flex w-full cursor-pointer items-center gap-2 px-3 py-1 text-start"
                [class.text-button-text-danger]="item.warn"
              >
                <i
                  class="material-symbols-outlined"
                  aria-hidden="true"
                >
                  {{ item.matIcon }}
                </i>
                {{ item.label }}
              </button>
            </ng-template>
          </core-menu>

          <core-name-edit-popover
            #folderNamePopover
            title="Edit Folder Name"
            placeholder="Folder name"
            [(value)]="folderNameEditValue"
            (save)="setFolderName()"
            (visibleChange)="folderPopoverVisible.set($event)"
          />

          <ul>
            @if (hasChildren()) {
              @for (childId of childIds(); track childId) {
                <li
                  [class.hidden]="
                    !isExpanded() || (isFiltering() && !filteredVisibleNodeIds().includes(childId))
                  "
                  [class.block]="isExpanded()"
                >
                  <core-workspace-tree-item
                    [nodeId]="childId"
                    [level]="level() + 1"
                    [isFiltering]="isFiltering()"
                    [filteredVisibleNodeIds]="filteredVisibleNodeIds()"
                    [selectedNodeIds]="selectedNodeIds()"
                    (nodeSelectionToggled)="nodeSelectionToggled.emit($event)"
                  />
                </li>
              }
            } @else if (isExpanded()) {
              <li>
                <core-tree-item
                  canInteract="false"
                  [level]="level() + 1"
                >
                  <i class="material-symbols-outlined text-muted-color">box</i>
                  <span class="text-sm text-muted-color italic">No forms yet</span>
                </core-tree-item>
              </li>
            }
          </ul>
        </div>
      } @else if (workspaceNode.type === 'form') {
        <core-tree-item
          #formTreeItem
          iconTile
          [level]="level()"
          [isActive]="isActiveForm()"
          [alwaysShowActions]="formNamePopoverVisible()"
          [selectionLabel]="'Select form ' + workspaceNode.name"
          [isSelected]="selectedNodeIds().includes(nodeId())"
          [selectionDisabled]="hasStorageRecoveryIssues()"
          (selectionToggled)="nodeSelectionToggled.emit(nodeId())"
          (click)="selectForm($event)"
        >
          <i
            itemIcon
            class="material-symbols-outlined"
            >description</i
          >
          <button
            type="button"
            class="flex min-w-0 flex-col gap-1 rounded-sm text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            [attr.aria-label]="'Open form ' + workspaceNode.name"
            [attr.aria-pressed]="isActiveForm()"
            [disabled]="hasFormStorageRecoveryIssue()"
          >
            <span class="leading-snug font-semibold [overflow-wrap:anywhere]">{{
              workspaceNode.name
            }}</span>
            <span
              class="flex flex-wrap items-center gap-x-1.5 text-sm leading-snug text-muted-color"
            >
              @if (uiConfigLabel()) {
                <span>{{ uiConfigLabel() }}</span>
              }
              @if (formFieldCount() !== undefined) {
                <span>&bull;</span>
                <span>{{ formFieldCount() + ' Field' + (formFieldCount() === 1 ? '' : 's') }}</span>
              }
            </span>
          </button>

          <ng-container actions>
            <button
              coreButton
              type="button"
              text
              class="size-8"
              rounded
              coreTooltip="Edit name"
              tooltipPosition="above"
              [attr.aria-label]="'Edit form name ' + workspaceNode.name"
              [disabled]="hasStorageRecoveryIssues()"
              (click)="$event.preventDefault(); editFormName()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                aria-hidden="true"
              >
                edit
              </i>
            </button>
            <button
              coreButton
              type="button"
              text
              class="size-8"
              rounded
              severity="danger"
              coreTooltip="Delete form"
              tooltipPosition="above"
              [attr.aria-label]="'Delete form ' + workspaceNode.name"
              [disabled]="hasStorageRecoveryIssues()"
              (click)="$event.preventDefault(); deleteNode()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                aria-hidden="true"
              >
                delete
              </i>
            </button>
          </ng-container>
        </core-tree-item>

        <core-name-edit-popover
          #formNamePopover
          title="Edit Form Name"
          placeholder="Form name"
          [(value)]="formNameEditValue"
          (save)="setFormName()"
          (visibleChange)="formNamePopoverVisible.set($event)"
        />
      }
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: WorkspaceTreeItem,
				selector: "core-workspace-tree-item",
				inputs: [
					"nodeId",
					"level",
					"isFiltering",
					"filteredVisibleNodeIds",
					"selectedNodeIds"
				],
				outputs: ["nodeSelectionToggled"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: TreeItem,
				selector: "core-tree-item",
				inputs: [
					"level",
					"isTabRoot",
					"isExpanded",
					"isParent",
					"isActive",
					"canInteract",
					"alwaysShowActions",
					"selectionLabel",
					"iconTile",
					"isSelected",
					"selectionDisabled"
				],
				outputs: ["toggleClicked", "selectionToggled"]
			},
			{
				kind: "component",
				type: Menu,
				selector: "core-menu",
				inputs: ["model", "ariaLabel"],
				outputs: ["opened", "dismissed"]
			},
			{
				kind: "component",
				type: NameEditPopover,
				selector: "core-name-edit-popover",
				inputs: [
					"value",
					"title",
					"placeholder"
				],
				outputs: [
					"valueChange",
					"save",
					"visibleChange"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: WorkspaceTreeItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-workspace-tree-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Tooltip,
				TreeItem,
				Menu,
				NameEditPopover
			],
			template: `
    @if (node(); as workspaceNode) {
      @if (workspaceNode.type === 'folder') {
        <div class="flex flex-col">
          <core-tree-item
            #folderTreeItem
            isParent
            [level]="level()"
            [isExpanded]="isExpanded()"
            [alwaysShowActions]="alwaysShowFolderActions()"
            [selectionLabel]="'Select folder ' + workspaceNode.name"
            [isSelected]="selectedNodeIds().includes(nodeId())"
            [selectionDisabled]="hasStorageRecoveryIssues()"
            (selectionToggled)="nodeSelectionToggled.emit(nodeId())"
            (click)="toggleFolder($event)"
            (toggleClicked)="toggleFolder($event)"
          >
            <i
              itemIcon
              class="material-symbols-outlined text-primary"
            >
              {{ isExpanded() ? 'folder_open' : 'folder' }}
            </i>
            <span class="truncate font-medium">{{ workspaceNode.name }}</span>

            <ng-container actions>
              <button
                coreButton
                text
                class="size-8"
                rounded
                aria-label="Options"
                coreTooltip="Options"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="$event.preventDefault(); folderMenu.toggle($event)"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  more_vert
                </i>
              </button>
            </ng-container>
          </core-tree-item>

          <core-menu
            #folderMenu
            [model]="folderMenuItems"
            (opened)="folderMenuVisible.set(true)"
            (dismissed)="folderMenuVisible.set(false)"
          >
            <ng-template
              #item
              let-item
            >
              <button
                type="button"
                tabindex="-1"
                class="flex w-full cursor-pointer items-center gap-2 px-3 py-1 text-start"
                [class.text-button-text-danger]="item.warn"
              >
                <i
                  class="material-symbols-outlined"
                  aria-hidden="true"
                >
                  {{ item.matIcon }}
                </i>
                {{ item.label }}
              </button>
            </ng-template>
          </core-menu>

          <core-name-edit-popover
            #folderNamePopover
            title="Edit Folder Name"
            placeholder="Folder name"
            [(value)]="folderNameEditValue"
            (save)="setFolderName()"
            (visibleChange)="folderPopoverVisible.set($event)"
          />

          <ul>
            @if (hasChildren()) {
              @for (childId of childIds(); track childId) {
                <li
                  [class.hidden]="
                    !isExpanded() || (isFiltering() && !filteredVisibleNodeIds().includes(childId))
                  "
                  [class.block]="isExpanded()"
                >
                  <core-workspace-tree-item
                    [nodeId]="childId"
                    [level]="level() + 1"
                    [isFiltering]="isFiltering()"
                    [filteredVisibleNodeIds]="filteredVisibleNodeIds()"
                    [selectedNodeIds]="selectedNodeIds()"
                    (nodeSelectionToggled)="nodeSelectionToggled.emit($event)"
                  />
                </li>
              }
            } @else if (isExpanded()) {
              <li>
                <core-tree-item
                  canInteract="false"
                  [level]="level() + 1"
                >
                  <i class="material-symbols-outlined text-muted-color">box</i>
                  <span class="text-sm text-muted-color italic">No forms yet</span>
                </core-tree-item>
              </li>
            }
          </ul>
        </div>
      } @else if (workspaceNode.type === 'form') {
        <core-tree-item
          #formTreeItem
          iconTile
          [level]="level()"
          [isActive]="isActiveForm()"
          [alwaysShowActions]="formNamePopoverVisible()"
          [selectionLabel]="'Select form ' + workspaceNode.name"
          [isSelected]="selectedNodeIds().includes(nodeId())"
          [selectionDisabled]="hasStorageRecoveryIssues()"
          (selectionToggled)="nodeSelectionToggled.emit(nodeId())"
          (click)="selectForm($event)"
        >
          <i
            itemIcon
            class="material-symbols-outlined"
            >description</i
          >
          <button
            type="button"
            class="flex min-w-0 flex-col gap-1 rounded-sm text-left focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
            [attr.aria-label]="'Open form ' + workspaceNode.name"
            [attr.aria-pressed]="isActiveForm()"
            [disabled]="hasFormStorageRecoveryIssue()"
          >
            <span class="leading-snug font-semibold [overflow-wrap:anywhere]">{{
              workspaceNode.name
            }}</span>
            <span
              class="flex flex-wrap items-center gap-x-1.5 text-sm leading-snug text-muted-color"
            >
              @if (uiConfigLabel()) {
                <span>{{ uiConfigLabel() }}</span>
              }
              @if (formFieldCount() !== undefined) {
                <span>&bull;</span>
                <span>{{ formFieldCount() + ' Field' + (formFieldCount() === 1 ? '' : 's') }}</span>
              }
            </span>
          </button>

          <ng-container actions>
            <button
              coreButton
              type="button"
              text
              class="size-8"
              rounded
              coreTooltip="Edit name"
              tooltipPosition="above"
              [attr.aria-label]="'Edit form name ' + workspaceNode.name"
              [disabled]="hasStorageRecoveryIssues()"
              (click)="$event.preventDefault(); editFormName()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                aria-hidden="true"
              >
                edit
              </i>
            </button>
            <button
              coreButton
              type="button"
              text
              class="size-8"
              rounded
              severity="danger"
              coreTooltip="Delete form"
              tooltipPosition="above"
              [attr.aria-label]="'Delete form ' + workspaceNode.name"
              [disabled]="hasStorageRecoveryIssues()"
              (click)="$event.preventDefault(); deleteNode()"
            >
              <i
                coreButtonIcon
                class="material-symbols-outlined"
                aria-hidden="true"
              >
                delete
              </i>
            </button>
          </ng-container>
        </core-tree-item>

        <core-name-edit-popover
          #formNamePopover
          title="Edit Form Name"
          placeholder="Form name"
          [(value)]="formNameEditValue"
          (save)="setFormName()"
          (visibleChange)="formNamePopoverVisible.set($event)"
        />
      }
    }
  `
		}]
	}],
	propDecorators: {
		nodeId: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "nodeId",
				required: true
			}]
		}],
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		isFiltering: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isFiltering",
				required: false
			}]
		}],
		filteredVisibleNodeIds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "filteredVisibleNodeIds",
				required: false
			}]
		}],
		selectedNodeIds: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectedNodeIds",
				required: false
			}]
		}],
		nodeSelectionToggled: [{
			type: i0.Output,
			args: ["nodeSelectionToggled"]
		}],
		formTreeItemRef: [{
			type: i0.ViewChild,
			args: ["formTreeItem", {
				read: ElementRef,
				isSignal: true
			}]
		}],
		folderTreeItemRef: [{
			type: i0.ViewChild,
			args: ["folderTreeItem", {
				read: ElementRef,
				isSignal: true
			}]
		}],
		formNamePopover: [{
			type: i0.ViewChild,
			args: ["formNamePopover", {
				read: NameEditPopover,
				isSignal: true
			}]
		}],
		folderNamePopover: [{
			type: i0.ViewChild,
			args: ["folderNamePopover", {
				read: NameEditPopover,
				isSignal: true
			}]
		}]
	}
});
var ValidationsTabContent = class ValidationsTabContent {
	forms = inject(CoreFormService);
	document = inject(DOCUMENT$1);
	destroyRef = inject(DestroyRef);
	filterValue = signal("", ...ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []);
	selectedIds = linkedSignal({
		...ngDevMode ? { debugName: "selectedIds" } : /* istanbul ignore next */ {},
		source: this.forms.validations,
		computation: (rules, previous) => previous?.value.filter((id) => rules.some((rule) => rule.id === id)) ?? []
	});
	editing = signal(null, ...ngDevMode ? [{ debugName: "editing" }] : /* istanbul ignore next */ []);
	editingRule = computed(() => {
		const rule = this.editing();
		return rule && rule !== "new" ? rule : void 0;
	}, ...ngDevMode ? [{ debugName: "editingRule" }] : /* istanbul ignore next */ []);
	reservedNames = computed(() => this.forms.validations().map((rule) => rule.name), ...ngDevMode ? [{ debugName: "reservedNames" }] : /* istanbul ignore next */ []);
	busy = signal(false, ...ngDevMode ? [{ debugName: "busy" }] : /* istanbul ignore next */ []);
	error = signal("", ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	unavailable = computed(() => this.busy() || this.forms.validationsLoading() || !!this.forms.validationsLoadError(), ...ngDevMode ? [{ debugName: "unavailable" }] : /* istanbul ignore next */ []);
	filteredValidations = computed(() => {
		const query = this.filterValue().trim().toLowerCase();
		return this.forms.validations().filter((rule) => rule.name.toLowerCase().includes(query));
	}, ...ngDevMode ? [{ debugName: "filteredValidations" }] : /* istanbul ignore next */ []);
	open(rule) {
		this.error.set("");
		this.editing.set(rule);
	}
	close() {
		if (!this.busy()) this.editing.set(null);
	}
	save({ name, rule }) {
		const id = this.editingRule()?.id;
		this.run(() => this.forms.saveValidation$({
			name,
			expression: rule.expression,
			message: rule.message ?? ""
		}, id), "Could not save this validation. Check that its name is unique and try again.", () => this.editing.set(null));
	}
	remove(rule) {
		if (this.document.defaultView?.confirm(`Delete validation "${rule.name}"? Existing field copies will be kept.`)) this.run(() => this.forms.deleteValidation$(rule.id), "Could not delete this validation. Try again.");
	}
	toggleSelection(id) {
		if (this.unavailable()) return;
		this.selectedIds.update((ids) => ids.includes(id) ? ids.filter((selected) => selected !== id) : [...ids, id]);
	}
	removeSelected() {
		const ids = this.selectedIds();
		if (this.unavailable() || !ids.length) return;
		if (this.document.defaultView?.confirm(`Delete ${ids.length} selected validations? Existing field copies will be kept.`)) this.run(() => from(ids).pipe(concatMap((id) => this.forms.deleteValidation$(id))), "Could not delete all selected validations. Try again.");
	}
	downloadBackup() {
		saveAs(new Blob([this.forms.getStorageRecoveryBackup("validations")], { type: "application/json" }), "formly-validations-recovery.json");
	}
	reset() {
		if (this.document.defaultView?.confirm("Reset the corrupted validation catalog? Download a backup first. Your forms will be kept.")) this.run(() => this.forms.resetValidations$(), "Could not reset saved validations. Try again.");
	}
	run(operation, errorMessage, saved) {
		if (this.busy()) return;
		this.busy.set(true);
		this.error.set("");
		defer(operation).pipe(takeUntilDestroyed(this.destroyRef), finalize(() => this.busy.set(false))).subscribe({
			next: () => saved?.(),
			error: () => this.error.set(errorMessage)
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ValidationsTabContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ValidationsTabContent,
		isStandalone: true,
		selector: "core-validations-tab-content",
		host: { classAttribute: "flex min-h-0 flex-1 flex-col gap-2 overflow-hidden" },
		ngImport: i0,
		template: `
    @if (!forms.validationStorageAvailable) {
      <core-empty
        label="Saved validations unavailable"
        description="This editor's storage provider does not support saved validations."
      />
    } @else {
      @let catalogReady = !forms.validationsLoadError() && !forms.validationsLoading();
      @let showValidationList = forms.validations().length > 0 || !!filterValue();
      <core-workspace-toolbar
        searchLabel="Search validations"
        deleteLabel="Delete selected validations"
        [canSearch]="catalogReady && showValidationList"
        [selectedCount]="selectedIds().length"
        [deleteUnavailable]="unavailable()"
        [(filterValue)]="filterValue"
        (deleteSelected)="removeSelected()"
      >
        <button
          #createButton
          coreButton
          class="min-w-0 @max-[13.5rem]:w-10 @max-[13.5rem]:px-1"
          aria-label="Create validation"
          coreTooltip="Create validation"
          tooltipPosition="above"
          [disabled]="unavailable()"
          (click)="open('new')"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            aria-hidden="true"
            >add</i
          >
          <span
            coreButtonLabel
            class="truncate @max-[13.5rem]:hidden"
            >Create validation</span
          >
        </button>
      </core-workspace-toolbar>
      @if (forms.validationsLoading()) {
        <p
          role="status"
          class="px-4"
        >
          Loading validations…
        </p>
      }
      @if (forms.validationRecoveryIssues().length) {
        <div
          role="alert"
          class="mx-4 flex flex-col gap-3"
        >
          <p>
            Saved validations could not be read. Download a backup before resetting this catalog.
            Your forms will be kept.
          </p>
          <div class="flex flex-wrap gap-2">
            <button
              coreButton
              severity="secondary"
              (click)="downloadBackup()"
            >
              Download backup
            </button>
            <button
              coreButton
              severity="danger"
              [disabled]="busy()"
              (click)="reset()"
            >
              Reset validations
            </button>
          </div>
        </div>
      } @else if (forms.validationsLoadError()) {
        <div
          role="alert"
          class="px-4"
        >
          <p>{{ forms.validationsLoadError() }}</p>
          <button
            coreButton
            text
            [disabled]="forms.validationsLoading()"
            (click)="forms.loadValidations()"
          >
            Try again
          </button>
        </div>
      }
      @if (error() && !editing()) {
        <p
          role="alert"
          class="px-4 text-red-700 dark:text-red-300"
        >
          {{ error() }}
        </p>
      }
      @if (catalogReady) {
        @if (showValidationList) {
          <ul class="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
            @for (rule of filteredValidations(); track rule.id) {
              <li>
                <core-tree-item
                  [selectionLabel]="'Select validation ' + rule.name"
                  [isSelected]="selectedIds().includes(rule.id)"
                  [selectionDisabled]="unavailable()"
                  (selectionToggled)="toggleSelection(rule.id)"
                >
                  <i
                    itemIcon
                    class="material-symbols-outlined text-content-secondary"
                    >rule</i
                  >
                  <div class="flex min-w-0 flex-col gap-0.5">
                    <span class="max-w-full truncate">{{ rule.name }}</span>
                    <span class="max-w-full truncate text-sm text-muted-color">{{
                      rule.message
                    }}</span>
                  </div>
                  <button
                    actions
                    coreButton
                    type="button"
                    text
                    rounded
                    class="size-8"
                    coreTooltip="Edit validation"
                    tooltipPosition="above"
                    [disabled]="busy()"
                    [attr.aria-label]="'Edit validation ' + rule.name"
                    (click)="open(rule)"
                  >
                    <i
                      coreButtonIcon
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >edit</i
                    >
                  </button>
                  <button
                    actions
                    coreButton
                    text
                    rounded
                    class="size-8"
                    severity="danger"
                    coreTooltip="Delete validation"
                    [disabled]="busy()"
                    [attr.aria-label]="'Delete validation ' + rule.name"
                    (click)="remove(rule)"
                  >
                    <i
                      coreButtonIcon
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >delete</i
                    >
                  </button>
                </core-tree-item>
              </li>
            } @empty {
              <li>
                <core-empty
                  label="No validations found"
                  description="Try adjusting your filter criteria."
                />
              </li>
            }
          </ul>
        } @else {
          <core-empty
            label="No validations yet"
            description="Create a validation to reuse it from a field's Custom Validation menu."
          />
        }
      }
    }

    <core-dialog
      [header]="editing() === 'new' ? 'Create validation' : 'Edit validation'"
      [visible]="!!editing()"
      [closable]="!busy()"
      [closeOnEscape]="!busy()"
      [style]="{ width: '36rem', maxWidth: 'calc(100vw - 32px)', maxHeight: 'calc(100dvh - 32px)' }"
      (visibleChange)="close()"
    >
      @if (editing()) {
        <p class="mb-4 text-sm text-muted-color">
          Selecting this validation on a field creates a copy. Changes here apply to future copies.
        </p>
        @if (error()) {
          <p
            role="alert"
            class="mb-3 text-red-700 dark:text-red-300"
          >
            {{ error() }}
          </p>
        }
        <core-validation-expression-editor
          [originalName]="editingRule()?.name ?? ''"
          [rule]="editingRule()"
          [reservedNames]="reservedNames()"
          [saving]="busy()"
          (saved)="save($event)"
          (cancelled)="close()"
        />
      }
    </core-dialog>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: TreeItem,
				selector: "core-tree-item",
				inputs: [
					"level",
					"isTabRoot",
					"isExpanded",
					"isParent",
					"isActive",
					"canInteract",
					"alwaysShowActions",
					"selectionLabel",
					"iconTile",
					"isSelected",
					"selectionDisabled"
				],
				outputs: ["toggleClicked", "selectionToggled"]
			},
			{
				kind: "component",
				type: ValidationExpressionEditor,
				selector: "core-validation-expression-editor",
				inputs: [
					"originalName",
					"rule",
					"reservedNames",
					"saving"
				],
				outputs: ["saved", "cancelled"]
			},
			{
				kind: "component",
				type: WorkspaceToolbar,
				selector: "core-workspace-toolbar",
				inputs: [
					"canSearch",
					"searchLabel",
					"deleteLabel",
					"selectedCount",
					"deleteUnavailable",
					"filterValue"
				],
				outputs: ["filterValueChange", "deleteSelected"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ValidationsTabContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-validations-tab-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Dialog,
				Empty,
				Tooltip,
				TreeItem,
				ValidationExpressionEditor,
				WorkspaceToolbar
			],
			host: { class: "flex min-h-0 flex-1 flex-col gap-2 overflow-hidden" },
			template: `
    @if (!forms.validationStorageAvailable) {
      <core-empty
        label="Saved validations unavailable"
        description="This editor's storage provider does not support saved validations."
      />
    } @else {
      @let catalogReady = !forms.validationsLoadError() && !forms.validationsLoading();
      @let showValidationList = forms.validations().length > 0 || !!filterValue();
      <core-workspace-toolbar
        searchLabel="Search validations"
        deleteLabel="Delete selected validations"
        [canSearch]="catalogReady && showValidationList"
        [selectedCount]="selectedIds().length"
        [deleteUnavailable]="unavailable()"
        [(filterValue)]="filterValue"
        (deleteSelected)="removeSelected()"
      >
        <button
          #createButton
          coreButton
          class="min-w-0 @max-[13.5rem]:w-10 @max-[13.5rem]:px-1"
          aria-label="Create validation"
          coreTooltip="Create validation"
          tooltipPosition="above"
          [disabled]="unavailable()"
          (click)="open('new')"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
            aria-hidden="true"
            >add</i
          >
          <span
            coreButtonLabel
            class="truncate @max-[13.5rem]:hidden"
            >Create validation</span
          >
        </button>
      </core-workspace-toolbar>
      @if (forms.validationsLoading()) {
        <p
          role="status"
          class="px-4"
        >
          Loading validations…
        </p>
      }
      @if (forms.validationRecoveryIssues().length) {
        <div
          role="alert"
          class="mx-4 flex flex-col gap-3"
        >
          <p>
            Saved validations could not be read. Download a backup before resetting this catalog.
            Your forms will be kept.
          </p>
          <div class="flex flex-wrap gap-2">
            <button
              coreButton
              severity="secondary"
              (click)="downloadBackup()"
            >
              Download backup
            </button>
            <button
              coreButton
              severity="danger"
              [disabled]="busy()"
              (click)="reset()"
            >
              Reset validations
            </button>
          </div>
        </div>
      } @else if (forms.validationsLoadError()) {
        <div
          role="alert"
          class="px-4"
        >
          <p>{{ forms.validationsLoadError() }}</p>
          <button
            coreButton
            text
            [disabled]="forms.validationsLoading()"
            (click)="forms.loadValidations()"
          >
            Try again
          </button>
        </div>
      }
      @if (error() && !editing()) {
        <p
          role="alert"
          class="px-4 text-red-700 dark:text-red-300"
        >
          {{ error() }}
        </p>
      }
      @if (catalogReady) {
        @if (showValidationList) {
          <ul class="min-h-0 flex-1 overflow-y-auto px-4 pb-4">
            @for (rule of filteredValidations(); track rule.id) {
              <li>
                <core-tree-item
                  [selectionLabel]="'Select validation ' + rule.name"
                  [isSelected]="selectedIds().includes(rule.id)"
                  [selectionDisabled]="unavailable()"
                  (selectionToggled)="toggleSelection(rule.id)"
                >
                  <i
                    itemIcon
                    class="material-symbols-outlined text-content-secondary"
                    >rule</i
                  >
                  <div class="flex min-w-0 flex-col gap-0.5">
                    <span class="max-w-full truncate">{{ rule.name }}</span>
                    <span class="max-w-full truncate text-sm text-muted-color">{{
                      rule.message
                    }}</span>
                  </div>
                  <button
                    actions
                    coreButton
                    type="button"
                    text
                    rounded
                    class="size-8"
                    coreTooltip="Edit validation"
                    tooltipPosition="above"
                    [disabled]="busy()"
                    [attr.aria-label]="'Edit validation ' + rule.name"
                    (click)="open(rule)"
                  >
                    <i
                      coreButtonIcon
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >edit</i
                    >
                  </button>
                  <button
                    actions
                    coreButton
                    text
                    rounded
                    class="size-8"
                    severity="danger"
                    coreTooltip="Delete validation"
                    [disabled]="busy()"
                    [attr.aria-label]="'Delete validation ' + rule.name"
                    (click)="remove(rule)"
                  >
                    <i
                      coreButtonIcon
                      class="material-symbols-outlined"
                      aria-hidden="true"
                      >delete</i
                    >
                  </button>
                </core-tree-item>
              </li>
            } @empty {
              <li>
                <core-empty
                  label="No validations found"
                  description="Try adjusting your filter criteria."
                />
              </li>
            }
          </ul>
        } @else {
          <core-empty
            label="No validations yet"
            description="Create a validation to reuse it from a field's Custom Validation menu."
          />
        }
      }
    }

    <core-dialog
      [header]="editing() === 'new' ? 'Create validation' : 'Edit validation'"
      [visible]="!!editing()"
      [closable]="!busy()"
      [closeOnEscape]="!busy()"
      [style]="{ width: '36rem', maxWidth: 'calc(100vw - 32px)', maxHeight: 'calc(100dvh - 32px)' }"
      (visibleChange)="close()"
    >
      @if (editing()) {
        <p class="mb-4 text-sm text-muted-color">
          Selecting this validation on a field creates a copy. Changes here apply to future copies.
        </p>
        @if (error()) {
          <p
            role="alert"
            class="mb-3 text-red-700 dark:text-red-300"
          >
            {{ error() }}
          </p>
        }
        <core-validation-expression-editor
          [originalName]="editingRule()?.name ?? ''"
          [rule]="editingRule()"
          [reservedNames]="reservedNames()"
          [saving]="busy()"
          (saved)="save($event)"
          (cancelled)="close()"
        />
      }
    </core-dialog>
  `
		}]
	}]
});
var FormsPanel = class FormsPanel {
	panels = inject(PanelService);
	activeTab = this.panels.activeWorkspaceTab;
	formService = inject(CoreFormService);
	mouseInsideService = inject(MouseInsideService);
	createFormDialogService = inject(CreateFormDialogService);
	importDialogService = inject(ImportDialogService);
	document = inject(DOCUMENT$1);
	formList = this.formService.formList;
	hierarchyRootNodeIds = this.formService.hierarchyRootNodeIds;
	hierarchyNodeMap = this.formService.hierarchyNodeMap;
	hasStorageRecoveryIssues = computed(() => this.formService.storageRecoveryIssues().some((issue) => issue.kind !== "validations"), ...ngDevMode ? [{ debugName: "hasStorageRecoveryIssues" }] : /* istanbul ignore next */ []);
	selectedNodeIds = linkedSignal({
		...ngDevMode ? { debugName: "selectedNodeIds" } : /* istanbul ignore next */ {},
		source: this.hierarchyNodeMap,
		computation: (nodes, previous) => previous?.value.filter((id) => !!nodes[id]) ?? []
	});
	filterValue = signal("", ...ngDevMode ? [{ debugName: "filterValue" }] : /* istanbul ignore next */ []);
	isFiltering = computed(() => !!this.filterValue().trim(), ...ngDevMode ? [{ debugName: "isFiltering" }] : /* istanbul ignore next */ []);
	showWorkspaceList = computed(() => this.isFiltering() || this.hierarchyRootNodeIds().length > 0, ...ngDevMode ? [{ debugName: "showWorkspaceList" }] : /* istanbul ignore next */ []);
	filteredVisibleNodeIds = computed(() => {
		const query = this.filterValue().trim().toLowerCase();
		if (!query) return [];
		const nodes = Object.values(this.hierarchyNodeMap());
		const visibleNodeIds = /* @__PURE__ */ new Set();
		nodes.filter((node) => node.name.toLowerCase().includes(query)).forEach((node) => {
			node.idPath.forEach((id) => visibleNodeIds.add(id));
			nodes.filter((candidate) => candidate.idPath.length >= node.idPath.length && node.idPath.every((id, index) => candidate.idPath[index] === id)).forEach((candidate) => visibleNodeIds.add(candidate.id));
		});
		return Array.from(visibleNodeIds);
	}, {
		...ngDevMode ? { debugName: "filteredVisibleNodeIds" } : /* istanbul ignore next */ {},
		equal: (a, b) => a.length === b.length && a.every((val, index) => val === b[index])
	});
	addNewForm() {
		this.createFormDialogService.open();
	}
	selectTab(tab) {
		if (tab !== "forms" && tab !== "validations") return;
		this.activeTab.set(tab);
		this.panels.setActiveLHSPanel("forms");
	}
	toggleNodeSelection(nodeId) {
		if (this.hasStorageRecoveryIssues()) return;
		this.selectedNodeIds.update((ids) => ids.includes(nodeId) ? ids.filter((id) => id !== nodeId) : [...ids, nodeId]);
	}
	deleteSelectedNodes() {
		if (this.hasStorageRecoveryIssues()) return;
		const selectedIds = this.selectedNodeIds();
		const nodes = this.hierarchyNodeMap();
		selectedIds.filter((id) => !nodes[id].idPath.slice(0, -1).some((parentId) => selectedIds.includes(parentId))).forEach((id) => this.formService.deleteWorkspaceNode(id));
	}
	addNewFolder() {
		this.formService.createFolder?.("New Folder");
	}
	openImportDialog() {
		this.importDialogService.open();
	}
	setMouseInside(isInside) {
		this.mouseInsideService.setMouseInside(isInside);
	}
	downloadRecoveryBackup() {
		const backup = this.formService.getStorageRecoveryBackup();
		const editorType = this.formService.storageRecoveryIssues()[0]?.editorType ?? "workspace";
		const url = URL.createObjectURL(new Blob([backup], { type: "application/json" }));
		const link = this.document.createElement("a");
		link.href = url;
		link.download = `formly-storage-recovery-${editorType}.json`;
		link.click();
		URL.revokeObjectURL(url);
	}
	resetCorruptedStorage() {
		if (this.document.defaultView?.confirm("Reset the corrupted local data for this workspace? Download a backup first if you may need it.")) this.formService.resetCorruptedStorage();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormsPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormsPanel,
		isStandalone: true,
		selector: "core-forms-panel",
		host: { classAttribute: "overflow-hidden h-full block" },
		providers: [MouseInsideService],
		ngImport: i0,
		template: `
    <core-panel-header
      class="[--panel-header-height:auto]"
      header="Workspace"
      subHeader="Create and manage forms and validations"
    />
    <mat-tab-group
      class="core-tabs min-h-0 flex-1"
      animationDuration="0ms"
      [preserveContent]="true"
      [selectedIndex]="['forms', 'validations'].indexOf(activeTab())"
      (selectedTabChange)="selectTab($event.index === 0 ? 'forms' : 'validations')"
      ><mat-tab
        ><ng-template mat-tab-label>
          <i
            class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
            aria-hidden="true"
            >description</i
          ><span>Forms</span>
        </ng-template>
        <div class="flex min-h-0 flex-1 flex-col overflow-hidden">
          <core-workspace-toolbar
            class="pb-2"
            searchLabel="Search forms and folders"
            deleteLabel="Delete selected items"
            [canSearch]="showWorkspaceList()"
            [selectedCount]="selectedNodeIds().length"
            [deleteUnavailable]="hasStorageRecoveryIssues()"
            [(filterValue)]="filterValue"
            (deleteSelected)="deleteSelectedNodes()"
          >
            <div
              role="group"
              class="min-w-0 [&>span]:flex"
              aria-label="Workspace actions"
            >
              <button
                coreButton
                class="shrink-0"
                severity="secondary"
                aria-label="New folder"
                coreTooltip="New folder"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="addNewFolder()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  create_new_folder
                </i>
              </button>
              <button
                coreButton
                class="shrink-0"
                severity="secondary"
                aria-label="Import Form"
                coreTooltip="Import Form"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="openImportDialog()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  upload
                </i>
              </button>
              <button
                #createButton
                coreButton
                class="min-w-0 @max-[17.5rem]:w-10 @max-[17.5rem]:px-1"
                aria-label="Create Form"
                coreTooltip="Create Form"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="addNewForm()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  add
                </i>
                <span
                  coreButtonLabel
                  class="truncate @max-[17.5rem]:hidden"
                  >Create Form</span
                >
              </button>
            </div>
          </core-workspace-toolbar>

          @if (hasStorageRecoveryIssues()) {
            <div
              role="alert"
              class="m-4 rounded border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950"
            >
              <strong>Saved workspace data could not be read.</strong>
              <p class="mt-1">
                Download a backup before resetting the affected local data. Other editor workspaces
                will not be changed.
              </p>
              <div class="mt-3 flex flex-wrap gap-2">
                <button
                  coreButton
                  severity="secondary"
                  outlined
                  (click)="downloadRecoveryBackup()"
                >
                  Download backup
                </button>
                <button
                  coreButton
                  severity="danger"
                  (click)="resetCorruptedStorage()"
                >
                  Reset local data
                </button>
              </div>
            </div>
          }

          @if (showWorkspaceList()) {
            <div class="flex min-h-0 flex-1 flex-col">
              @if (isFiltering() && !filteredVisibleNodeIds().length) {
                <core-empty
                  label="No forms or folders found"
                  description="Try adjusting your filter criteria."
                />
              } @else if (hierarchyRootNodeIds().length) {
                <ul
                  class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4"
                  (mouseenter)="setMouseInside(true)"
                  (mouseleave)="setMouseInside(false)"
                >
                  @for (nodeId of hierarchyRootNodeIds(); track nodeId) {
                    <li
                      [class.hidden]="isFiltering() && !filteredVisibleNodeIds().includes(nodeId)"
                    >
                      <core-workspace-tree-item
                        [nodeId]="nodeId"
                        [isFiltering]="isFiltering()"
                        [filteredVisibleNodeIds]="filteredVisibleNodeIds()"
                        [selectedNodeIds]="selectedNodeIds()"
                        (nodeSelectionToggled)="toggleNodeSelection($event)"
                      />
                    </li>
                  }
                </ul>
              }
            </div>
          } @else {
            <core-empty
              label="No Forms Yet"
              description="Click the + button to add a new form. You can also add the default form"
            >
              <button
                coreButton
                text
                [disabled]="hasStorageRecoveryIssues()"
                (click)="addNewForm()"
              >
                <i class="material-symbols-outlined">assignment</i>
                Create Form
              </button>
            </core-empty>
          }
        </div></mat-tab
      ><mat-tab
        ><ng-template mat-tab-label>
          <i
            class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
            aria-hidden="true"
            >rule</i
          ><span>Validations</span>
        </ng-template>
        <div class="flex min-h-0 flex-1 flex-col overflow-hidden">
          <core-validations-tab-content /></div></mat-tab
    ></mat-tab-group>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: MatTabsModule
			},
			{
				kind: "directive",
				type: i1$1.MatTabLabel,
				selector: "[mat-tab-label], [matTabLabel]"
			},
			{
				kind: "component",
				type: i1$1.MatTab,
				selector: "mat-tab",
				inputs: [
					"disabled",
					"label",
					"aria-label",
					"aria-labelledby",
					"labelClass",
					"bodyClass",
					"id"
				],
				exportAs: ["matTab"]
			},
			{
				kind: "component",
				type: i1$1.MatTabGroup,
				selector: "mat-tab-group",
				inputs: [
					"color",
					"fitInkBarToContent",
					"mat-stretch-tabs",
					"mat-align-tabs",
					"dynamicHeight",
					"selectedIndex",
					"headerPosition",
					"animationDuration",
					"contentTabIndex",
					"disablePagination",
					"disableRipple",
					"preserveContent",
					"backgroundColor",
					"aria-label",
					"aria-labelledby"
				],
				outputs: [
					"selectedIndexChange",
					"focusChange",
					"animationDone",
					"selectedTabChange"
				],
				exportAs: ["matTabGroup"]
			},
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			},
			{
				kind: "component",
				type: WorkspaceToolbar,
				selector: "core-workspace-toolbar",
				inputs: [
					"canSearch",
					"searchLabel",
					"deleteLabel",
					"selectedCount",
					"deleteUnavailable",
					"filterValue"
				],
				outputs: ["filterValueChange", "deleteSelected"]
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			},
			{
				kind: "component",
				type: WorkspaceTreeItem,
				selector: "core-workspace-tree-item",
				inputs: [
					"nodeId",
					"level",
					"isFiltering",
					"filteredVisibleNodeIds",
					"selectedNodeIds"
				],
				outputs: ["nodeSelectionToggled"]
			},
			{
				kind: "component",
				type: ValidationsTabContent,
				selector: "core-validations-tab-content"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormsPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-forms-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [MouseInsideService],
			imports: [
				MatTabsModule,
				Empty,
				Tooltip,
				WorkspaceToolbar,
				PanelHeader,
				WorkspaceTreeItem,
				ValidationsTabContent
			],
			host: { class: "overflow-hidden h-full block" },
			template: `
    <core-panel-header
      class="[--panel-header-height:auto]"
      header="Workspace"
      subHeader="Create and manage forms and validations"
    />
    <mat-tab-group
      class="core-tabs min-h-0 flex-1"
      animationDuration="0ms"
      [preserveContent]="true"
      [selectedIndex]="['forms', 'validations'].indexOf(activeTab())"
      (selectedTabChange)="selectTab($event.index === 0 ? 'forms' : 'validations')"
      ><mat-tab
        ><ng-template mat-tab-label>
          <i
            class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
            aria-hidden="true"
            >description</i
          ><span>Forms</span>
        </ng-template>
        <div class="flex min-h-0 flex-1 flex-col overflow-hidden">
          <core-workspace-toolbar
            class="pb-2"
            searchLabel="Search forms and folders"
            deleteLabel="Delete selected items"
            [canSearch]="showWorkspaceList()"
            [selectedCount]="selectedNodeIds().length"
            [deleteUnavailable]="hasStorageRecoveryIssues()"
            [(filterValue)]="filterValue"
            (deleteSelected)="deleteSelectedNodes()"
          >
            <div
              role="group"
              class="min-w-0 [&>span]:flex"
              aria-label="Workspace actions"
            >
              <button
                coreButton
                class="shrink-0"
                severity="secondary"
                aria-label="New folder"
                coreTooltip="New folder"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="addNewFolder()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  create_new_folder
                </i>
              </button>
              <button
                coreButton
                class="shrink-0"
                severity="secondary"
                aria-label="Import Form"
                coreTooltip="Import Form"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="openImportDialog()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  upload
                </i>
              </button>
              <button
                #createButton
                coreButton
                class="min-w-0 @max-[17.5rem]:w-10 @max-[17.5rem]:px-1"
                aria-label="Create Form"
                coreTooltip="Create Form"
                tooltipPosition="above"
                [disabled]="hasStorageRecoveryIssues()"
                (click)="addNewForm()"
              >
                <i
                  coreButtonIcon
                  class="material-symbols-outlined"
                >
                  add
                </i>
                <span
                  coreButtonLabel
                  class="truncate @max-[17.5rem]:hidden"
                  >Create Form</span
                >
              </button>
            </div>
          </core-workspace-toolbar>

          @if (hasStorageRecoveryIssues()) {
            <div
              role="alert"
              class="m-4 rounded border border-amber-300 bg-amber-50 p-3 text-sm text-amber-950"
            >
              <strong>Saved workspace data could not be read.</strong>
              <p class="mt-1">
                Download a backup before resetting the affected local data. Other editor workspaces
                will not be changed.
              </p>
              <div class="mt-3 flex flex-wrap gap-2">
                <button
                  coreButton
                  severity="secondary"
                  outlined
                  (click)="downloadRecoveryBackup()"
                >
                  Download backup
                </button>
                <button
                  coreButton
                  severity="danger"
                  (click)="resetCorruptedStorage()"
                >
                  Reset local data
                </button>
              </div>
            </div>
          }

          @if (showWorkspaceList()) {
            <div class="flex min-h-0 flex-1 flex-col">
              @if (isFiltering() && !filteredVisibleNodeIds().length) {
                <core-empty
                  label="No forms or folders found"
                  description="Try adjusting your filter criteria."
                />
              } @else if (hierarchyRootNodeIds().length) {
                <ul
                  class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4"
                  (mouseenter)="setMouseInside(true)"
                  (mouseleave)="setMouseInside(false)"
                >
                  @for (nodeId of hierarchyRootNodeIds(); track nodeId) {
                    <li
                      [class.hidden]="isFiltering() && !filteredVisibleNodeIds().includes(nodeId)"
                    >
                      <core-workspace-tree-item
                        [nodeId]="nodeId"
                        [isFiltering]="isFiltering()"
                        [filteredVisibleNodeIds]="filteredVisibleNodeIds()"
                        [selectedNodeIds]="selectedNodeIds()"
                        (nodeSelectionToggled)="toggleNodeSelection($event)"
                      />
                    </li>
                  }
                </ul>
              }
            </div>
          } @else {
            <core-empty
              label="No Forms Yet"
              description="Click the + button to add a new form. You can also add the default form"
            >
              <button
                coreButton
                text
                [disabled]="hasStorageRecoveryIssues()"
                (click)="addNewForm()"
              >
                <i class="material-symbols-outlined">assignment</i>
                Create Form
              </button>
            </core-empty>
          }
        </div></mat-tab
      ><mat-tab
        ><ng-template mat-tab-label>
          <i
            class="material-symbols-outlined size-6 shrink-0 overflow-hidden"
            aria-hidden="true"
            >rule</i
          ><span>Validations</span>
        </ng-template>
        <div class="flex min-h-0 flex-1 flex-col overflow-hidden">
          <core-validations-tab-content /></div></mat-tab
    ></mat-tab-group>
  `
		}]
	}]
});
var ModelEditPanel = class ModelEditPanel {
	form = viewChild.required(NgForm, ...ngDevMode ? [{ debugName: "form" }] : /* istanbul ignore next */ []);
	formService = inject(CoreFormService);
	activeForm = this.formService.activeForm;
	activeModel = this.formService.activeModel;
	isMouseOverContent = signal(false, ...ngDevMode ? [{ debugName: "isMouseOverContent" }] : /* istanbul ignore next */ []);
	activeModelJSON = computed(() => JSON.stringify(this.activeModel(), null, 2), ...ngDevMode ? [{ debugName: "activeModelJSON" }] : /* istanbul ignore next */ []);
	modifyActiveModel(newJSON) {
		if (this.form().valid) this.formService.modifyActiveModel(newJSON);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ModelEditPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ModelEditPanel,
		isStandalone: true,
		selector: "core-model-edit-panel",
		viewQueries: [{
			propertyName: "form",
			first: true,
			predicate: NgForm,
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <core-panel-header
      header="Model"
      subHeader="Edit the active form model"
    />
    @if (activeForm()) {
      <form
        #form="ngForm"
        class="panel-content"
      >
        <core-json-content
          class="h-full"
          name="json"
          coreJsonFormat
          editable
          [ngModel]="activeModelJSON()"
          (ngModelChange)="modifyActiveModel($event)"
        />
      </form>
    } @else {
      <core-empty-no-form />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: EmptyNoForm,
				selector: "core-empty-no-form"
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			},
			{
				kind: "component",
				type: JSONContent,
				selector: "core-json-content",
				inputs: ["editable"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.ɵNgNoValidate,
				selector: "form:not([ngNoForm]):not([ngNativeValidate])"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatusGroup,
				selector: "[formGroupName],[formArrayName],[ngModelGroup],[formGroup],[formArray],form:not([ngNoForm]),[ngForm]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: i1$2.NgForm,
				selector: "form:not([ngNoForm]):not([formGroup]):not([formArray]),ng-form,[ngForm]",
				inputs: ["ngFormOptions"],
				outputs: ["ngSubmit"],
				exportAs: ["ngForm"]
			},
			{
				kind: "directive",
				type: JSONFormatValidator,
				selector: "[coreJsonFormat]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ModelEditPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-model-edit-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				EmptyNoForm,
				PanelHeader,
				JSONContent,
				FormsModule,
				JSONFormatValidator
			],
			template: `
    <core-panel-header
      header="Model"
      subHeader="Edit the active form model"
    />
    @if (activeForm()) {
      <form
        #form="ngForm"
        class="panel-content"
      >
        <core-json-content
          class="h-full"
          name="json"
          coreJsonFormat
          editable
          [ngModel]="activeModelJSON()"
          (ngModelChange)="modifyActiveModel($event)"
        />
      </form>
    } @else {
      <core-empty-no-form />
    }
  `
		}]
	}],
	propDecorators: { form: [{
		type: i0.ViewChild,
		args: [i0.forwardRef(() => NgForm), { isSignal: true }]
	}] }
});
var ClassType;
(function(ClassType) {
	ClassType["CLASS_NAME"] = "className";
	ClassType["FIELD_GROUP_CLASS_NAME"] = "fieldGroupClassName";
})(ClassType || (ClassType = {}));
var BreakpointAffix;
(function(BreakpointAffix) {
	BreakpointAffix["PREFIX"] = "prefix";
	BreakpointAffix["INFIX"] = "infix";
	BreakpointAffix["SUFFIX"] = "suffix";
})(BreakpointAffix || (BreakpointAffix = {}));
const CORE_STYLES_CONFIG = new InjectionToken("CORE_STYLES_CONFIG ");
const formatVariant = (variant, option, bp, bpAffix) => {
	const optionValue = `${option.value ? `${option.value}-` : ""}`;
	switch (bpAffix) {
		case BreakpointAffix.PREFIX: return `${bp.value}${optionValue}${variant}`;
		case BreakpointAffix.INFIX: return `${optionValue}${bp.value ? `${bp.value}-` : ""}${variant}`;
		case BreakpointAffix.SUFFIX: return `${optionValue}${variant}${bp.value}`;
	}
};
const findVariant = (source, option, bp, bpAffix) => {
	const variants = new Map(option.variants.map((variant) => [formatVariant(variant, option, bp, bpAffix), variant]));
	for (const token of classTokens(source)) if (variants.has(token)) return variants.get(token);
};
const classTokens = (source) => source.split(/[\t\n\f\r ]+/).filter((token) => token.length > 0);
const hasClass = (source, value) => classTokens(source).includes(value);
const removeOptionClasses = (source, option, bp, bpAffix) => {
	const classes = new Set(option.variants.map((variant) => formatVariant(variant, option, bp, bpAffix)));
	const tokens = classTokens(source);
	const remaining = tokens.filter((token) => !classes.has(token));
	return remaining.length === tokens.length ? source : remaining.join(" ");
};
const removeInvalidDependencies = (previous, candidate, config) => {
	const result = { ...candidate };
	let changed;
	do {
		changed = false;
		for (const classType of [ClassType.CLASS_NAME, ClassType.FIELD_GROUP_CLASS_NAME]) for (const category of config[classType]) for (const option of category.options) {
			const dependency = option.dependsOn;
			if (!dependency || !hasClass(previous[dependency.type], dependency.value) || hasClass(result[dependency.type], dependency.value)) continue;
			for (const breakpoint of config.breakpoints) {
				if (breakpoint.value && !option.hasBreakpoints) continue;
				const cleaned = removeOptionClasses(result[classType], option, breakpoint, config.breakpointAffix);
				if (cleaned !== result[classType]) {
					result[classType] = cleaned;
					changed = true;
				}
			}
		}
	} while (changed);
	return result;
};
var StylingOption = class StylingOption {
	option = input.required(...ngDevMode ? [{ debugName: "option" }] : /* istanbul ignore next */ []);
	breakpoint = input.required(...ngDevMode ? [{ debugName: "breakpoint" }] : /* istanbul ignore next */ []);
	classType = input.required(...ngDevMode ? [{ debugName: "classType" }] : /* istanbul ignore next */ []);
	fieldChange = output();
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	stylesConfig = inject(CORE_STYLES_CONFIG);
	activeField = this.formService.activeField;
	classNamePath = this.fieldService.classNamePath;
	fieldGroupClassNamePath = this.fieldService.fieldGroupClassNamePath;
	breakpointAffix = this.stylesConfig.breakpointAffix;
	selectId = `styling-option-select-${Math.random().toString(36).substring(2, 15)}`;
	classPath = computed(() => this.classType() === ClassType.CLASS_NAME ? this.classNamePath : this.fieldGroupClassNamePath, ...ngDevMode ? [{ debugName: "classPath" }] : /* istanbul ignore next */ []);
	classValue = computed(() => this.activeField() ? get(this.activeField(), this.classPath()) ?? "" : "", ...ngDevMode ? [{ debugName: "classValue" }] : /* istanbul ignore next */ []);
	selectedVariant = computed(() => findVariant(this.classValue(), this.option(), this.breakpoint(), this.breakpointAffix), ...ngDevMode ? [{ debugName: "selectedVariant" }] : /* istanbul ignore next */ []);
	variantOptions = computed(() => this.option().variants.map((value) => ({
		value,
		label: this.option().variantLabels?.[value] ?? value
	})), ...ngDevMode ? [{ debugName: "variantOptions" }] : /* istanbul ignore next */ []);
	selectVariant(variant) {
		if (variant && !this.option().variants.includes(variant)) return;
		const formattedVariant = variant ? formatVariant(variant, this.option(), this.breakpoint(), this.breakpointAffix) : "";
		const remaining = removeOptionClasses(this.classValue(), this.option(), this.breakpoint(), this.breakpointAffix);
		if (variant && variant === this.selectedVariant() && classTokens(this.classValue()).length - classTokens(remaining).length === 1) return;
		const field = this.activeField();
		if (!field) return;
		const previous = {
			[ClassType.CLASS_NAME]: get(field, this.classNamePath) ?? "",
			[ClassType.FIELD_GROUP_CLASS_NAME]: get(field, this.fieldGroupClassNamePath) ?? ""
		};
		const result = removeInvalidDependencies(previous, {
			...previous,
			[this.classType()]: [remaining, formattedVariant].filter((token) => !!token).join(" ")
		}, this.stylesConfig);
		const changes = [];
		for (const classType of [this.classType(), this.classType() === ClassType.CLASS_NAME ? ClassType.FIELD_GROUP_CLASS_NAME : ClassType.CLASS_NAME]) {
			if (result[classType] === previous[classType]) continue;
			const path = classType === ClassType.CLASS_NAME ? this.classNamePath : this.fieldGroupClassNamePath;
			changes.push(result[classType] ? {
				type: PropertyChangeType.VALUE,
				path,
				value: result[classType]
			} : {
				type: PropertyChangeType.CLEAR,
				path
			});
		}
		for (const change of changes) this.fieldChange.emit(change);
	}
	clear() {
		this.selectVariant("");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StylingOption,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: StylingOption,
		isStandalone: true,
		selector: "core-styling-option",
		inputs: {
			option: {
				classPropertyName: "option",
				publicName: "option",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			breakpoint: {
				classPropertyName: "breakpoint",
				publicName: "breakpoint",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			classType: {
				classPropertyName: "classType",
				publicName: "classType",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { fieldChange: "fieldChange" },
		ngImport: i0,
		template: `
    <core-field-property-wrapper
      [label]="option().name"
      [description]="option().description"
      [labelForId]="selectId"
      [isClearable]="true"
      (clear)="clear()"
    >
      <mat-select
        class="w-full"
        [id]="selectId"
        [aria-label]="option().name"
        [ngModel]="selectedVariant()"
        [attr.aria-describedby]="option().description ? selectId + '-description' : undefined"
        (selectionChange)="selectVariant($event.value)"
      >
        @for (option of variantOptions(); track $index) {
          <mat-option [value]="option.value">{{ option.label }}</mat-option>
        }
      </mat-select>
    </core-field-property-wrapper>
    @if (option().description) {
      <p
        class="mt-1 text-xs text-muted-color"
        [id]="selectId + '-description'"
      >
        {{ option().description }}
      </p>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: MatSelect,
				selector: "mat-select",
				inputs: [
					"aria-describedby",
					"panelClass",
					"disabled",
					"disableRipple",
					"tabIndex",
					"hideSingleSelectionIndicator",
					"placeholder",
					"required",
					"multiple",
					"disableOptionCentering",
					"compareWith",
					"value",
					"aria-label",
					"aria-labelledby",
					"errorStateMatcher",
					"typeaheadDebounceInterval",
					"sortComparator",
					"id",
					"panelWidth",
					"canSelectNullableOptions"
				],
				outputs: [
					"openedChange",
					"opened",
					"closed",
					"selectionChange",
					"valueChange"
				],
				exportAs: ["matSelect"]
			},
			{
				kind: "component",
				type: MatOption,
				selector: "mat-option",
				inputs: [
					"value",
					"id",
					"disabled"
				],
				outputs: ["onSelectionChange"],
				exportAs: ["matOption"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$2.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$2.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "component",
				type: FieldPropertyWrapper,
				selector: "core-field-property-wrapper",
				inputs: [
					"label",
					"description",
					"labelForId",
					"isClearable"
				],
				outputs: ["clear"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StylingOption,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-styling-option",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				MatSelect,
				MatOption,
				FormsModule,
				FieldPropertyWrapper
			],
			template: `
    <core-field-property-wrapper
      [label]="option().name"
      [description]="option().description"
      [labelForId]="selectId"
      [isClearable]="true"
      (clear)="clear()"
    >
      <mat-select
        class="w-full"
        [id]="selectId"
        [aria-label]="option().name"
        [ngModel]="selectedVariant()"
        [attr.aria-describedby]="option().description ? selectId + '-description' : undefined"
        (selectionChange)="selectVariant($event.value)"
      >
        @for (option of variantOptions(); track $index) {
          <mat-option [value]="option.value">{{ option.label }}</mat-option>
        }
      </mat-select>
    </core-field-property-wrapper>
    @if (option().description) {
      <p
        class="mt-1 text-xs text-muted-color"
        [id]="selectId + '-description'"
      >
        {{ option().description }}
      </p>
    }
  `
		}]
	}],
	propDecorators: {
		option: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "option",
				required: true
			}]
		}],
		breakpoint: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "breakpoint",
				required: true
			}]
		}],
		classType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "classType",
				required: true
			}]
		}],
		fieldChange: [{
			type: i0.Output,
			args: ["fieldChange"]
		}]
	}
});
var StylingClassType = class StylingClassType {
	classType = input.required(...ngDevMode ? [{ debugName: "classType" }] : /* istanbul ignore next */ []);
	classNameMap = input.required(...ngDevMode ? [{ debugName: "classNameMap" }] : /* istanbul ignore next */ []);
	fieldGroupClassNameMap = input.required(...ngDevMode ? [{ debugName: "fieldGroupClassNameMap" }] : /* istanbul ignore next */ []);
	stylesConfig = inject(CORE_STYLES_CONFIG);
	fieldChange = output();
	activeCategories = computed(() => this.classType() === ClassType.CLASS_NAME ? this.classNameMap()[this.activeBreakpointValue()] : this.fieldGroupClassNameMap()[this.activeBreakpointValue()], ...ngDevMode ? [{ debugName: "activeCategories" }] : /* istanbul ignore next */ []);
	activeBreakpoint = computed(() => this.breakpointMap[this.activeBreakpointValue()], ...ngDevMode ? [{ debugName: "activeBreakpoint" }] : /* istanbul ignore next */ []);
	breakpoints = this.stylesConfig.breakpoints;
	breakpointMap = Object.fromEntries(this.stylesConfig.breakpoints.map((bp) => [bp.value, bp]));
	activeBreakpointValue = signal(this.breakpoints[0]?.value ?? "", ...ngDevMode ? [{ debugName: "activeBreakpointValue" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StylingClassType,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: StylingClassType,
		isStandalone: true,
		selector: "core-styling-class-type",
		inputs: {
			classType: {
				classPropertyName: "classType",
				publicName: "classType",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			classNameMap: {
				classPropertyName: "classNameMap",
				publicName: "classNameMap",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			fieldGroupClassNameMap: {
				classPropertyName: "fieldGroupClassNameMap",
				publicName: "fieldGroupClassNameMap",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { fieldChange: "fieldChange" },
		host: { classAttribute: "flex flex-col gap-2" },
		ngImport: i0,
		template: `
    @if (activeBreakpoint(); as breakpoint) {
      <div
        class="core-segmented"
        role="group"
      >
        @for (option of stylesConfig.breakpoints; track option.value) {
          <button
            coreButton
            text
            type="button"
            [attr.aria-pressed]="activeBreakpointValue() === option.value"
            (click)="activeBreakpointValue.set(option.value)"
          >
            {{ option.name }}
          </button>
        }
      </div>
      <h4>{{ breakpoint.description }}</h4>
      <div>
        @for (category of activeCategories(); track category.name) {
          <core-property-panel [header]="category.name">
            <div class="grid grid-cols-2 gap-2">
              @for (option of category.options; track option.name) {
                <core-styling-option
                  [class.col-span-2]="option.spanWidth"
                  [option]="option"
                  [breakpoint]="breakpoint"
                  [classType]="classType()"
                  (fieldChange)="fieldChange.emit($event)"
                />
              }
            </div>
          </core-property-panel>
        }
      </div>
    } @else {
      <p class="text-sm text-muted-color">No styling presets configured.</p>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			},
			{
				kind: "component",
				type: StylingOption,
				selector: "core-styling-option",
				inputs: [
					"option",
					"breakpoint",
					"classType"
				],
				outputs: ["fieldChange"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StylingClassType,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-styling-class-type",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormsModule,
				Panel,
				StylingOption
			],
			host: { class: "flex flex-col gap-2" },
			template: `
    @if (activeBreakpoint(); as breakpoint) {
      <div
        class="core-segmented"
        role="group"
      >
        @for (option of stylesConfig.breakpoints; track option.value) {
          <button
            coreButton
            text
            type="button"
            [attr.aria-pressed]="activeBreakpointValue() === option.value"
            (click)="activeBreakpointValue.set(option.value)"
          >
            {{ option.name }}
          </button>
        }
      </div>
      <h4>{{ breakpoint.description }}</h4>
      <div>
        @for (category of activeCategories(); track category.name) {
          <core-property-panel [header]="category.name">
            <div class="grid grid-cols-2 gap-2">
              @for (option of category.options; track option.name) {
                <core-styling-option
                  [class.col-span-2]="option.spanWidth"
                  [option]="option"
                  [breakpoint]="breakpoint"
                  [classType]="classType()"
                  (fieldChange)="fieldChange.emit($event)"
                />
              }
            </div>
          </core-property-panel>
        }
      </div>
    } @else {
      <p class="text-sm text-muted-color">No styling presets configured.</p>
    }
  `
		}]
	}],
	propDecorators: {
		classType: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "classType",
				required: true
			}]
		}],
		classNameMap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "classNameMap",
				required: true
			}]
		}],
		fieldGroupClassNameMap: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldGroupClassNameMap",
				required: true
			}]
		}],
		fieldChange: [{
			type: i0.Output,
			args: ["fieldChange"]
		}]
	}
});
var StylingPanel = class StylingPanel {
	fieldChange = output();
	typeOfClassType = ClassType;
	activeTab = signal("self", ...ngDevMode ? [{ debugName: "activeTab" }] : /* istanbul ignore next */ []);
	isParent = computed(() => !!this.activeField()?._info.isParent, ...ngDevMode ? [{ debugName: "isParent" }] : /* istanbul ignore next */ []);
	classNameMap = computed(() => {
		const activeField = this.activeField();
		if (!activeField) return {};
		const parentField = this.parentField();
		return this.getBreakpointCategoryEntries(ClassType.CLASS_NAME, activeField, parentField);
	}, ...ngDevMode ? [{ debugName: "classNameMap" }] : /* istanbul ignore next */ []);
	fieldGroupClassNameMap = computed(() => {
		const activeField = this.activeField();
		if (!activeField) return {};
		const parentField = this.parentField();
		return this.getBreakpointCategoryEntries(ClassType.FIELD_GROUP_CLASS_NAME, activeField, parentField);
	}, ...ngDevMode ? [{ debugName: "fieldGroupClassNameMap" }] : /* istanbul ignore next */ []);
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	stylesConfig = inject(CORE_STYLES_CONFIG);
	classNamePath = this.fieldService.classNamePath;
	fieldGroupClassNamePath = this.fieldService.fieldGroupClassNamePath;
	activeField = this.formService.activeField;
	parentField = computed(() => {
		const field = this.activeField();
		if (!field) return null;
		const parentId = field._info.idPath[field._info.idPath.length - 2];
		return parentId ? this.formService.activeFieldMap()[parentId] : null;
	}, ...ngDevMode ? [{ debugName: "parentField" }] : /* istanbul ignore next */ []);
	classNameProperty = createChipsProperty({
		label: "Classes",
		key: this.classNamePath.join("."),
		description: "CSS class names applied to this field.",
		outputString: { separator: " " }
	});
	fieldGroupClassNameProperty = createChipsProperty({
		label: "Group Classes",
		key: this.fieldGroupClassNamePath.join("."),
		description: `CSS class names applied to this field's group container.`,
		outputString: { separator: " " }
	});
	constructor() {
		effect(() => {
			if (!this.isParent()) this.activeTab.set("self");
		});
	}
	onFieldChanged(change) {
		this.formService.modifyActiveField(change);
	}
	getBreakpointCategoryEntries(classType, activeField, parentField) {
		const categories = this.stylesConfig[classType];
		const entries = this.stylesConfig.breakpoints.map((breakpoint) => {
			const breakpointCategories = categories.map((category) => ({
				...category,
				options: category.options.filter((option) => this.canShowOption(option, breakpoint, activeField, parentField))
			}));
			return [breakpoint.value, breakpointCategories];
		});
		return Object.fromEntries(entries);
	}
	canShowOption(option, breakpoint, activeField, parentField) {
		if (breakpoint.value && !option.hasBreakpoints) return false;
		if (option.dependsOn) {
			const { type, value } = option.dependsOn;
			const classValue = this.getClassValue(activeField, type);
			if (!hasClass(classValue, value)) return false;
		}
		if (option.dependsOnParent) {
			const { type, value } = option.dependsOnParent;
			const classValue = this.getClassValue(parentField, type);
			if (!hasClass(classValue, value)) return false;
		}
		return true;
	}
	getClassValue(field, classType) {
		const classPath = classType === ClassType.CLASS_NAME ? this.classNamePath : this.fieldGroupClassNamePath;
		return field ? get(field, classPath) ?? "" : "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: StylingPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: StylingPanel,
		isStandalone: true,
		selector: "core-styling-panel",
		outputs: { fieldChange: "fieldChange" },
		ngImport: i0,
		template: `
    <core-panel-header
      header="Styling"
      subHeader="Edit responsive classes for the selected field"
    />
    @if (activeField()) {
      <mat-tab-group
        class="core-tabs min-h-0 flex-1"
        animationDuration="0ms"
        [preserveContent]="true"
        [selectedIndex]="['self', 'children'].indexOf(activeTab())"
        (selectedTabChange)="activeTab.set($event.index === 0 ? 'self' : 'children')"
        ><mat-tab
          ><ng-template mat-tab-label>
            <i class="material-symbols-outlined">person</i>
            <span>Self</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4">
            <core-styling-class-type
              [classType]="typeOfClassType.CLASS_NAME"
              [classNameMap]="classNameMap()"
              [fieldGroupClassNameMap]="fieldGroupClassNameMap()"
              (fieldChange)="onFieldChanged($event)"
            />
            @if (activeField(); as field) {
              <core-property-panel header="CSS Class Names">
                <core-field-chips-property
                  [property]="classNameProperty"
                  [path]="classNamePath"
                  [target]="field"
                  (targetChanged)="onFieldChanged($event)"
                />
              </core-property-panel>
            }</div></mat-tab
        ><mat-tab [disabled]="!isParent()"
          ><ng-template mat-tab-label>
            <i class="material-symbols-outlined">groups</i>
            <span>Children</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4">
            <core-styling-class-type
              [classType]="typeOfClassType.FIELD_GROUP_CLASS_NAME"
              [classNameMap]="classNameMap()"
              [fieldGroupClassNameMap]="fieldGroupClassNameMap()"
              (fieldChange)="onFieldChanged($event)"
            />
            @if (activeField(); as field) {
              <core-property-panel header="CSS Class Names">
                <core-field-chips-property
                  [property]="fieldGroupClassNameProperty"
                  [path]="fieldGroupClassNamePath"
                  [target]="field"
                  (targetChanged)="onFieldChanged($event)"
                />
              </core-property-panel>
            }</div></mat-tab
      ></mat-tab-group>
    } @else {
      <core-empty-no-field-selected />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: MatTabsModule
			},
			{
				kind: "directive",
				type: i1$1.MatTabLabel,
				selector: "[mat-tab-label], [matTabLabel]"
			},
			{
				kind: "component",
				type: i1$1.MatTab,
				selector: "mat-tab",
				inputs: [
					"disabled",
					"label",
					"aria-label",
					"aria-labelledby",
					"labelClass",
					"bodyClass",
					"id"
				],
				exportAs: ["matTab"]
			},
			{
				kind: "component",
				type: i1$1.MatTabGroup,
				selector: "mat-tab-group",
				inputs: [
					"color",
					"fitInkBarToContent",
					"mat-stretch-tabs",
					"mat-align-tabs",
					"dynamicHeight",
					"selectedIndex",
					"headerPosition",
					"animationDuration",
					"contentTabIndex",
					"disablePagination",
					"disableRipple",
					"preserveContent",
					"backgroundColor",
					"aria-label",
					"aria-labelledby"
				],
				outputs: [
					"selectedIndexChange",
					"focusChange",
					"animationDone",
					"selectedTabChange"
				],
				exportAs: ["matTabGroup"]
			},
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "component",
				type: StylingClassType,
				selector: "core-styling-class-type",
				inputs: [
					"classType",
					"classNameMap",
					"fieldGroupClassNameMap"
				],
				outputs: ["fieldChange"]
			},
			{
				kind: "component",
				type: EmptyNoFieldSelected,
				selector: "core-empty-no-field-selected"
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			},
			{
				kind: "component",
				type: FieldChipsProperty,
				selector: "core-field-chips-property"
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: StylingPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-styling-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				MatTabsModule,
				FormsModule,
				StylingClassType,
				EmptyNoFieldSelected,
				PanelHeader,
				FieldChipsProperty,
				Panel
			],
			template: `
    <core-panel-header
      header="Styling"
      subHeader="Edit responsive classes for the selected field"
    />
    @if (activeField()) {
      <mat-tab-group
        class="core-tabs min-h-0 flex-1"
        animationDuration="0ms"
        [preserveContent]="true"
        [selectedIndex]="['self', 'children'].indexOf(activeTab())"
        (selectedTabChange)="activeTab.set($event.index === 0 ? 'self' : 'children')"
        ><mat-tab
          ><ng-template mat-tab-label>
            <i class="material-symbols-outlined">person</i>
            <span>Self</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4">
            <core-styling-class-type
              [classType]="typeOfClassType.CLASS_NAME"
              [classNameMap]="classNameMap()"
              [fieldGroupClassNameMap]="fieldGroupClassNameMap()"
              (fieldChange)="onFieldChanged($event)"
            />
            @if (activeField(); as field) {
              <core-property-panel header="CSS Class Names">
                <core-field-chips-property
                  [property]="classNameProperty"
                  [path]="classNamePath"
                  [target]="field"
                  (targetChanged)="onFieldChanged($event)"
                />
              </core-property-panel>
            }</div></mat-tab
        ><mat-tab [disabled]="!isParent()"
          ><ng-template mat-tab-label>
            <i class="material-symbols-outlined">groups</i>
            <span>Children</span>
          </ng-template>
          <div class="flex min-h-0 flex-1 flex-col overflow-y-auto px-4 pb-4">
            <core-styling-class-type
              [classType]="typeOfClassType.FIELD_GROUP_CLASS_NAME"
              [classNameMap]="classNameMap()"
              [fieldGroupClassNameMap]="fieldGroupClassNameMap()"
              (fieldChange)="onFieldChanged($event)"
            />
            @if (activeField(); as field) {
              <core-property-panel header="CSS Class Names">
                <core-field-chips-property
                  [property]="fieldGroupClassNameProperty"
                  [path]="fieldGroupClassNamePath"
                  [target]="field"
                  (targetChanged)="onFieldChanged($event)"
                />
              </core-property-panel>
            }</div></mat-tab
      ></mat-tab-group>
    } @else {
      <core-empty-no-field-selected />
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { fieldChange: [{
		type: i0.Output,
		args: ["fieldChange"]
	}] }
});
var ValidationPanelContent = class ValidationPanelContent {
	config = input.required(...ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []);
	target = input.required(...ngDevMode ? [{ debugName: "target" }] : /* istanbul ignore next */ []);
	targetChanged = output();
	customValidators = computed(() => this.config().customValidators ?? createCustomValidationProperty({
		label: "Custom Validation",
		key: "validators.validation",
		validationOptions: []
	}), ...ngDevMode ? [{ debugName: "customValidators" }] : /* istanbul ignore next */ []);
	fieldService = inject(CoreFieldService);
	panelPT = { content: { class: "grid! grid-cols-2 gap-2" } };
	messagesPath = this.fieldService.validationMessagesPath;
	propertyPath(property) {
		if (property.key === void 0) throw new Error("Validation property must have a key");
		return property.key.split(".");
	}
	hasPropertyValue(property) {
		return this.hasValue(get(this.target(), this.propertyPath(property)));
	}
	onRuleChanged(change, validatorName) {
		this.targetChanged.emit(change);
		if (change.type === PropertyChangeType.CLEAR) this.targetChanged.emit({
			type: PropertyChangeType.CLEAR,
			path: [...this.messagesPath, validatorName]
		});
	}
	hasValue(value) {
		return value !== void 0 && value !== null && value !== "";
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ValidationPanelContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ValidationPanelContent,
		isStandalone: true,
		selector: "core-validation-panel-content",
		inputs: {
			config: {
				classPropertyName: "config",
				publicName: "config",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			target: {
				classPropertyName: "target",
				publicName: "target",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: { targetChanged: "targetChanged" },
		host: { classAttribute: "flex min-h-0 min-w-0 flex-1 flex-col gap-4 overflow-y-auto px-4 pb-4" },
		ngImport: i0,
		template: `
    @if (config().displayProperties?.length) {
      <core-property-panel header="Display">
        @for (property of config().displayProperties; track property.key) {
          <core-field-property
            [class.col-span-1]="property.colSpan === 1"
            [class.col-span-2]="property.colSpan !== 1"
            [property]="property"
            [path]="propertyPath(property)"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        }
      </core-property-panel>
    }

    @if (config().rules.length) {
      <core-property-panel header="Rules">
        @for (rule of config().rules; track rule.name) {
          <div
            class="grid grid-cols-[minmax(0,1fr)_minmax(0,2fr)] items-end gap-2 [&_.field-property-control]:min-w-0!"
          >
            <core-field-property
              class="min-w-0"
              [property]="rule.property"
              [path]="propertyPath(rule.property)"
              [target]="target()"
              (targetChanged)="onRuleChanged($event, rule.name)"
            />
            @if (hasPropertyValue(rule.property)) {
              <core-validation-message-input
                class="min-w-0"
                [validatorLabel]="rule.property.label"
                [validatorName]="rule.name"
                [target]="target()"
                (targetChanged)="targetChanged.emit($event)"
              />
            }
          </div>
        }
      </core-property-panel>
    }

    @if (customValidators(); as property) {
      <core-field-custom-validation-property
        [property]="property"
        [path]="propertyPath(property)"
        [target]="target()"
        (targetChanged)="targetChanged.emit($event)"
      />
    }

    @if (config().asyncValidators; as property) {
      <core-field-custom-validation-property
        [property]="property"
        [path]="propertyPath(property)"
        [target]="target()"
        (targetChanged)="targetChanged.emit($event)"
      />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldCustomValidationProperty,
				selector: "core-field-custom-validation-property"
			},
			{
				kind: "component",
				type: FieldProperty,
				selector: "core-field-property",
				inputs: [
					"property",
					"path",
					"target"
				],
				outputs: ["targetChanged"]
			},
			{
				kind: "component",
				type: ValidationMessageInput,
				selector: "core-validation-message-input",
				inputs: [
					"validatorName",
					"validatorLabel",
					"target"
				],
				outputs: ["targetChanged"]
			},
			{
				kind: "component",
				type: Panel,
				selector: "core-property-panel",
				inputs: [
					"header",
					"toggleable",
					"collapsed",
					"pt"
				],
				outputs: ["collapsedChange"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ValidationPanelContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-validation-panel-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldCustomValidationProperty,
				FieldProperty,
				ValidationMessageInput,
				Panel
			],
			host: { class: "flex min-h-0 min-w-0 flex-1 flex-col gap-4 overflow-y-auto px-4 pb-4" },
			template: `
    @if (config().displayProperties?.length) {
      <core-property-panel header="Display">
        @for (property of config().displayProperties; track property.key) {
          <core-field-property
            [class.col-span-1]="property.colSpan === 1"
            [class.col-span-2]="property.colSpan !== 1"
            [property]="property"
            [path]="propertyPath(property)"
            [target]="target()"
            (targetChanged)="targetChanged.emit($event)"
          />
        }
      </core-property-panel>
    }

    @if (config().rules.length) {
      <core-property-panel header="Rules">
        @for (rule of config().rules; track rule.name) {
          <div
            class="grid grid-cols-[minmax(0,1fr)_minmax(0,2fr)] items-end gap-2 [&_.field-property-control]:min-w-0!"
          >
            <core-field-property
              class="min-w-0"
              [property]="rule.property"
              [path]="propertyPath(rule.property)"
              [target]="target()"
              (targetChanged)="onRuleChanged($event, rule.name)"
            />
            @if (hasPropertyValue(rule.property)) {
              <core-validation-message-input
                class="min-w-0"
                [validatorLabel]="rule.property.label"
                [validatorName]="rule.name"
                [target]="target()"
                (targetChanged)="targetChanged.emit($event)"
              />
            }
          </div>
        }
      </core-property-panel>
    }

    @if (customValidators(); as property) {
      <core-field-custom-validation-property
        [property]="property"
        [path]="propertyPath(property)"
        [target]="target()"
        (targetChanged)="targetChanged.emit($event)"
      />
    }

    @if (config().asyncValidators; as property) {
      <core-field-custom-validation-property
        [property]="property"
        [path]="propertyPath(property)"
        [target]="target()"
        (targetChanged)="targetChanged.emit($event)"
      />
    }
  `
		}]
	}],
	propDecorators: {
		config: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "config",
				required: true
			}]
		}],
		target: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "target",
				required: true
			}]
		}],
		targetChanged: [{
			type: i0.Output,
			args: ["targetChanged"]
		}]
	}
});
var ValidationPanel = class ValidationPanel {
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	activeField = this.formService.activeField;
	activeFieldByType = computed(() => this.activeField(), {
		...ngDevMode ? { debugName: "activeFieldByType" } : /* istanbul ignore next */ {},
		equal: (a, b) => !!(a && b && this.fieldService.isFieldEqual(a, b))
	});
	config = computed(() => {
		const field = this.activeFieldByType();
		return field ? this.fieldService.getValidationConfig(field) : void 0;
	}, ...ngDevMode ? [{ debugName: "config" }] : /* istanbul ignore next */ []);
	onFieldChanged(change) {
		this.formService.modifyActiveField(change);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ValidationPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ValidationPanel,
		isStandalone: true,
		selector: "core-validation-panel",
		host: { classAttribute: "overflow-hidden" },
		ngImport: i0,
		template: `
    <core-panel-header
      header="Validation"
      subHeader="Configure validation for the selected field"
    />
    @if (activeField(); as field) {
      @if (config(); as validationConfig) {
        <core-validation-panel-content
          [config]="validationConfig"
          [target]="field"
          (targetChanged)="onFieldChanged($event)"
        />
      } @else {
        <core-empty
          label="No validation options"
          description="This field type has no configurable validation options."
        />
      }
    } @else {
      <core-empty-no-field-selected />
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: Empty,
				selector: "core-empty",
				inputs: ["label", "description"]
			},
			{
				kind: "component",
				type: EmptyNoFieldSelected,
				selector: "core-empty-no-field-selected"
			},
			{
				kind: "component",
				type: ValidationPanelContent,
				selector: "core-validation-panel-content",
				inputs: ["config", "target"],
				outputs: ["targetChanged"]
			},
			{
				kind: "component",
				type: PanelHeader,
				selector: "core-panel-header",
				inputs: ["header", "subHeader"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ValidationPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-validation-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				Empty,
				EmptyNoFieldSelected,
				ValidationPanelContent,
				PanelHeader
			],
			host: { class: "overflow-hidden" },
			template: `
    <core-panel-header
      header="Validation"
      subHeader="Configure validation for the selected field"
    />
    @if (activeField(); as field) {
      @if (config(); as validationConfig) {
        <core-validation-panel-content
          [config]="validationConfig"
          [target]="field"
          (targetChanged)="onFieldChanged($event)"
        />
      } @else {
        <core-empty
          label="No validation options"
          description="This field type has no configurable validation options."
        />
      }
    } @else {
      <core-empty-no-field-selected />
    }
  `
		}]
	}]
});
var SettingsPanel = class SettingsPanel {
	editor = inject(CORE_EDITOR_CONFIG);
	libraries = inject(CORE_LIBRARY_CONFIGS);
	styles = inject(CORE_STYLES_CONFIG);
	sharedTemplates = inject(CORE_FORM_TEMPLATES, { optional: true });
	templates = this.sharedTemplates ?? this.libraries.filter((library) => !library.hidden).flatMap((library) => library.formTemplates ?? []);
	storageLabel = inject(CORE_FORM_STORE) instanceof LocalFormStoreService ? "Browser local storage" : "Custom storage";
	styleGroups = [{
		label: "Self",
		categories: this.styles.className
	}, {
		label: "Children",
		categories: this.styles.fieldGroupClassName
	}];
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: SettingsPanel,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: SettingsPanel,
		isStandalone: true,
		selector: "core-settings-panel",
		ngImport: i0,
		template: `
    <core-panel-header
      header="Builder settings"
      subHeader="Configured by the application that hosts this builder"
    />
    <div class="panel-content flex flex-col gap-6 text-sm wrap-anywhere">
      <section aria-label="General settings">
        <h3 class="mb-2 font-medium">General</h3>
        <dl class="flex flex-col gap-3">
          <div>
            <dt class="text-muted-color">Storage namespace</dt>
            <dd>{{ editor.editorType }}</dd>
          </div>
          <div>
            <dt class="text-muted-color">Autosave</dt>
            <dd>{{ editor.autoSave === false ? 'Disabled' : 'Enabled' }}</dd>
          </div>
          <div>
            <dt class="text-muted-color">Autosave delay</dt>
            <dd>
              {{ editor.autoSaveDelay ?? 3000 }} ms{{
                editor.autoSave === false ? ' (inactive)' : ''
              }}
            </dd>
          </div>
          <div>
            <dt class="text-muted-color">Storage</dt>
            <dd>{{ storageLabel }}</dd>
          </div>
        </dl>
      </section>

      <section aria-label="Registered libraries">
        <h3 class="mb-2 font-medium">UI libraries</h3>
        <ul class="flex flex-col gap-2">
          @for (library of libraries; track library.id) {
            <li>
              {{ library.label }} <span class="text-muted-color">({{ library.id }})</span>
              @if (library.hidden) {
                <p class="text-muted-color">Available for saved forms only</p>
              }
            </li>
          }
        </ul>
      </section>

      <section aria-label="Configured templates">
        <h3 class="mb-2 font-medium">Templates</h3>
        <p class="mb-2 text-muted-color">
          {{ sharedTemplates !== null ? 'Shared across UI libraries' : 'Provided by UI libraries' }}
        </p>
        <ul class="flex flex-col gap-1">
          @for (template of templates; track $index) {
            <li>{{ template.name }}</li>
          } @empty {
            <li>No templates configured.</li>
          }
        </ul>
      </section>

      <section aria-label="Styling configuration">
        <h3 class="mb-2 font-medium">Styling · {{ styles.label ?? 'Custom styles' }}</h3>
        <p class="mb-3 text-muted-color">
          These choices add CSS classes. The host application's styles determine their appearance
          and dimensions. Labels describe the configured scale; pixel sizes also depend on the root
          font size.
        </p>
        <h4 class="mb-2 font-medium">Breakpoints</h4>
        <dl class="mb-4 flex flex-col gap-2">
          @for (breakpoint of styles.breakpoints; track breakpoint.value) {
            <div>
              <dt>{{ breakpoint.name }}{{ breakpoint.value ? ' · ' + breakpoint.value : '' }}</dt>
              <dd class="text-muted-color">{{ breakpoint.description }}</dd>
            </div>
          } @empty {
            <p>No breakpoints configured.</p>
          }
        </dl>
        @for (group of styleGroups; track group.label) {
          <h4 class="mt-4 mb-2 font-medium">{{ group.label }}</h4>
          @for (category of group.categories; track $index) {
            <core-property-panel
              [header]="category.name"
              [toggleable]="true"
              [collapsed]="true"
            >
              @for (option of category.options; track $index) {
                <div class="mb-3">
                  <h5 class="font-medium">{{ option.name }}</h5>
                  @if (option.description) {
                    <p class="mb-1 text-muted-color">{{ option.description }}</p>
                  }
                  <p class="text-muted-color">
                    Class prefix: {{ option.value ?? '(none)' }} ·
                    {{ option.hasBreakpoints ? 'Responsive' : 'All devices' }}
                  </p>
                  <ul class="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                    @for (variant of option.variants; track variant) {
                      <li>
                        {{ option.variantLabels?.[variant] ?? variant }}
                        @if (
                          option.variantLabels?.[variant] &&
                          option.variantLabels[variant] !== variant
                        ) {
                          <span class="text-muted-color">[{{ variant }}]</span>
                        }
                      </li>
                    } @empty {
                      <li>No choices configured.</li>
                    }
                  </ul>
                </div>
              } @empty {
                <p>No options configured.</p>
              }
            </core-property-panel>
          } @empty {
            <p class="text-muted-color">No styling categories configured.</p>
          }
        }
      </section>

      <section
        aria-label="Builder integration documentation"
        class="pb-4"
      >
        <h3 class="mb-2 font-medium">Configure your builder</h3>
        <p class="mb-3 text-muted-color">
          Settings are supplied at initialization. Changes belong in your application's builder
          configuration.
        </p>
        <ul class="flex flex-col gap-2">
          <li>
            <a
              class="text-primary underline underline-offset-4"
              href="https://docs.formlystudio.com/developers/builder-configuration/"
              target="_blank"
              rel="noopener noreferrer"
              >Builder configuration</a
            >
          </li>
          <li>
            <a
              class="text-primary underline underline-offset-4"
              href="https://docs.formlystudio.com/developers/embed-in-angular/"
              target="_blank"
              rel="noopener noreferrer"
              >Embed in Angular</a
            >
          </li>
        </ul>
      </section>
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: PanelHeader,
			selector: "core-panel-header",
			inputs: ["header", "subHeader"]
		}, {
			kind: "component",
			type: Panel,
			selector: "core-property-panel",
			inputs: [
				"header",
				"toggleable",
				"collapsed",
				"pt"
			],
			outputs: ["collapsedChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: SettingsPanel,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-settings-panel",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [PanelHeader, Panel],
			template: `
    <core-panel-header
      header="Builder settings"
      subHeader="Configured by the application that hosts this builder"
    />
    <div class="panel-content flex flex-col gap-6 text-sm wrap-anywhere">
      <section aria-label="General settings">
        <h3 class="mb-2 font-medium">General</h3>
        <dl class="flex flex-col gap-3">
          <div>
            <dt class="text-muted-color">Storage namespace</dt>
            <dd>{{ editor.editorType }}</dd>
          </div>
          <div>
            <dt class="text-muted-color">Autosave</dt>
            <dd>{{ editor.autoSave === false ? 'Disabled' : 'Enabled' }}</dd>
          </div>
          <div>
            <dt class="text-muted-color">Autosave delay</dt>
            <dd>
              {{ editor.autoSaveDelay ?? 3000 }} ms{{
                editor.autoSave === false ? ' (inactive)' : ''
              }}
            </dd>
          </div>
          <div>
            <dt class="text-muted-color">Storage</dt>
            <dd>{{ storageLabel }}</dd>
          </div>
        </dl>
      </section>

      <section aria-label="Registered libraries">
        <h3 class="mb-2 font-medium">UI libraries</h3>
        <ul class="flex flex-col gap-2">
          @for (library of libraries; track library.id) {
            <li>
              {{ library.label }} <span class="text-muted-color">({{ library.id }})</span>
              @if (library.hidden) {
                <p class="text-muted-color">Available for saved forms only</p>
              }
            </li>
          }
        </ul>
      </section>

      <section aria-label="Configured templates">
        <h3 class="mb-2 font-medium">Templates</h3>
        <p class="mb-2 text-muted-color">
          {{ sharedTemplates !== null ? 'Shared across UI libraries' : 'Provided by UI libraries' }}
        </p>
        <ul class="flex flex-col gap-1">
          @for (template of templates; track $index) {
            <li>{{ template.name }}</li>
          } @empty {
            <li>No templates configured.</li>
          }
        </ul>
      </section>

      <section aria-label="Styling configuration">
        <h3 class="mb-2 font-medium">Styling · {{ styles.label ?? 'Custom styles' }}</h3>
        <p class="mb-3 text-muted-color">
          These choices add CSS classes. The host application's styles determine their appearance
          and dimensions. Labels describe the configured scale; pixel sizes also depend on the root
          font size.
        </p>
        <h4 class="mb-2 font-medium">Breakpoints</h4>
        <dl class="mb-4 flex flex-col gap-2">
          @for (breakpoint of styles.breakpoints; track breakpoint.value) {
            <div>
              <dt>{{ breakpoint.name }}{{ breakpoint.value ? ' · ' + breakpoint.value : '' }}</dt>
              <dd class="text-muted-color">{{ breakpoint.description }}</dd>
            </div>
          } @empty {
            <p>No breakpoints configured.</p>
          }
        </dl>
        @for (group of styleGroups; track group.label) {
          <h4 class="mt-4 mb-2 font-medium">{{ group.label }}</h4>
          @for (category of group.categories; track $index) {
            <core-property-panel
              [header]="category.name"
              [toggleable]="true"
              [collapsed]="true"
            >
              @for (option of category.options; track $index) {
                <div class="mb-3">
                  <h5 class="font-medium">{{ option.name }}</h5>
                  @if (option.description) {
                    <p class="mb-1 text-muted-color">{{ option.description }}</p>
                  }
                  <p class="text-muted-color">
                    Class prefix: {{ option.value ?? '(none)' }} ·
                    {{ option.hasBreakpoints ? 'Responsive' : 'All devices' }}
                  </p>
                  <ul class="mt-1 flex flex-wrap gap-x-3 gap-y-1">
                    @for (variant of option.variants; track variant) {
                      <li>
                        {{ option.variantLabels?.[variant] ?? variant }}
                        @if (
                          option.variantLabels?.[variant] &&
                          option.variantLabels[variant] !== variant
                        ) {
                          <span class="text-muted-color">[{{ variant }}]</span>
                        }
                      </li>
                    } @empty {
                      <li>No choices configured.</li>
                    }
                  </ul>
                </div>
              } @empty {
                <p>No options configured.</p>
              }
            </core-property-panel>
          } @empty {
            <p class="text-muted-color">No styling categories configured.</p>
          }
        }
      </section>

      <section
        aria-label="Builder integration documentation"
        class="pb-4"
      >
        <h3 class="mb-2 font-medium">Configure your builder</h3>
        <p class="mb-3 text-muted-color">
          Settings are supplied at initialization. Changes belong in your application's builder
          configuration.
        </p>
        <ul class="flex flex-col gap-2">
          <li>
            <a
              class="text-primary underline underline-offset-4"
              href="https://docs.formlystudio.com/developers/builder-configuration/"
              target="_blank"
              rel="noopener noreferrer"
              >Builder configuration</a
            >
          </li>
          <li>
            <a
              class="text-primary underline underline-offset-4"
              href="https://docs.formlystudio.com/developers/embed-in-angular/"
              target="_blank"
              rel="noopener noreferrer"
              >Embed in Angular</a
            >
          </li>
        </ul>
      </section>
    </div>
  `
		}]
	}]
});
var PanelOption = class PanelOption {
	label = input(...ngDevMode ? [void 0, { debugName: "label" }] : /* istanbul ignore next */ []);
	value = input(...ngDevMode ? [void 0, { debugName: "value" }] : /* istanbul ignore next */ []);
	matIcon = input(...ngDevMode ? [void 0, { debugName: "matIcon" }] : /* istanbul ignore next */ []);
	isActive = input(false, {
		...ngDevMode ? { debugName: "isActive" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	disabled = input(false, {
		...ngDevMode ? { debugName: "disabled" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	position = input("left", ...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	selected = output();
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PanelOption,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PanelOption,
		isStandalone: true,
		selector: "core-panel-option",
		inputs: {
			label: {
				classPropertyName: "label",
				publicName: "label",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			matIcon: {
				classPropertyName: "matIcon",
				publicName: "matIcon",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isActive: {
				classPropertyName: "isActive",
				publicName: "isActive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			disabled: {
				classPropertyName: "disabled",
				publicName: "disabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { selected: "selected" },
		host: { classAttribute: "flex" },
		ngImport: i0,
		template: `
    @if (position() === 'left') {
      <div
        class="h-18 w-1.5 bg-primary opacity-0"
        [class.opacity-100]="isActive()"
      ></div>
    }
    <button
      class="flex size-18 flex-col items-center justify-center rounded-none px-0.5"
      coreButton
      text
      [disabled]="disabled()"
      [attr.aria-label]="'Open ' + label() + ' panel'"
      [coreTooltip]="label()"
      [tooltipPosition]="position() === 'right' ? 'left' : 'right'"
      (click)="selected.emit()"
    >
      <i
        coreButtonIcon
        class="material-symbols-outlined"
        >{{ matIcon() }}</i
      >
      <span
        coreButtonLabel
        class="text-xs"
      >
        {{ label() }}
      </span>
    </button>
    @if (position() === 'right') {
      <div
        class="h-18 w-1.5 bg-primary opacity-0"
        [class.opacity-100]="isActive()"
      ></div>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Tooltip,
			selector: "[coreTooltip]"
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PanelOption,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-panel-option",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Tooltip],
			host: { class: "flex" },
			template: `
    @if (position() === 'left') {
      <div
        class="h-18 w-1.5 bg-primary opacity-0"
        [class.opacity-100]="isActive()"
      ></div>
    }
    <button
      class="flex size-18 flex-col items-center justify-center rounded-none px-0.5"
      coreButton
      text
      [disabled]="disabled()"
      [attr.aria-label]="'Open ' + label() + ' panel'"
      [coreTooltip]="label()"
      [tooltipPosition]="position() === 'right' ? 'left' : 'right'"
      (click)="selected.emit()"
    >
      <i
        coreButtonIcon
        class="material-symbols-outlined"
        >{{ matIcon() }}</i
      >
      <span
        coreButtonLabel
        class="text-xs"
      >
        {{ label() }}
      </span>
    </button>
    @if (position() === 'right') {
      <div
        class="h-18 w-1.5 bg-primary opacity-0"
        [class.opacity-100]="isActive()"
      ></div>
    }
  `
		}]
	}],
	propDecorators: {
		label: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "label",
				required: false
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: false
			}]
		}],
		matIcon: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "matIcon",
				required: false
			}]
		}],
		isActive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isActive",
				required: false
			}]
		}],
		disabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "disabled",
				required: false
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: false
			}]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}]
	}
});
var PanelOptionList = class PanelOptionList {
	showSettings = inject(PanelService).showSettings;
	activeFormId = inject(CoreFormService).activeFormId;
	options = input.required(...ngDevMode ? [{ debugName: "options" }] : /* istanbul ignore next */ []);
	position = input.required(...ngDevMode ? [{ debugName: "position" }] : /* istanbul ignore next */ []);
	value = model.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	selected = output();
	selectOption(value) {
		this.value.set(value);
		this.selected.emit(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PanelOptionList,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PanelOptionList,
		isStandalone: true,
		selector: "core-panel-option-list",
		inputs: {
			options: {
				classPropertyName: "options",
				publicName: "options",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			position: {
				classPropertyName: "position",
				publicName: "position",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			selected: "selected"
		},
		host: { classAttribute: "flex" },
		ngImport: i0,
		template: `
    @if (position() === 'right') {
      <hr
        class="h-full"
        layout="vertical"
      />
    }
    <ul class="flex flex-col">
      @for (option of options(); track option.value) {
        @if (option.value !== 'settings' || showSettings) {
          <li [class.mt-auto]="option.value === 'settings'">
            @if (!$first && option.value === 'field-edit') {
              <div
                class="px-3 py-2"
                aria-hidden="true"
              >
                <hr />
              </div>
            }
            <core-panel-option
              [matIcon]="option.matIcon"
              [label]="option.label"
              [value]="option.value"
              [isActive]="option.value === value()"
              [disabled]="
                option.value !== 'forms' && option.value !== 'settings' && !activeFormId()
              "
              [position]="position()"
              (selected)="selectOption(option.value)"
            />
          </li>
        }
      }
    </ul>
    @if (position() === 'left') {
      <hr
        class="h-full"
        layout="vertical"
      />
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: PanelOption,
			selector: "core-panel-option",
			inputs: [
				"label",
				"value",
				"matIcon",
				"isActive",
				"disabled",
				"position"
			],
			outputs: ["selected"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PanelOptionList,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-panel-option-list",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [PanelOption],
			host: { class: "flex" },
			template: `
    @if (position() === 'right') {
      <hr
        class="h-full"
        layout="vertical"
      />
    }
    <ul class="flex flex-col">
      @for (option of options(); track option.value) {
        @if (option.value !== 'settings' || showSettings) {
          <li [class.mt-auto]="option.value === 'settings'">
            @if (!$first && option.value === 'field-edit') {
              <div
                class="px-3 py-2"
                aria-hidden="true"
              >
                <hr />
              </div>
            }
            <core-panel-option
              [matIcon]="option.matIcon"
              [label]="option.label"
              [value]="option.value"
              [isActive]="option.value === value()"
              [disabled]="
                option.value !== 'forms' && option.value !== 'settings' && !activeFormId()
              "
              [position]="position()"
              (selected)="selectOption(option.value)"
            />
          </li>
        }
      }
    </ul>
    @if (position() === 'left') {
      <hr
        class="h-full"
        layout="vertical"
      />
    }
  `
		}]
	}],
	propDecorators: {
		options: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "options",
				required: true
			}]
		}],
		position: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "position",
				required: true
			}]
		}],
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		selected: [{
			type: i0.Output,
			args: ["selected"]
		}]
	}
});
var LHSSidebar = class LHSSidebar {
	panelService = inject(PanelService);
	activePanel = this.panelService.activeLHSPanel;
	panelOptions = [
		{
			label: "Workspace",
			value: "forms",
			matIcon: "assignment"
		},
		{
			label: "Fields",
			value: "fields",
			matIcon: "lists"
		},
		{
			label: "Add Field",
			value: "add-field",
			matIcon: "add"
		},
		{
			label: "Builder settings",
			value: "settings",
			matIcon: "settings"
		}
	];
	setActivePanel(panel) {
		this.panelService.setActiveLHSPanel(panel);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LHSSidebar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: LHSSidebar,
		isStandalone: true,
		selector: "core-lhs-sidebar",
		host: { classAttribute: "flex h-full min-h-0 min-w-0 shrink-0" },
		ngImport: i0,
		template: `
    <core-panel-option-list
      position="left"
      [options]="panelOptions"
      [value]="activePanel()"
      (selected)="setActivePanel($event)"
    />
    @switch (activePanel()) {
      @case ('settings') {
        @if (panelService.showSettings) {
          <core-settings-panel class="panel" />
        }
      }
      @case ('fields') {
        <core-fields-panel class="panel" />
      }
      @case ('add-field') {
        <core-add-field-panel class="panel" />
      }
      @case ('forms') {
        <core-forms-panel class="panel" />
      }
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldsPanel,
				selector: "core-fields-panel"
			},
			{
				kind: "component",
				type: AddFieldPanel,
				selector: "core-add-field-panel"
			},
			{
				kind: "component",
				type: FormsPanel,
				selector: "core-forms-panel"
			},
			{
				kind: "component",
				type: PanelOptionList,
				selector: "core-panel-option-list",
				inputs: [
					"options",
					"position",
					"value"
				],
				outputs: ["valueChange", "selected"]
			},
			{
				kind: "component",
				type: SettingsPanel,
				selector: "core-settings-panel"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LHSSidebar,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-lhs-sidebar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldsPanel,
				AddFieldPanel,
				FormsPanel,
				PanelOptionList,
				SettingsPanel
			],
			host: { class: "flex h-full min-h-0 min-w-0 shrink-0" },
			template: `
    <core-panel-option-list
      position="left"
      [options]="panelOptions"
      [value]="activePanel()"
      (selected)="setActivePanel($event)"
    />
    @switch (activePanel()) {
      @case ('settings') {
        @if (panelService.showSettings) {
          <core-settings-panel class="panel" />
        }
      }
      @case ('fields') {
        <core-fields-panel class="panel" />
      }
      @case ('add-field') {
        <core-add-field-panel class="panel" />
      }
      @case ('forms') {
        <core-forms-panel class="panel" />
      }
    }
  `
		}]
	}]
});
var RHSSidebar = class RHSSidebar {
	panelService = inject(PanelService);
	activePanel = this.panelService.activeRHSPanel;
	panelOptions = [
		{
			label: "Field Edit",
			value: "field-edit",
			matIcon: "edit_square"
		},
		{
			label: "Validation",
			value: "validation",
			matIcon: "rule"
		},
		{
			label: "Styling",
			value: "styling",
			matIcon: "palette"
		},
		{
			label: "Model",
			value: "model",
			matIcon: "database"
		}
	];
	setActivePanel(panel) {
		this.panelService.setActiveRHSPanel(panel);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: RHSSidebar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: RHSSidebar,
		isStandalone: true,
		selector: "core-rhs-sidebar",
		host: { classAttribute: "flex h-full min-h-0 min-w-0 shrink-0" },
		ngImport: i0,
		template: `
    @switch (activePanel()) {
      @case ('field-edit') {
        <core-field-edit-panel class="panel" />
      }
      @case ('styling') {
        <core-styling-panel class="panel" />
      }
      @case ('validation') {
        <core-validation-panel class="panel" />
      }
      @case ('model') {
        <core-model-edit-panel class="panel" />
      }
    }
    <core-panel-option-list
      position="right"
      [options]="panelOptions"
      [value]="activePanel()"
      (selected)="setActivePanel($event)"
    />
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FieldEditPanel,
				selector: "core-field-edit-panel"
			},
			{
				kind: "component",
				type: ValidationPanel,
				selector: "core-validation-panel"
			},
			{
				kind: "component",
				type: StylingPanel,
				selector: "core-styling-panel",
				outputs: ["fieldChange"]
			},
			{
				kind: "component",
				type: ModelEditPanel,
				selector: "core-model-edit-panel"
			},
			{
				kind: "component",
				type: PanelOptionList,
				selector: "core-panel-option-list",
				inputs: [
					"options",
					"position",
					"value"
				],
				outputs: ["valueChange", "selected"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: RHSSidebar,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-rhs-sidebar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FieldEditPanel,
				ValidationPanel,
				StylingPanel,
				ModelEditPanel,
				PanelOptionList
			],
			host: { class: "flex h-full min-h-0 min-w-0 shrink-0" },
			template: `
    @switch (activePanel()) {
      @case ('field-edit') {
        <core-field-edit-panel class="panel" />
      }
      @case ('styling') {
        <core-styling-panel class="panel" />
      }
      @case ('validation') {
        <core-validation-panel class="panel" />
      }
      @case ('model') {
        <core-model-edit-panel class="panel" />
      }
    }
    <core-panel-option-list
      position="right"
      [options]="panelOptions"
      [value]="activePanel()"
      (selected)="setActivePanel($event)"
    />
  `
		}]
	}]
});
const TABLET_PANEL_OPTIONS = [
	{
		label: "Workspace",
		value: "forms",
		matIcon: "assignment"
	},
	{
		label: "Fields",
		value: "fields",
		matIcon: "lists"
	},
	{
		label: "Add Field",
		value: "add-field",
		matIcon: "add"
	},
	{
		label: "Field Edit",
		value: "field-edit",
		matIcon: "edit_square"
	},
	{
		label: "Validation",
		value: "validation",
		matIcon: "rule"
	},
	{
		label: "Styling",
		value: "styling",
		matIcon: "palette"
	},
	{
		label: "Model",
		value: "model",
		matIcon: "database"
	},
	{
		label: "Builder settings",
		value: "settings",
		matIcon: "settings"
	}
];
var TabletSidebar = class TabletSidebar {
	panelService = inject(PanelService);
	activePanel = this.panelService.activePanel;
	panelOptions = TABLET_PANEL_OPTIONS;
	setActivePanel(panel) {
		this.panelService.setActivePanel(panel);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TabletSidebar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TabletSidebar,
		isStandalone: true,
		selector: "core-tablet-sidebar",
		host: { classAttribute: "flex h-full min-w-0" },
		ngImport: i0,
		template: `
    <core-panel-option-list
      position="left"
      [options]="panelOptions"
      [value]="activePanel()"
      (selected)="setActivePanel($event)"
    />
    <div class="min-h-0 min-w-0 grow">
      @switch (activePanel()) {
        @case ('forms') {
          <core-forms-panel class="panel" />
        }
        @case ('settings') {
          @if (panelService.showSettings) {
            <core-settings-panel class="panel" />
          }
        }
        @case ('field-edit') {
          <core-field-edit-panel class="panel" />
        }
        @case ('styling') {
          <core-styling-panel class="panel" />
        }
        @case ('validation') {
          <core-validation-panel class="panel" />
        }
        @case ('model') {
          <core-model-edit-panel class="panel" />
        }
        @case ('fields') {
          <core-fields-panel class="panel" />
        }
        @case ('add-field') {
          <core-add-field-panel class="panel" />
        }
      }
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: AddFieldPanel,
				selector: "core-add-field-panel"
			},
			{
				kind: "component",
				type: FieldEditPanel,
				selector: "core-field-edit-panel"
			},
			{
				kind: "component",
				type: FieldsPanel,
				selector: "core-fields-panel"
			},
			{
				kind: "component",
				type: FormsPanel,
				selector: "core-forms-panel"
			},
			{
				kind: "component",
				type: ModelEditPanel,
				selector: "core-model-edit-panel"
			},
			{
				kind: "component",
				type: PanelOptionList,
				selector: "core-panel-option-list",
				inputs: [
					"options",
					"position",
					"value"
				],
				outputs: ["valueChange", "selected"]
			},
			{
				kind: "component",
				type: StylingPanel,
				selector: "core-styling-panel",
				outputs: ["fieldChange"]
			},
			{
				kind: "component",
				type: ValidationPanel,
				selector: "core-validation-panel"
			},
			{
				kind: "component",
				type: SettingsPanel,
				selector: "core-settings-panel"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TabletSidebar,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-tablet-sidebar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				AddFieldPanel,
				FieldEditPanel,
				FieldsPanel,
				FormsPanel,
				ModelEditPanel,
				PanelOptionList,
				StylingPanel,
				ValidationPanel,
				SettingsPanel
			],
			host: { class: "flex h-full min-w-0" },
			template: `
    <core-panel-option-list
      position="left"
      [options]="panelOptions"
      [value]="activePanel()"
      (selected)="setActivePanel($event)"
    />
    <div class="min-h-0 min-w-0 grow">
      @switch (activePanel()) {
        @case ('forms') {
          <core-forms-panel class="panel" />
        }
        @case ('settings') {
          @if (panelService.showSettings) {
            <core-settings-panel class="panel" />
          }
        }
        @case ('field-edit') {
          <core-field-edit-panel class="panel" />
        }
        @case ('styling') {
          <core-styling-panel class="panel" />
        }
        @case ('validation') {
          <core-validation-panel class="panel" />
        }
        @case ('model') {
          <core-model-edit-panel class="panel" />
        }
        @case ('fields') {
          <core-fields-panel class="panel" />
        }
        @case ('add-field') {
          <core-add-field-panel class="panel" />
        }
      }
    </div>
  `
		}]
	}]
});
var FormlyBuilder = class FormlyBuilder {
	hideFormTitle = input(false, ...ngDevMode ? [{ debugName: "hideFormTitle" }] : /* istanbul ignore next */ []);
	destroyRef = inject(DestroyRef);
	responsiveService = inject(CoreResponsiveService);
	panelService = inject(PanelService);
	viewContainerRef = inject(ViewContainerRef);
	isDesktop = this.responsiveService.isDesktop;
	isTablet = this.responsiveService.isTablet;
	isMobile = this.responsiveService.isMobile;
	panelSizes = signal([
		20,
		60,
		20
	], ...ngDevMode ? [{ debugName: "panelSizes" }] : /* istanbul ignore next */ []);
	minSizes = signal([20, 20], ...ngDevMode ? [{ debugName: "minSizes" }] : /* istanbul ignore next */ []);
	tabletPanelSizes = signal([40, 60], ...ngDevMode ? [{ debugName: "tabletPanelSizes" }] : /* istanbul ignore next */ []);
	tabletMinSizes = signal([28, 40], ...ngDevMode ? [{ debugName: "tabletMinSizes" }] : /* istanbul ignore next */ []);
	mobileDrawerVisible = signal(false, ...ngDevMode ? [{ debugName: "mobileDrawerVisible" }] : /* istanbul ignore next */ []);
	activePanel = this.panelService.activePanel;
	panelOptions = TABLET_PANEL_OPTIONS;
	constructor() {
		let destroyed = false;
		this.destroyRef.onDestroy(() => destroyed = true);
		import("./ngx-formly-builder-ui-app-dialogs-E0Rxyi5S.mjs").then(({ AppDialogs }) => {
			if (!destroyed) this.viewContainerRef.createComponent(AppDialogs);
		});
		this.panelService.highlightPanel$.pipe(takeUntilDestroyed()).subscribe(() => {
			if (this.isMobile()) this.mobileDrawerVisible.set(true);
		});
	}
	openMobilePanel(panel) {
		this.panelService.setActivePanel(panel);
		this.mobileDrawerVisible.set(true);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyBuilder,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormlyBuilder,
		isStandalone: true,
		selector: "formly-builder",
		inputs: { hideFormTitle: {
			classPropertyName: "hideFormTitle",
			publicName: "hideFormTitle",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "core-root block h-full min-h-0" },
		ngImport: i0,
		template: `
    @if (isDesktop()) {
      <core-splitter
        class="h-full min-h-0"
        stateKey="formly-studio-main-splitter-desktop"
        [panelSizes]="panelSizes()"
        [minSizes]="minSizes()"
      >
        <ng-template #panel>
          <core-lhs-sidebar />
        </ng-template>
        <ng-template #panel>
          <core-form-panel [hideFormTitle]="hideFormTitle()" />
        </ng-template>
        <ng-template #panel>
          <core-rhs-sidebar />
        </ng-template>
      </core-splitter>
    } @else if (isTablet()) {
      <core-splitter
        class="h-full min-h-0"
        stateKey="formly-studio-main-splitter-tablet"
        [panelSizes]="tabletPanelSizes()"
        [minSizes]="tabletMinSizes()"
      >
        <ng-template #panel>
          <core-tablet-sidebar />
        </ng-template>
        <ng-template #panel>
          <core-form-panel [hideFormTitle]="hideFormTitle()" />
        </ng-template>
      </core-splitter>
    } @else if (isMobile()) {
      <div class="flex h-full min-w-0">
        <core-panel-option-list
          position="left"
          [options]="panelOptions"
          [value]="activePanel()"
          (selected)="openMobilePanel($event)"
        />
        <core-form-panel
          class="min-w-0 grow"
          [hideFormTitle]="hideFormTitle()"
        />
      </div>

      <core-dialog
        header="Editor panels"
        role="complementary"
        [visible]="mobileDrawerVisible()"
        [style]="{ width: 'min(92vw, 30rem)', height: '100dvh', maxHeight: '100dvh' }"
        (visibleChange)="mobileDrawerVisible.set($event)"
      >
        <core-tablet-sidebar class="h-full min-h-0 min-w-0 overflow-hidden" />
      </core-dialog>
    }
  `,
		isInline: true,
		dependencies: [
			{
				kind: "component",
				type: FormPanel,
				selector: "core-form-panel",
				inputs: ["hideFormTitle"]
			},
			{
				kind: "component",
				type: Dialog,
				selector: "core-dialog",
				inputs: [
					"visible",
					"header",
					"focusOnShow",
					"style",
					"pt",
					"closable",
					"closeOnEscape",
					"role"
				],
				outputs: ["visibleChange", "opened"]
			},
			{
				kind: "component",
				type: PanelOptionList,
				selector: "core-panel-option-list",
				inputs: [
					"options",
					"position",
					"value"
				],
				outputs: ["valueChange", "selected"]
			},
			{
				kind: "component",
				type: Splitter,
				selector: "core-splitter",
				inputs: [
					"panelSizes",
					"minSizes",
					"stateKey"
				]
			},
			{
				kind: "component",
				type: LHSSidebar,
				selector: "core-lhs-sidebar"
			},
			{
				kind: "component",
				type: RHSSidebar,
				selector: "core-rhs-sidebar"
			},
			{
				kind: "component",
				type: TabletSidebar,
				selector: "core-tablet-sidebar"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormlyBuilder,
	decorators: [{
		type: Component,
		args: [{
			selector: "formly-builder",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				FormPanel,
				Dialog,
				PanelOptionList,
				Splitter,
				LHSSidebar,
				RHSSidebar,
				TabletSidebar
			],
			host: { class: "core-root block h-full min-h-0" },
			template: `
    @if (isDesktop()) {
      <core-splitter
        class="h-full min-h-0"
        stateKey="formly-studio-main-splitter-desktop"
        [panelSizes]="panelSizes()"
        [minSizes]="minSizes()"
      >
        <ng-template #panel>
          <core-lhs-sidebar />
        </ng-template>
        <ng-template #panel>
          <core-form-panel [hideFormTitle]="hideFormTitle()" />
        </ng-template>
        <ng-template #panel>
          <core-rhs-sidebar />
        </ng-template>
      </core-splitter>
    } @else if (isTablet()) {
      <core-splitter
        class="h-full min-h-0"
        stateKey="formly-studio-main-splitter-tablet"
        [panelSizes]="tabletPanelSizes()"
        [minSizes]="tabletMinSizes()"
      >
        <ng-template #panel>
          <core-tablet-sidebar />
        </ng-template>
        <ng-template #panel>
          <core-form-panel [hideFormTitle]="hideFormTitle()" />
        </ng-template>
      </core-splitter>
    } @else if (isMobile()) {
      <div class="flex h-full min-w-0">
        <core-panel-option-list
          position="left"
          [options]="panelOptions"
          [value]="activePanel()"
          (selected)="openMobilePanel($event)"
        />
        <core-form-panel
          class="min-w-0 grow"
          [hideFormTitle]="hideFormTitle()"
        />
      </div>

      <core-dialog
        header="Editor panels"
        role="complementary"
        [visible]="mobileDrawerVisible()"
        [style]="{ width: 'min(92vw, 30rem)', height: '100dvh', maxHeight: '100dvh' }"
        (visibleChange)="mobileDrawerVisible.set($event)"
      >
        <core-tablet-sidebar class="h-full min-h-0 min-w-0 overflow-hidden" />
      </core-dialog>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { hideFormTitle: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "hideFormTitle",
			required: false
		}]
	}] }
});
var BuilderFieldStateService$1 = class BuilderFieldStateService$1 extends BuilderFieldStateService {
	constructor() {
		super(inject(CoreFormService));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderFieldStateService$1,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderFieldStateService$1
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderFieldStateService$1,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function getDropPosition(x, y, rect, isParent) {
	const horizontal = (x - rect.left) / rect.width;
	const vertical = (y - rect.top) / rect.height;
	if (isParent && horizontal > .25 && horizontal < .75 && vertical > .25 && vertical < .75) return "center";
	const sideDistance = Math.min(horizontal, 1 - horizontal);
	if (Math.min(vertical, 1 - vertical) <= sideDistance) return vertical < .5 ? "top" : "bottom";
	return horizontal < .5 ? "left" : "right";
}
var FormlyFieldHeader = class FormlyFieldHeader {
	field = input.required(...ngDevMode ? [{ debugName: "field" }] : /* istanbul ignore next */ []);
	fieldInfo = input.required(...ngDevMode ? [{ debugName: "fieldInfo" }] : /* istanbul ignore next */ []);
	fieldKey = input(...ngDevMode ? [void 0, { debugName: "fieldKey" }] : /* istanbul ignore next */ []);
	isMouseInside = input.required(...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	addMenuChild = viewChild("addMenu", {
		...ngDevMode ? { debugName: "addMenuChild" } : /* istanbul ignore next */ {},
		read: Menu
	});
	otherOptionsMenuChild = viewChild("otherOptionsMenu", {
		...ngDevMode ? { debugName: "otherOptionsMenuChild" } : /* istanbul ignore next */ {},
		read: Menu
	});
	replaceOptionsMenuChild = viewChild("replaceOptionsMenu", {
		...ngDevMode ? { debugName: "replaceOptionsMenuChild" } : /* istanbul ignore next */ {},
		read: Menu
	});
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	presetDialogService = inject(FieldPresetDialogService);
	savePresetName = signal("", ...ngDevMode ? [{ debugName: "savePresetName" }] : /* istanbul ignore next */ []);
	savePresetJSON = signal("", ...ngDevMode ? [{ debugName: "savePresetJSON" }] : /* istanbul ignore next */ []);
	isSavePresetDialogOpen = signal(false, ...ngDevMode ? [{ debugName: "isSavePresetDialogOpen" }] : /* istanbul ignore next */ []);
	isSavable = computed(() => !this.fieldInfo().isRoot, ...ngDevMode ? [{ debugName: "isSavable" }] : /* istanbul ignore next */ []);
	isRemovable = computed(() => !this.fieldInfo().isRoot, ...ngDevMode ? [{ debugName: "isRemovable" }] : /* istanbul ignore next */ []);
	isDraggable = computed(() => !this.fieldInfo().isRoot, ...ngDevMode ? [{ debugName: "isDraggable" }] : /* istanbul ignore next */ []);
	fieldIcon = computed(() => {
		return this.fieldService.getFieldIcon(this.field());
	}, ...ngDevMode ? [{ debugName: "fieldIcon" }] : /* istanbul ignore next */ []);
	addOptions = computed(() => this.formService.getAddOptions(this.fieldInfo()), ...ngDevMode ? [{ debugName: "addOptions" }] : /* istanbul ignore next */ []);
	replaceOptions = computed(() => this.formService.getReplaceOptions(this.fieldInfo()), ...ngDevMode ? [{ debugName: "replaceOptions" }] : /* istanbul ignore next */ []);
	otherOptions = computed(() => {
		const options = [];
		const fieldInfo = this.fieldInfo();
		const fieldIndex = this.formService.getFieldIndex(fieldInfo.id);
		const siblingIds = this.siblingIds();
		const parentId = fieldInfo.idPath.at(-2);
		const inRow = !!parentId && isLayoutRow(this.formService.getField(parentId));
		if (fieldIndex > 0) options.push({
			label: inRow ? "Move left" : "Move up",
			matIcon: inRow ? "arrow_back" : "arrow_upward",
			command: () => this.moveField(-1)
		});
		if (fieldIndex >= 0 && fieldIndex < siblingIds.length - 1) options.push({
			label: inRow ? "Move right" : "Move down",
			matIcon: inRow ? "arrow_forward" : "arrow_downward",
			command: () => this.moveField(1)
		});
		if (inRow && parentId) options.push({
			label: "Move above row",
			matIcon: "arrow_upward",
			command: () => this.formService.dropField(parentId, "top", { fieldId: fieldInfo.id })
		}, {
			label: "Move below row",
			matIcon: "arrow_downward",
			command: () => this.formService.dropField(parentId, "bottom", { fieldId: fieldInfo.id })
		});
		if (!this.fieldInfo().isRoot) options.push({
			label: "Save as Preset",
			matIcon: "save",
			command: () => this.openPresetDialog()
		}, {
			label: "Remove",
			matIcon: "delete",
			warn: true,
			command: () => this.removeField()
		});
		return options;
	}, ...ngDevMode ? [{ debugName: "otherOptions" }] : /* istanbul ignore next */ []);
	siblingIds = computed(() => {
		const parentId = this.fieldInfo().idPath[this.fieldInfo().idPath.length - 2];
		if (!parentId) return this.formService.activeRootFieldIds();
		const parent = this.formService.getField(parentId);
		return parent ? this.fieldService.getChildIds(parent._info) : [];
	}, ...ngDevMode ? [{ debugName: "siblingIds" }] : /* istanbul ignore next */ []);
	areOptionsVisible = computed(() => this.isMouseInside() || this.addMenuChild()?.visible || this.otherOptionsMenuChild()?.visible || this.replaceOptionsMenuChild()?.visible, ...ngDevMode ? [{ debugName: "areOptionsVisible" }] : /* istanbul ignore next */ []);
	openAddMenu(event) {
		this.addMenuChild()?.show(event);
		event.preventDefault();
	}
	openOtherOptionsMenu(event) {
		this.otherOptionsMenuChild()?.show(event);
		event.preventDefault();
	}
	openReplaceOptionsMenu(event) {
		this.replaceOptionsMenuChild()?.show(event);
		event.preventDefault();
	}
	openPresetDialog() {
		const fieldMap = this.formService.activeFieldMap();
		const field = this.formService.buildField(this.fieldInfo().id, fieldMap);
		this.formService.cleanField(field);
		const fieldJSON = JSON.stringify(field, null, 2);
		this.presetDialogService.open({
			name: `My ${this.fieldInfo().name}`,
			json: fieldJSON
		});
	}
	removeField() {
		this.formService.removeField(this.fieldInfo().id);
	}
	moveField(direction) {
		const fieldInfo = this.fieldInfo();
		const fieldIndex = this.formService.getFieldIndex(fieldInfo.id);
		if (fieldIndex < 0) return;
		const parentId = fieldInfo.idPath[fieldInfo.idPath.length - 2];
		const targetIndex = direction === -1 ? fieldIndex - 1 : fieldIndex + 2;
		this.formService.moveField(fieldInfo.id, fieldIndex, targetIndex, parentId);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyFieldHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormlyFieldHeader,
		isStandalone: true,
		selector: "core-formly-field-header",
		inputs: {
			field: {
				classPropertyName: "field",
				publicName: "field",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			fieldInfo: {
				classPropertyName: "fieldInfo",
				publicName: "fieldInfo",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			fieldKey: {
				classPropertyName: "fieldKey",
				publicName: "fieldKey",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isMouseInside: {
				classPropertyName: "isMouseInside",
				publicName: "isMouseInside",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		host: {
			properties: {
				"class.cursor-grab": "isDraggable()",
				"class.cursor-pointer": "!isDraggable()"
			},
			classAttribute: "flex justify-between rounded-t-sm bg-primary/20 px-2"
		},
		viewQueries: [
			{
				propertyName: "addMenuChild",
				first: true,
				predicate: ["addMenu"],
				descendants: true,
				read: Menu,
				isSignal: true
			},
			{
				propertyName: "otherOptionsMenuChild",
				first: true,
				predicate: ["otherOptionsMenu"],
				descendants: true,
				read: Menu,
				isSignal: true
			},
			{
				propertyName: "replaceOptionsMenuChild",
				first: true,
				predicate: ["replaceOptionsMenu"],
				descendants: true,
				read: Menu,
				isSignal: true
			}
		],
		ngImport: i0,
		template: `
    <div class="flex min-w-24 items-center gap-1.5 overflow-hidden">
      @if (isDraggable()) {
        <i class="material-symbols-outlined opacity-50">drag_indicator</i>
      }
      @if (fieldIcon(); as icon) {
        <i
          class="material-symbols-outlined text-muted-color"
          tooltipPosition="above"
          [style.fontSize]="'1rem'"
          [coreTooltip]="fieldInfo().name"
        >
          {{ icon }}
        </i>
      }
      <span class="truncate">{{ fieldKey() || fieldInfo().name }} </span>
      @if (fieldInfo().badges; as badges) {
        @for (badge of badges; track badge.label) {
          <span
            class="core-chip"
            tooltipPosition="above"
            [coreTooltip]="badge.description"
            >{{ badge.label }}</span
          >
        }
      }
    </div>
    <div
      class="touch-actions-visible flex items-center gap-2 opacity-0 transition-opacity"
      [class.opacity-100]="areOptionsVisible()"
    >
      @if (addOptions().length) {
        <span class="inline-flex">
          <core-menu
            #addMenu
            [model]="addOptions()"
          />
          <button
            coreButton
            text
            class="size-6"
            aria-label="Add Field"
            coreTooltip="Add Field"
            tooltipPosition="above"
            (click)="openAddMenu($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              add
            </i>
          </button>
        </span>
      }
      @if (replaceOptions().length) {
        <span class="inline-flex">
          <core-menu
            #replaceOptionsMenu
            [model]="replaceOptions()"
          />
          <button
            coreButton
            text
            class="size-6"
            aria-label="Replace Field"
            coreTooltip="Replace Field"
            tooltipPosition="above"
            (click)="openReplaceOptionsMenu($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              swap_horiz
            </i>
          </button>
        </span>
      }
      @if (otherOptions().length) {
        <span class="inline-flex">
          <core-menu
            #otherOptionsMenu
            [model]="otherOptions()"
          >
            <ng-template
              #item
              let-item
            >
              <button
                type="button"
                tabindex="-1"
                class="flex w-full cursor-pointer items-center gap-2 px-3 py-1 text-start"
                [class.text-button-text-danger]="item.warn"
              >
                @if (item.matIcon) {
                  <i class="material-symbols-outlined">
                    {{ item.matIcon }}
                  </i>
                }
                {{ item.label }}
              </button>
            </ng-template>
          </core-menu>
          <button
            coreButton
            text
            class="size-6"
            aria-label="Options"
            coreTooltip="Options"
            tooltipPosition="above"
            (click)="openOtherOptionsMenu($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              more_horiz
            </i>
          </button>
        </span>
      }
    </div>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: Tooltip,
			selector: "[coreTooltip]"
		}, {
			kind: "component",
			type: Menu,
			selector: "core-menu",
			inputs: ["model", "ariaLabel"],
			outputs: ["opened", "dismissed"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormlyFieldHeader,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-formly-field-header",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [Tooltip, Menu],
			host: {
				class: "flex justify-between rounded-t-sm bg-primary/20 px-2",
				"[class.cursor-grab]": "isDraggable()",
				"[class.cursor-pointer]": "!isDraggable()"
			},
			template: `
    <div class="flex min-w-24 items-center gap-1.5 overflow-hidden">
      @if (isDraggable()) {
        <i class="material-symbols-outlined opacity-50">drag_indicator</i>
      }
      @if (fieldIcon(); as icon) {
        <i
          class="material-symbols-outlined text-muted-color"
          tooltipPosition="above"
          [style.fontSize]="'1rem'"
          [coreTooltip]="fieldInfo().name"
        >
          {{ icon }}
        </i>
      }
      <span class="truncate">{{ fieldKey() || fieldInfo().name }} </span>
      @if (fieldInfo().badges; as badges) {
        @for (badge of badges; track badge.label) {
          <span
            class="core-chip"
            tooltipPosition="above"
            [coreTooltip]="badge.description"
            >{{ badge.label }}</span
          >
        }
      }
    </div>
    <div
      class="touch-actions-visible flex items-center gap-2 opacity-0 transition-opacity"
      [class.opacity-100]="areOptionsVisible()"
    >
      @if (addOptions().length) {
        <span class="inline-flex">
          <core-menu
            #addMenu
            [model]="addOptions()"
          />
          <button
            coreButton
            text
            class="size-6"
            aria-label="Add Field"
            coreTooltip="Add Field"
            tooltipPosition="above"
            (click)="openAddMenu($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              add
            </i>
          </button>
        </span>
      }
      @if (replaceOptions().length) {
        <span class="inline-flex">
          <core-menu
            #replaceOptionsMenu
            [model]="replaceOptions()"
          />
          <button
            coreButton
            text
            class="size-6"
            aria-label="Replace Field"
            coreTooltip="Replace Field"
            tooltipPosition="above"
            (click)="openReplaceOptionsMenu($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              swap_horiz
            </i>
          </button>
        </span>
      }
      @if (otherOptions().length) {
        <span class="inline-flex">
          <core-menu
            #otherOptionsMenu
            [model]="otherOptions()"
          >
            <ng-template
              #item
              let-item
            >
              <button
                type="button"
                tabindex="-1"
                class="flex w-full cursor-pointer items-center gap-2 px-3 py-1 text-start"
                [class.text-button-text-danger]="item.warn"
              >
                @if (item.matIcon) {
                  <i class="material-symbols-outlined">
                    {{ item.matIcon }}
                  </i>
                }
                {{ item.label }}
              </button>
            </ng-template>
          </core-menu>
          <button
            coreButton
            text
            class="size-6"
            aria-label="Options"
            coreTooltip="Options"
            tooltipPosition="above"
            (click)="openOtherOptionsMenu($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
            >
              more_horiz
            </i>
          </button>
        </span>
      }
    </div>
  `
		}]
	}],
	propDecorators: {
		field: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "field",
				required: true
			}]
		}],
		fieldInfo: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldInfo",
				required: true
			}]
		}],
		fieldKey: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "fieldKey",
				required: false
			}]
		}],
		isMouseInside: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isMouseInside",
				required: true
			}]
		}],
		addMenuChild: [{
			type: i0.ViewChild,
			args: ["addMenu", {
				read: Menu,
				isSignal: true
			}]
		}],
		otherOptionsMenuChild: [{
			type: i0.ViewChild,
			args: ["otherOptionsMenu", {
				read: Menu,
				isSignal: true
			}]
		}],
		replaceOptionsMenuChild: [{
			type: i0.ViewChild,
			args: ["replaceOptionsMenu", {
				read: Menu,
				isSignal: true
			}]
		}]
	}
});
var FormlyFieldOverlay = class FormlyFieldOverlay {
	positionClasses = {
		top: "inset-x-0 -top-1 h-1",
		bottom: "inset-x-0 -bottom-1 h-1",
		left: "inset-y-0 -left-1 w-1",
		right: "inset-y-0 -right-1 w-1",
		center: ""
	};
	canDrop = input.required({
		...ngDevMode ? { debugName: "canDrop" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	hoverPosition = input.required(...ngDevMode ? [{ debugName: "hoverPosition" }] : /* istanbul ignore next */ []);
	showCenter = input(false, {
		...ngDevMode ? { debugName: "showCenter" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	showSides = input(false, {
		...ngDevMode ? { debugName: "showSides" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyFieldOverlay,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FormlyFieldOverlay,
		isStandalone: true,
		selector: "core-formly-field-overlay",
		inputs: {
			canDrop: {
				classPropertyName: "canDrop",
				publicName: "canDrop",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			hoverPosition: {
				classPropertyName: "hoverPosition",
				publicName: "hoverPosition",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			showCenter: {
				classPropertyName: "showCenter",
				publicName: "showCenter",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			showSides: {
				classPropertyName: "showSides",
				publicName: "showSides",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		host: {
			attributes: { "aria-hidden": "true" },
			properties: { "attr.data-drop-position": "canDrop() ? hoverPosition() : null" },
			classAttribute: "absolute inset-0 pointer-events-none touch-none z-20"
		},
		ngImport: i0,
		template: `
    @if (canDrop()) {
      @if (showSides() && hoverPosition() !== 'center') {
        <div
          class="absolute rounded-full bg-primary"
          [class]="positionClasses[hoverPosition() ?? 'center']"
        ></div>
      }
      @if (showCenter() && hoverPosition() === 'center') {
        <div
          class="absolute inset-0 flex items-center justify-center rounded-sm border-2 border-dashed border-primary bg-primary/10"
        >
          <span class="rounded bg-primary px-2 py-1 text-sm text-primary-contrast"
            >Drop inside</span
          >
        </div>
      }
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormlyFieldOverlay,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-formly-field-overlay",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				class: "absolute inset-0 pointer-events-none touch-none z-20",
				"aria-hidden": "true",
				"[attr.data-drop-position]": "canDrop() ? hoverPosition() : null"
			},
			template: `
    @if (canDrop()) {
      @if (showSides() && hoverPosition() !== 'center') {
        <div
          class="absolute rounded-full bg-primary"
          [class]="positionClasses[hoverPosition() ?? 'center']"
        ></div>
      }
      @if (showCenter() && hoverPosition() === 'center') {
        <div
          class="absolute inset-0 flex items-center justify-center rounded-sm border-2 border-dashed border-primary bg-primary/10"
        >
          <span class="rounded bg-primary px-2 py-1 text-sm text-primary-contrast"
            >Drop inside</span
          >
        </div>
      }
    }
  `
		}]
	}],
	propDecorators: {
		canDrop: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canDrop",
				required: true
			}]
		}],
		hoverPosition: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "hoverPosition",
				required: true
			}]
		}],
		showCenter: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showCenter",
				required: false
			}]
		}],
		showSides: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "showSides",
				required: false
			}]
		}]
	}
});
var CoreFieldWrapper = class CoreFieldWrapper extends FieldWrapper {
	formService = inject(CoreFormService);
	fieldService = inject(CoreFieldService);
	dndService = inject(DNDService);
	elementRef = inject(ElementRef);
	fieldInfo;
	isDraggable;
	isActiveField = computed(() => {
		return this.formService.activeFieldId() === this.fieldInfo.id;
	}, ...ngDevMode ? [{ debugName: "isActiveField" }] : /* istanbul ignore next */ []);
	isMouseInside = computed(() => {
		return this.formService.activeMouseInside() === this.fieldInfo.id;
	}, ...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	borderColor = computed(() => {
		if (this.isActiveField()) return "border-primary/70";
		if (this.isMouseInside()) return "border-primary/30";
		return "border-transparent";
	}, ...ngDevMode ? [{ debugName: "borderColor" }] : /* istanbul ignore next */ []);
	fieldOptions = this.fieldService.activeFieldCategoryOptions;
	boundingRect = computed(() => {
		this.dndService.activeDragData();
		this.dndService.activeDragOverData();
		return this.elementRef.nativeElement.getBoundingClientRect();
	}, ...ngDevMode ? [{ debugName: "boundingRect" }] : /* istanbul ignore next */ []);
	canDrop = computed(() => {
		const activeDragData = this.dndService.activeDragData();
		const position = this.hoverPosition();
		if (!activeDragData || !position) return false;
		return this.formService.canDropField(activeDragData.action === DropAction.MOVE ? activeDragData.fieldId : void 0, this.fieldInfo.id, position);
	}, ...ngDevMode ? [{ debugName: "canDrop" }] : /* istanbul ignore next */ []);
	showExpandedDropzone = computed(() => {
		if (!this.dndService.activeDragData()) return false;
		return this.fieldInfo.isParent && !this.fieldInfo.isRoot && !(!!this.field.fieldGroup?.length || Object.keys(this.field.fieldArray ?? {}).length);
	}, ...ngDevMode ? [{ debugName: "showExpandedDropzone" }] : /* istanbul ignore next */ []);
	hoverPosition = computed(() => {
		const activeDragOverData = this.dndService.activeDragOverData();
		if (!activeDragOverData || activeDragOverData.fieldId !== this.fieldInfo.id) return null;
		if (this.fieldInfo.isRoot) return "center";
		return getDropPosition(activeDragOverData.clientX, activeDragOverData.clientY, this.boundingRect(), !!this.fieldInfo.isParent);
	}, ...ngDevMode ? [{ debugName: "hoverPosition" }] : /* istanbul ignore next */ []);
	rowIndicator = computed(() => {
		const position = this.hoverPosition();
		if (position !== "top" && position !== "bottom") return null;
		const element = this.elementRef.nativeElement;
		const row = element.closest(".formly-builder-row");
		if (!row) return null;
		const bounds = element.getBoundingClientRect();
		const rowBounds = row.getBoundingClientRect();
		return {
			left: rowBounds.left - bounds.left,
			top: rowBounds.top - bounds.top,
			width: rowBounds.width,
			height: rowBounds.height
		};
	}, ...ngDevMode ? [{ debugName: "rowIndicator" }] : /* istanbul ignore next */ []);
	ngOnInit() {
		this.fieldInfo = this.formService.getField(this.field._info.id)._info;
		this.isDraggable = !this.fieldInfo.isRoot;
	}
	ngOnDestroy() {
		this.setMouseLeft();
	}
	onDragStart() {
		this.dndService.setActiveDragData({
			action: DropAction.MOVE,
			fieldType: this.field.type,
			fieldId: this.fieldInfo.id,
			index: this.formService.getFieldIndex(this.fieldInfo.id)
		});
	}
	onDragover(event) {
		this.dndService.setActiveDragOverData({
			fieldId: this.fieldInfo.id,
			clientX: event.clientX,
			clientY: event.clientY
		});
		event.preventDefault();
	}
	onDrop() {
		const dragData = this.dndService.activeDragData();
		if (!dragData || !this.canDrop()) return;
		const position = this.hoverPosition();
		if (!position) return;
		this.formService.dropField(this.fieldInfo.id, position, dragData.action === DropAction.COPY ? {
			fieldType: dragData.fieldType,
			preset: dragData.preset
		} : { fieldId: dragData.fieldId });
		this.onDragEnd();
	}
	onDragLeave() {
		if (this.dndService.activeDragOverData()?.fieldId === this.fieldInfo.id) this.dndService.setActiveDragOverData(null);
	}
	onDragEnd() {
		this.dndService.setActiveDragData(null);
		this.dndService.setActiveDragOverData(null);
	}
	setActiveField() {
		this.formService.setActiveField(this.fieldInfo.id);
	}
	onFieldClick(event) {
		const target = event.target;
		if (!(target instanceof Element)) return;
		if (target.closest("core-field-wrapper") !== event.currentTarget) return;
		this.setActiveField();
	}
	onFieldKeydown(event) {
		if (event.defaultPrevented || this.elementRef.nativeElement.ownerDocument.activeElement !== this.elementRef.nativeElement) return;
		event.preventDefault();
		this.setActiveField();
	}
	setMouseEntered() {
		this.formService.setMouseEnteredField(this.fieldInfo.id);
	}
	setMouseLeft() {
		this.formService.setMouseLeftField(this.fieldInfo.id);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreFieldWrapper,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: CoreFieldWrapper,
		isStandalone: true,
		selector: "core-field-wrapper",
		host: {
			listeners: {
				"mouseenter": "setMouseEntered()",
				"mouseleave": "setMouseLeft()",
				"click": "onFieldClick($event)",
				"keydown.enter": "onFieldKeydown($event)",
				"keydown.space": "onFieldKeydown($event)"
			},
			properties: {
				"id": "fieldInfo.id",
				"tabindex": "0",
				"attr.aria-label": "'Field ' + fieldInfo.id",
				"attr.aria-pressed": "isActiveField()"
			},
			classAttribute: "block"
		},
		usesInheritance: true,
		ngImport: i0,
		template: `
    <div
      dndDropzone
      [class]="'relative rounded-sm border-2 transition-[border-color] ' + this.borderColor()"
      (dndDragover)="onDragover($event)"
      (dndDragleave)="onDragLeave()"
      (dndDrop)="onDrop()"
    >
      <div
        class="h-full w-full"
        dndDraggable
        dndEffectAllowed="move"
        [dndDisableIf]="!isDraggable"
        (dndStart)="onDragStart()"
        (dndEnd)="onDragEnd()"
      >
        <core-formly-field-header
          dndHandle
          [field]="field"
          [fieldInfo]="fieldInfo"
          [fieldKey]="field.key"
          [isMouseInside]="isMouseInside()"
        />

        <div
          class="p-1"
          [class.py-8]="showExpandedDropzone()"
        >
          <ng-template #fieldComponent />
        </div>

        <core-formly-field-overlay
          [canDrop]="canDrop()"
          [hoverPosition]="hoverPosition()"
          [showCenter]="fieldInfo.isParent"
          [showSides]="!fieldInfo.isRoot"
          [style.left.px]="rowIndicator()?.left"
          [style.top.px]="rowIndicator()?.top"
          [style.width.px]="rowIndicator()?.width"
          [style.height.px]="rowIndicator()?.height"
        />
      </div>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "directive",
				type: DndDraggableDirective,
				selector: "[dndDraggable]",
				inputs: [
					"dndDraggable",
					"dndEffectAllowed",
					"dndType",
					"dndDraggingClass",
					"dndDraggingSourceClass",
					"dndHideDraggingSource",
					"dndDraggableDisabledClass",
					"dndDragImageOffsetFunction",
					"dndDisableIf",
					"dndDisableDragIf"
				],
				outputs: [
					"dndStart",
					"dndDrag",
					"dndEnd",
					"dndMoved",
					"dndCopied",
					"dndLinked",
					"dndCanceled"
				]
			},
			{
				kind: "directive",
				type: DndDropzoneDirective,
				selector: "[dndDropzone]",
				inputs: [
					"dndDropzone",
					"dndEffectAllowed",
					"dndAllowExternal",
					"dndHorizontal",
					"dndDragoverClass",
					"dndDropzoneDisabledClass",
					"dndDisableIf",
					"dndDisableDropIf"
				],
				outputs: ["dndDragover", "dndDrop"]
			},
			{
				kind: "directive",
				type: DndHandleDirective,
				selector: "[dndHandle]"
			},
			{
				kind: "component",
				type: FormlyFieldHeader,
				selector: "core-formly-field-header",
				inputs: [
					"field",
					"fieldInfo",
					"fieldKey",
					"isMouseInside"
				]
			},
			{
				kind: "component",
				type: FormlyFieldOverlay,
				selector: "core-formly-field-overlay",
				inputs: [
					"canDrop",
					"hoverPosition",
					"showCenter",
					"showSides"
				]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreFieldWrapper,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-field-wrapper",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				DndDraggableDirective,
				DndDropzoneDirective,
				DndHandleDirective,
				FormlyFieldHeader,
				FormlyFieldOverlay
			],
			host: {
				class: "block",
				"[id]": "fieldInfo.id",
				"[tabindex]": "0",
				"[attr.aria-label]": "'Field ' + fieldInfo.id",
				"[attr.aria-pressed]": "isActiveField()",
				"(mouseenter)": "setMouseEntered()",
				"(mouseleave)": "setMouseLeft()",
				"(click)": "onFieldClick($event)",
				"(keydown.enter)": "onFieldKeydown($event)",
				"(keydown.space)": "onFieldKeydown($event)"
			},
			template: `
    <div
      dndDropzone
      [class]="'relative rounded-sm border-2 transition-[border-color] ' + this.borderColor()"
      (dndDragover)="onDragover($event)"
      (dndDragleave)="onDragLeave()"
      (dndDrop)="onDrop()"
    >
      <div
        class="h-full w-full"
        dndDraggable
        dndEffectAllowed="move"
        [dndDisableIf]="!isDraggable"
        (dndStart)="onDragStart()"
        (dndEnd)="onDragEnd()"
      >
        <core-formly-field-header
          dndHandle
          [field]="field"
          [fieldInfo]="fieldInfo"
          [fieldKey]="field.key"
          [isMouseInside]="isMouseInside()"
        />

        <div
          class="p-1"
          [class.py-8]="showExpandedDropzone()"
        >
          <ng-template #fieldComponent />
        </div>

        <core-formly-field-overlay
          [canDrop]="canDrop()"
          [hoverPosition]="hoverPosition()"
          [showCenter]="fieldInfo.isParent"
          [showSides]="!fieldInfo.isRoot"
          [style.left.px]="rowIndicator()?.left"
          [style.top.px]="rowIndicator()?.top"
          [style.width.px]="rowIndicator()?.width"
          [style.height.px]="rowIndicator()?.height"
        />
      </div>
    </div>
  `
		}]
	}]
});
const numberVariants = [
	"0",
	"0.5",
	"1",
	"1.5",
	"2",
	"2.5",
	"3",
	"3.5",
	"4",
	"5",
	"6",
	"7",
	"8",
	"9",
	"10",
	"11",
	"12",
	"14",
	"16",
	"20",
	"24",
	"28",
	"32",
	"36",
	"40",
	"44",
	"48",
	"52",
	"56",
	"60",
	"64",
	"72",
	"80",
	"96"
];
const spacingLabels = Object.fromEntries(numberVariants.map((value) => [value, `${value} · ${Number(value) * .25}rem`]));
const fractionVariants2 = [
	...[
		"1/2",
		"1/3",
		"2/3",
		"1/4",
		"2/4",
		"3/4",
		"1/5",
		"2/5",
		"3/5",
		"4/5",
		"1/6",
		"2/6",
		"3/6",
		"4/6",
		"5/6"
	],
	"1/12",
	"2/12",
	"3/12",
	"4/12",
	"5/12",
	"6/12",
	"7/12",
	"8/12",
	"9/12",
	"10/12",
	"11/12"
];
const textVariants = ["px", "auto"];
const textVariants2 = [
	...textVariants,
	"full",
	"screen",
	"min",
	"max",
	"fit"
];
const fieldLayout = {
	name: "Layout",
	options: [
		{
			name: "System",
			variants: ["block"],
			spanWidth: true,
			hasBreakpoints: true
		},
		{
			name: "Column Start",
			value: "col-start",
			variants: [
				"1",
				"2",
				"3"
			],
			hasBreakpoints: true,
			dependsOnParent: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "grid"
			}
		},
		{
			name: "Column Span",
			value: "col-span",
			variants: [
				"1",
				"2",
				"3"
			],
			hasBreakpoints: true,
			dependsOnParent: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "grid"
			}
		},
		{
			name: "Row Start",
			value: "row-start",
			variants: [
				"1",
				"2",
				"3"
			],
			hasBreakpoints: true,
			dependsOnParent: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "grid"
			}
		},
		{
			name: "Row Span",
			value: "row-span",
			variants: [
				"1",
				"2",
				"3"
			],
			hasBreakpoints: true,
			dependsOnParent: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "grid"
			}
		}
	]
};
const fieldSizing = {
	name: "Size",
	options: [{
		name: "Height",
		value: "h",
		hasBreakpoints: true,
		variantLabels: spacingLabels,
		variants: [
			...numberVariants,
			...fractionVariants2,
			...textVariants2
		]
	}, {
		name: "Width",
		value: "w",
		hasBreakpoints: true,
		variantLabels: spacingLabels,
		variants: [
			...numberVariants,
			...fractionVariants2,
			...textVariants2
		]
	}]
};
const fieldMargin = {
	name: "Margin",
	options: [
		{
			name: "General",
			value: "m",
			spanWidth: true,
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		},
		{
			name: "Horizintal",
			value: "mx",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		},
		{
			name: "Vertical",
			value: "my",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		},
		{
			name: "Top",
			value: "mt",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		},
		{
			name: "Bottom",
			value: "mb",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		},
		{
			name: "Left",
			value: "ml",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		},
		{
			name: "Right",
			value: "mr",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, ...textVariants]
		}
	]
};
const fieldGroupLayout = {
	name: "Layout",
	options: [
		{
			name: "System",
			variants: [
				"flex",
				"grid",
				"block"
			],
			spanWidth: true
		},
		{
			name: "Flex Direction",
			value: "flex",
			variants: [
				"col",
				"col-reverse",
				"row",
				"row-reverse"
			],
			dependsOn: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "flex"
			},
			spanWidth: true,
			hasBreakpoints: true
		},
		{
			name: "Columns",
			value: "grid-cols",
			variants: [
				"1",
				"2",
				"3"
			],
			dependsOn: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "grid"
			},
			hasBreakpoints: true
		},
		{
			name: "Rows",
			value: "grid-rows",
			variants: [
				"1",
				"2",
				"3"
			],
			dependsOn: {
				type: ClassType.FIELD_GROUP_CLASS_NAME,
				value: "grid"
			},
			hasBreakpoints: true
		},
		{
			name: "Align Items",
			value: "items",
			variants: [
				"start",
				"center",
				"end"
			]
		},
		{
			name: "Justify Content",
			value: "justify",
			variants: [
				"start",
				"center",
				"end",
				"around",
				"between",
				"evenly"
			]
		}
	]
};
const fieldGroupGap = {
	name: "Gap",
	options: [
		{
			name: "General",
			value: "gap",
			spanWidth: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants]
		},
		{
			name: "Horizontal",
			value: "gap-x",
			variantLabels: spacingLabels,
			variants: [...numberVariants]
		},
		{
			name: "Vertical",
			value: "gap-y",
			variantLabels: spacingLabels,
			variants: [...numberVariants]
		}
	]
};
const fieldGroupPadding = {
	name: "Padding",
	options: [
		{
			name: "General",
			value: "p",
			spanWidth: true,
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		},
		{
			name: "Horizintal",
			value: "px",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		},
		{
			name: "Vertical",
			value: "py",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		},
		{
			name: "Top",
			value: "pt",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		},
		{
			name: "Bottom",
			value: "pb",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		},
		{
			name: "Left",
			value: "pl",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		},
		{
			name: "Right",
			value: "pr",
			hasBreakpoints: true,
			variantLabels: spacingLabels,
			variants: [...numberVariants, "px"]
		}
	]
};
const tailwindConfig = {
	label: "Tailwind",
	breakpointAffix: BreakpointAffix.PREFIX,
	breakpoints: [
		{
			name: "Default",
			description: "All devices",
			value: ""
		},
		{
			name: "SM",
			description: "Portrait tablets and large phones, 640px and up",
			value: "sm:"
		},
		{
			name: "MD",
			description: "Landscape tablets, 768px and up",
			value: "md:"
		},
		{
			name: "LG",
			description: "Laptops/desktops, 1024px and up",
			value: "lg:"
		},
		{
			name: "XL",
			description: "Large laptops and desktops, 1280px and up",
			value: "xl:"
		}
	],
	className: [
		fieldLayout,
		fieldSizing,
		fieldMargin
	],
	fieldGroupClassName: [
		fieldGroupLayout,
		fieldGroupGap,
		fieldGroupPadding
	]
};
function provideCore(styles = tailwindConfig) {
	return makeEnvironmentProviders([
		CoreFormService,
		{
			provide: BuilderEngineService,
			useExisting: CoreFormService
		},
		CoreFieldService,
		{
			provide: CORE_STYLES_CONFIG,
			useValue: styles
		},
		PanelService,
		FieldPresetDialogService,
		ExpressionDialogService,
		MarkdownDialogService,
		ArrayTableDialogService,
		DNDService,
		BuilderFieldStateService$1,
		{
			provide: BuilderFieldStateService,
			useExisting: BuilderFieldStateService$1
		}
	]);
}
function provideCoreTheme() {
	return makeEnvironmentProviders([{
		provide: CORE_THEME,
		useFactory: () => signal("light")
	}]);
}
function provideCoreConfig(libraryConfig = [], autoSave = true, overrides = {}) {
	const editorConfig = {
		editorType: overrides.editorType ?? "form-editor",
		defaultTypeOption,
		autoSave,
		autoSaveDelay: overrides.autoSaveDelay,
		showSettings: overrides.showSettings ?? true
	};
	const formlyConfig = {
		wrappers: [{
			name: "core-field",
			component: CoreFieldWrapper
		}],
		extensions: [{
			name: "core-field",
			extension: { postPopulate(field) {
				if (field._info) {
					if (field.wrappers) field.wrappers = field.wrappers.includes("core-field") ? field.wrappers : ["core-field", ...field.wrappers];
					else field.wrappers = ["core-field"];
				}
			} }
		}]
	};
	return makeEnvironmentProviders([
		{
			provide: CORE_EDITOR_CONFIG,
			useValue: editorConfig
		},
		{
			provide: CORE_LIBRARY_CONFIGS,
			useValue: [vanillaLibraryConfig, ...libraryConfig]
		},
		CoreLibraryService,
		provideFormlyConfig(formlyConfig)
	]);
}
function provideFormlyBuilder(config = {}) {
	const formStore = config.formStore ?? LocalFormStoreService;
	return makeEnvironmentProviders([
		provideFormlyCore(),
		provideCore(config.styles),
		provideCoreConfig(config.libraries, config.autoSave ?? true, {
			editorType: config.editorType,
			autoSaveDelay: config.autoSaveDelay,
			showSettings: config.showSettings
		}),
		{
			provide: CORE_FORM_TEMPLATES,
			useValue: config.formTemplates ?? null
		},
		{
			provide: CORE_FORM_STORE,
			useClass: formStore
		}
	]);
}
export { BreakpointAffix, CORE_FORM_STORE, CORE_LIBRARY_CONFIGS, CORE_THEME, ClassType, FormlyBuilder as Core, FormlyBuilder, CoreFieldService, CoreFormService, CoreLibraryService, CreateFormDialogService, FormStoreRecoveryRequiredError, FormTitle, ImportDialogService, MarkdownDialogService, PanelService, PropertyChangeType, PropertyType, addNodeToHierarchy, buildHierarchyFromFlatForms, createArrayProperty, createBooleanProperty, createChipsProperty, createCustomValidationProperty, createDateProperty, createEmptyWorkspaceHierarchy, createExpressionsProperty, createGroupProperty, createInputProperty, createLibrary, createMarkdownProperty, createObjectProperty, createSelectProperty, createValidationMessagesProperty, createWrappersProperty, generateTypeOptionSchema, generateTypeOptionSchemaMap, getChildPath, getDefaultProperty, getDefaultPropertyFromValue, getDefaultPropertyValue, getDescendantNodeIds, getPropertySchema, isAncestorOf, modifyPropertyTarget, moveNodeInHierarchy, nativeFieldConfig, nativeFieldTypes, provideCore, provideCoreConfig, provideCoreTheme, provideFormStore, provideFormlyBuilder, provideLocalFormStore, recalculateNodePaths, removeNodeFromHierarchy, renameNodeInHierarchy, tailwindConfig, toggleFolderExpansion, trackByPropertyKey };

//# sourceMappingURL=ngx-formly-builder-ui.mjs.map