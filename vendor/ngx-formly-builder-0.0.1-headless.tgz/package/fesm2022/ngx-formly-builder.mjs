import * as i0 from "@angular/core";
import { DestroyRef, Inject, Injectable, InjectionToken, computed, inject, linkedSignal, makeEnvironmentProviders, signal } from "@angular/core";
import { BehaviorSubject, EMPTY, Observable, Subject, catchError, concatMap, debounceTime, defer, finalize, first, forkJoin, from, map, of, switchMap, takeUntil, tap, throwError, toArray } from "rxjs";
import { takeUntilDestroyed } from "@angular/core/rxjs-interop";
import { cloneDeep, get, isEmpty, isEqual, mergeWith, set, unset } from "lodash-es";
import { create } from "mutative";
import { v4 } from "uuid";
function isValidationRuleName(name) {
	return /^[A-Za-z][A-Za-z0-9_]*$/.test(name) && !(name in Object.prototype) && ![
		"validation",
		"required",
		"pattern",
		"min",
		"max",
		"minLength",
		"maxLength",
		"minlength",
		"maxlength",
		"email",
		"step",
		"multipleOf"
	].includes(name);
}
function isWorkspaceValidation(value) {
	if (!value || typeof value !== "object") return false;
	const rule = value;
	return typeof rule["id"] === "string" && !!rule["id"].trim() && typeof rule["name"] === "string" && isValidationRuleName(rule["name"]) && typeof rule["expression"] === "string" && !!rule["expression"].trim() && typeof rule["message"] === "string" && !!rule["message"].trim();
}
function isWorkspaceValidationList(value) {
	return Array.isArray(value) && value.every(isWorkspaceValidation) && new Set(value.map((rule) => rule.id)).size === value.length && new Set(value.map((rule) => rule.name)).size === value.length;
}
function createEmptyWorkspaceHierarchy(workspaceId) {
	return {
		workspaceId,
		rootNodeIds: [],
		nodeMap: {}
	};
}
function isAncestorOf(hierarchy, potentialAncestorId, targetNodeId) {
	if (!targetNodeId || !potentialAncestorId) return false;
	if (potentialAncestorId === targetNodeId) return true;
	const targetNode = hierarchy.nodeMap[targetNodeId];
	if (!targetNode) return false;
	return targetNode.idPath.includes(potentialAncestorId);
}
function getDescendantNodeIds(hierarchy, folderId) {
	const folder = hierarchy.nodeMap[folderId];
	if (!folder || folder.type !== "folder") return [];
	const result = [];
	const traverse = (currentFolder) => {
		for (const childId of currentFolder.childIds) {
			result.push(childId);
			const child = hierarchy.nodeMap[childId];
			if (child && child.type === "folder") traverse(child);
		}
	};
	traverse(folder);
	return result;
}
function recalculateNodePaths(nodeMap, nodeId, parentPath = []) {
	const node = nodeMap[nodeId];
	if (!node) return nodeMap;
	const updatedPath = [...parentPath, nodeId];
	const updatedNode = {
		...node,
		idPath: updatedPath
	};
	let updatedMap = {
		...nodeMap,
		[nodeId]: updatedNode
	};
	if (updatedNode.type === "folder") for (const childId of updatedNode.childIds) updatedMap = recalculateNodePaths(updatedMap, childId, updatedPath);
	return updatedMap;
}
function addNodeToHierarchy(hierarchy, node, targetIndex) {
	const { parentId } = node;
	const parent = parentId ? hierarchy.nodeMap[parentId] : null;
	if (parentId && (!parent || parent.type !== "folder")) throw new Error(`Parent folder with ID '${parentId}' does not exist.`);
	const parentPath = parent ? parent.idPath : [];
	const nodeWithPath = {
		...node,
		idPath: [...parentPath, node.id]
	};
	let updatedNodeMap = {
		...hierarchy.nodeMap,
		[node.id]: nodeWithPath
	};
	const updatedRootNodeIds = [...hierarchy.rootNodeIds];
	if (!parentId) {
		if (!updatedRootNodeIds.includes(node.id)) {
			if (typeof targetIndex === "number" && targetIndex >= 0) updatedRootNodeIds.splice(targetIndex, 0, node.id);
			else updatedRootNodeIds.push(node.id);
		}
	} else if (parent && parent.type === "folder") {
		const updatedChildIds = [...parent.childIds];
		if (!updatedChildIds.includes(node.id)) {
			if (typeof targetIndex === "number" && targetIndex >= 0) updatedChildIds.splice(targetIndex, 0, node.id);
			else updatedChildIds.push(node.id);
		}
		updatedNodeMap[parentId] = {
			...parent,
			childIds: updatedChildIds,
			isExpanded: true
		};
	}
	if (node.type === "folder" && node.childIds.length > 0) updatedNodeMap = recalculateNodePaths(updatedNodeMap, node.id, parentPath);
	return {
		...hierarchy,
		rootNodeIds: updatedRootNodeIds,
		nodeMap: updatedNodeMap
	};
}
function removeNodeFromHierarchy(hierarchy, nodeId) {
	const node = hierarchy.nodeMap[nodeId];
	if (!node) return {
		hierarchy,
		removedNodeIds: []
	};
	const allIdsToRemove = [nodeId, ...node.type === "folder" ? getDescendantNodeIds(hierarchy, nodeId) : []];
	const updatedNodeMap = { ...hierarchy.nodeMap };
	for (const id of allIdsToRemove) delete updatedNodeMap[id];
	let updatedRootNodeIds = [...hierarchy.rootNodeIds];
	if (!node.parentId) updatedRootNodeIds = updatedRootNodeIds.filter((id) => id !== nodeId);
	else {
		const parent = updatedNodeMap[node.parentId];
		if (parent && parent.type === "folder") updatedNodeMap[node.parentId] = {
			...parent,
			childIds: parent.childIds.filter((id) => id !== nodeId)
		};
	}
	return {
		hierarchy: {
			...hierarchy,
			rootNodeIds: updatedRootNodeIds,
			nodeMap: updatedNodeMap
		},
		removedNodeIds: allIdsToRemove
	};
}
function moveNodeInHierarchy(hierarchy, nodeId, newParentId, targetIndex) {
	const node = hierarchy.nodeMap[nodeId];
	if (!node) throw new Error(`Node with ID '${nodeId}' not found.`);
	if (newParentId === nodeId) throw new Error(`Cannot move node '${nodeId}' into itself.`);
	if (newParentId && isAncestorOf(hierarchy, nodeId, newParentId)) throw new Error(`Cannot move node '${nodeId}' into its descendant '${newParentId}' (cycle detected).`);
	const oldParentId = node.parentId;
	let updatedNodeMap = { ...hierarchy.nodeMap };
	let updatedRootNodeIds = [...hierarchy.rootNodeIds];
	if (!oldParentId) updatedRootNodeIds = updatedRootNodeIds.filter((id) => id !== nodeId);
	else {
		const oldParent = updatedNodeMap[oldParentId];
		if (oldParent && oldParent.type === "folder") updatedNodeMap[oldParentId] = {
			...oldParent,
			childIds: oldParent.childIds.filter((id) => id !== nodeId)
		};
	}
	const newParent = newParentId ? updatedNodeMap[newParentId] : null;
	if (newParentId && (!newParent || newParent.type !== "folder")) throw new Error(`Target parent folder with ID '${newParentId}' does not exist.`);
	const parentPath = newParent ? newParent.idPath : [];
	if (!newParentId) {
		if (typeof targetIndex === "number" && targetIndex >= 0) updatedRootNodeIds.splice(targetIndex, 0, nodeId);
		else updatedRootNodeIds.push(nodeId);
	} else if (newParent && newParent.type === "folder") {
		const updatedChildIds = [...newParent.childIds];
		if (typeof targetIndex === "number" && targetIndex >= 0) updatedChildIds.splice(targetIndex, 0, nodeId);
		else updatedChildIds.push(nodeId);
		updatedNodeMap[newParentId] = {
			...newParent,
			childIds: updatedChildIds
		};
	}
	updatedNodeMap[nodeId] = {
		...node,
		parentId: newParentId,
		idPath: [...parentPath, nodeId]
	};
	updatedNodeMap = recalculateNodePaths(updatedNodeMap, nodeId, parentPath);
	return {
		...hierarchy,
		rootNodeIds: updatedRootNodeIds,
		nodeMap: updatedNodeMap
	};
}
function renameNodeInHierarchy(hierarchy, nodeId, newName) {
	const node = hierarchy.nodeMap[nodeId];
	if (!node) return hierarchy;
	return {
		...hierarchy,
		nodeMap: {
			...hierarchy.nodeMap,
			[nodeId]: {
				...node,
				name: newName,
				updatedAt: (/* @__PURE__ */ new Date()).toISOString()
			}
		}
	};
}
function toggleFolderExpansion(hierarchy, folderId, isExpanded) {
	const folder = hierarchy.nodeMap[folderId];
	if (!folder || folder.type !== "folder") return hierarchy;
	const nextExpandedState = isExpanded !== void 0 ? isExpanded : !folder.isExpanded;
	return {
		...hierarchy,
		nodeMap: {
			...hierarchy.nodeMap,
			[folderId]: {
				...folder,
				isExpanded: nextExpandedState
			}
		}
	};
}
function buildHierarchyFromFlatForms(workspaceId, forms) {
	const nodeMap = {};
	const rootNodeIds = [];
	for (const form of forms) {
		const parentId = form.parentId || null;
		const formNode = {
			id: form.id,
			name: form.name,
			type: "form",
			libraryId: form.libraryId,
			fieldCount: form.fieldCount,
			parentId,
			idPath: parentId ? [parentId, form.id] : [form.id]
		};
		nodeMap[form.id] = formNode;
		if (!parentId) rootNodeIds.push(form.id);
	}
	return {
		workspaceId,
		rootNodeIds,
		nodeMap
	};
}
var FormStoreRecoveryRequiredError = class extends Error {
	issues;
	constructor(issues) {
		super("Corrupted local storage must be backed up or reset before it can be changed.");
		this.issues = issues;
		this.name = "FormStoreRecoveryRequiredError";
	}
};
const CORE_FORM_STORE = new InjectionToken("FormStoreService");
var LocalFormStoreService = class LocalFormStoreService {
	storageKey = "formly-studio-forms";
	hierarchyStorageKey = "formly-studio-hierarchy";
	validationsStorageKey = "formly-studio-validations";
	recoveryIssues = /* @__PURE__ */ new Map();
	addForm$(editorType, newForm) {
		const formMap = this.getFormMap(editorType);
		let hierarchy = this.getHierarchySync(editorType);
		const recoveryError = this.getRecoveryError(editorType);
		if (recoveryError) return throwError(() => recoveryError);
		formMap[newForm.id] = newForm;
		this.storeFormMap(editorType, formMap);
		const parentId = newForm.parentId ?? null;
		const formNode = {
			id: newForm.id,
			name: newForm.name,
			type: "form",
			libraryId: newForm.libraryId,
			fieldCount: newForm.fieldCount ?? newForm.fields.length,
			parentId,
			idPath: parentId && hierarchy.nodeMap[parentId] ? [...hierarchy.nodeMap[parentId].idPath, newForm.id] : [newForm.id]
		};
		hierarchy = addNodeToHierarchy(hierarchy, formNode);
		this.storeHierarchy(editorType, hierarchy);
		return of(void 0);
	}
	updateForm$(editorType, newForm) {
		const formMap = this.getFormMap(editorType);
		let hierarchy = this.getHierarchySync(editorType);
		const recoveryError = this.getRecoveryError(editorType);
		if (recoveryError) return throwError(() => recoveryError);
		formMap[newForm.id] = newForm;
		this.storeFormMap(editorType, formMap);
		if (hierarchy.nodeMap[newForm.id]) {
			hierarchy = renameNodeInHierarchy(hierarchy, newForm.id, newForm.name);
			const node = hierarchy.nodeMap[newForm.id];
			if (node && node.type === "form") {
				node.fieldCount = newForm.fieldCount ?? newForm.fields.length;
				node.libraryId = newForm.libraryId;
			}
			this.storeHierarchy(editorType, hierarchy);
		}
		return of(void 0);
	}
	removeForm$(editorType, formId) {
		const formMap = this.getFormMap(editorType);
		const hierarchy = this.getHierarchySync(editorType);
		const recoveryError = this.getRecoveryError(editorType);
		if (recoveryError) return throwError(() => recoveryError);
		delete formMap[formId];
		this.storeFormMap(editorType, formMap);
		if (hierarchy.nodeMap[formId]) {
			const res = removeNodeFromHierarchy(hierarchy, formId);
			this.storeHierarchy(editorType, res.hierarchy);
		}
		return of(void 0);
	}
	getFormList$(editorType) {
		return of(Object.values(this.getFormMap(editorType)).map((f) => ({
			id: f.id,
			libraryId: f.libraryId,
			fieldCount: f.fieldCount ?? f.fields.length,
			name: f.name,
			parentId: f.parentId
		})));
	}
	getForm$(editorType, formId) {
		return of(this.getFormMap(editorType)[formId]);
	}
	getHierarchy$(editorType) {
		return of(this.getHierarchySync(editorType));
	}
	saveHierarchy$(editorType, hierarchy) {
		this.getFormMap(editorType);
		this.getHierarchySync(editorType);
		const recoveryError = this.getRecoveryError(editorType);
		if (recoveryError) return throwError(() => recoveryError);
		this.storeHierarchy(editorType, hierarchy);
		return of(void 0);
	}
	getRecoveryIssues$(editorType) {
		this.getFormMap(editorType);
		this.getHierarchySync(editorType);
		this.readValidations(editorType);
		return this.getRecoveryIssuesSubject(editorType).asObservable();
	}
	getValidations$(editorType) {
		const validations = this.readValidations(editorType);
		const error = this.getRecoveryError(editorType, "validations");
		return error ? throwError(() => error) : of(validations);
	}
	saveValidations$(editorType, validations) {
		this.readValidations(editorType);
		const error = this.getRecoveryError(editorType, "validations");
		if (error) return throwError(() => error);
		if (!isWorkspaceValidationList(validations)) return throwError(() => /* @__PURE__ */ new Error("Validation names must be valid and unique."));
		localStorage.setItem(`${this.validationsStorageKey}-${editorType}`, JSON.stringify(validations));
		return of(void 0);
	}
	readValidations(editorType) {
		const raw = localStorage.getItem(`${this.validationsStorageKey}-${editorType}`);
		if (raw === null) {
			this.clearRecoveryIssue(editorType, "validations");
			return [];
		}
		try {
			const value = JSON.parse(raw);
			if (isWorkspaceValidationList(value)) {
				this.clearRecoveryIssue(editorType, "validations");
				return value;
			}
			this.setRecoveryIssue(editorType, "validations", "invalid-shape", raw);
		} catch {
			this.setRecoveryIssue(editorType, "validations", "invalid-json", raw);
		}
		return [];
	}
	resetCorruptedStorage$(editorType, kind) {
		this.getFormMap(editorType);
		this.getHierarchySync(editorType);
		this.readValidations(editorType);
		const subject = this.getRecoveryIssuesSubject(editorType);
		const issues = subject.value.filter((issue) => !kind || issue.kind === kind);
		if (issues.some((issue) => issue.kind === "forms")) {
			localStorage.removeItem(`${this.storageKey}-${editorType}`);
			localStorage.removeItem(`${this.hierarchyStorageKey}-${editorType}`);
		} else if (issues.some((issue) => issue.kind === "hierarchy")) localStorage.removeItem(`${this.hierarchyStorageKey}-${editorType}`);
		if (issues.some((issue) => issue.kind === "validations")) localStorage.removeItem(`${this.validationsStorageKey}-${editorType}`);
		subject.next(subject.value.filter((issue) => !issues.includes(issue)));
		return of(void 0);
	}
	getHierarchySync(editorType) {
		const hierarchyStorageKey = `${this.hierarchyStorageKey}-${editorType}`;
		const raw = localStorage.getItem(hierarchyStorageKey);
		if (raw) try {
			const hierarchy = JSON.parse(raw);
			if (this.isWorkspaceHierarchy(hierarchy)) {
				this.clearRecoveryIssue(editorType, "hierarchy");
				return hierarchy;
			}
			this.setRecoveryIssue(editorType, "hierarchy", "invalid-shape", raw);
		} catch {
			this.setRecoveryIssue(editorType, "hierarchy", "invalid-json", raw);
		}
		else this.clearRecoveryIssue(editorType, "hierarchy");
		const hierarchy = buildHierarchyFromFlatForms(editorType, Object.values(this.getFormMap(editorType)).map((f) => ({
			id: f.id,
			libraryId: f.libraryId,
			fieldCount: f.fieldCount ?? f.fields.length,
			name: f.name,
			parentId: f.parentId
		})));
		if (!this.getRecoveryError(editorType)) this.storeHierarchy(editorType, hierarchy);
		return hierarchy;
	}
	storeHierarchy(editorType, hierarchy) {
		const hierarchyStorageKey = `${this.hierarchyStorageKey}-${editorType}`;
		localStorage.setItem(hierarchyStorageKey, JSON.stringify(hierarchy));
	}
	getFormMap(editorType) {
		const editorStorageKey = `${this.storageKey}-${editorType}`;
		const raw = localStorage.getItem(editorStorageKey);
		if (!raw) {
			this.clearRecoveryIssue(editorType, "forms");
			return {};
		}
		try {
			const formMap = JSON.parse(raw);
			if (this.isFormMap(formMap)) {
				this.clearRecoveryIssue(editorType, "forms");
				return formMap;
			}
			this.setRecoveryIssue(editorType, "forms", "invalid-shape", raw);
			return {};
		} catch {
			this.setRecoveryIssue(editorType, "forms", "invalid-json", raw);
			return {};
		}
	}
	storeFormMap(editorType, formMap) {
		const editorStorageKey = `${this.storageKey}-${editorType}`;
		localStorage.setItem(editorStorageKey, JSON.stringify(formMap));
	}
	getRecoveryIssuesSubject(editorType) {
		let subject = this.recoveryIssues.get(editorType);
		if (!subject) {
			subject = new BehaviorSubject([]);
			this.recoveryIssues.set(editorType, subject);
		}
		return subject;
	}
	getRecoveryError(editorType, kind) {
		const issues = this.getRecoveryIssuesSubject(editorType).value.filter((issue) => kind ? issue.kind === kind : issue.kind !== "validations");
		return issues.length ? new FormStoreRecoveryRequiredError(issues) : void 0;
	}
	setRecoveryIssue(editorType, kind, reason, rawValue) {
		const subject = this.getRecoveryIssuesSubject(editorType);
		const issue = {
			editorType,
			kind,
			reason,
			rawValue,
			storageKey: kind === "forms" ? `${this.storageKey}-${editorType}` : kind === "validations" ? `${this.validationsStorageKey}-${editorType}` : `${this.hierarchyStorageKey}-${editorType}`
		};
		if (kind === "forms") {
			const storageKey = `${this.hierarchyStorageKey}-${editorType}`;
			const rawValue = localStorage.getItem(storageKey);
			if (rawValue !== null) issue.relatedEntries = [{
				storageKey,
				rawValue
			}];
		}
		subject.next([...subject.value.filter((value) => value.kind !== kind), issue]);
	}
	clearRecoveryIssue(editorType, kind) {
		const subject = this.getRecoveryIssuesSubject(editorType);
		const issues = subject.value.filter((issue) => issue.kind !== kind);
		if (issues.length !== subject.value.length) subject.next(issues);
	}
	isFormMap(value) {
		return this.isRecord(value) && Object.values(value).every((form) => this.isRecord(form) && (form["id"] === void 0 || typeof form["id"] === "string") && (form["libraryId"] === void 0 || typeof form["libraryId"] === "string") && typeof form["name"] === "string" && Array.isArray(form["fields"]) && this.isRecord(form["model"]));
	}
	isWorkspaceHierarchy(value) {
		if (!this.isRecord(value) || typeof value["workspaceId"] !== "string" || !Array.isArray(value["rootNodeIds"]) || !value["rootNodeIds"].every((id) => typeof id === "string") || !this.isRecord(value["nodeMap"])) return false;
		const nodeMap = value["nodeMap"];
		return value["rootNodeIds"].every((id) => id in nodeMap) && Object.entries(nodeMap).every(([id, node]) => this.isWorkspaceNode(node) && node.id === id);
	}
	isWorkspaceNode(value) {
		if (!this.isRecord(value) || typeof value["id"] !== "string" || typeof value["name"] !== "string" || value["parentId"] !== null && typeof value["parentId"] !== "string" || !Array.isArray(value["idPath"]) || !value["idPath"].every((id) => typeof id === "string")) return false;
		return value["type"] === "folder" ? Array.isArray(value["childIds"]) && value["childIds"].every((id) => typeof id === "string") : value["type"] === "form" && typeof value["libraryId"] === "string";
	}
	isRecord(value) {
		return typeof value === "object" && value !== null && !Array.isArray(value);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LocalFormStoreService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: LocalFormStoreService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: LocalFormStoreService,
	decorators: [{ type: Injectable }]
});
const BUILDER_ENGINE_CONFIG = new InjectionToken("BuilderEngineConfig");
var PropertyChangeType;
(function(PropertyChangeType) {
	PropertyChangeType[PropertyChangeType["KEY"] = 0] = "KEY";
	PropertyChangeType[PropertyChangeType["VALUE"] = 1] = "VALUE";
	PropertyChangeType[PropertyChangeType["CLEAR"] = 2] = "CLEAR";
})(PropertyChangeType || (PropertyChangeType = {}));
const modifyTargetKey = (target, { path, newPath }) => {
	if (!newPath?.length) throw new Error("Unable to modify target key without newPath");
	const oldKey = path[path.length - 1];
	const newKey = newPath[path.length - 1];
	const modifyKey = (p) => Object.fromEntries(Object.entries(p).map(([k, v]) => [k === oldKey ? newKey : k, v]));
	if (newPath.length > 1) {
		const parentPath = newPath.slice(0, -1);
		const newParent = modifyKey(get(target, parentPath));
		return create(target, (draft) => {
			set(draft, parentPath, newParent);
		});
	} else return modifyKey(target);
};
const modifyTargetValue = (target, { path, value }) => create(target, (draft) => {
	set(draft, path, value);
});
const modifyTargetClear = (target, { path }) => create(target, (draft) => {
	unset(draft, path);
});
const modifyPropertyTarget = (target, { type, ...change }) => {
	switch (type) {
		case PropertyChangeType.KEY: return modifyTargetKey(target, change);
		case PropertyChangeType.VALUE: return modifyTargetValue(target, change);
		case PropertyChangeType.CLEAR: return modifyTargetClear(target, change);
	}
};
const ROW_CLASSES = "formly-builder-row flex flex-col gap-4 md:flex-row [&>formly-field]:min-w-0 [&>formly-field]:flex-1";
function isLayoutRow(field) {
	return !!(field && field.key == null && field.type === "formly-group" && field.fieldGroupClassName?.split(/\s+/).includes("formly-builder-row"));
}
function parentId(field) {
	return field._info.idPath.at(-2);
}
function childIds(form, id) {
	return id ? form.fieldMap[id]._info.childIds : form.rootFieldIds;
}
function updateFieldPath(form, fieldId, path) {
	const field = form.fieldMap[fieldId];
	field._info.idPath = [...path, fieldId];
	field._info.childIds.forEach((id) => updateFieldPath(form, id, field._info.idPath));
}
function removeEmptyRows(form) {
	for (const field of Object.values(form.fieldMap)) {
		if (!isLayoutRow(field) || field._info.childIds.length) continue;
		const siblings = childIds(form, parentId(field));
		siblings.splice(siblings.indexOf(field._info.id), 1);
		delete form.fieldMap[field._info.id];
		removeEmptyRows(form);
		return;
	}
}
function canDropField(form, sourceId, targetId, position) {
	const target = form.fieldMap[targetId];
	const source = sourceId ? form.fieldMap[sourceId] : void 0;
	if (!target || sourceId && !source || target._info.idPath.includes(sourceId ?? "")) return false;
	if (position === "center") {
		if (!target._info.isParent || target._info.isFieldArray && target._info.childIds.length) return false;
	} else if (form.fieldMap[parentId(target) ?? ""]?._info.isFieldArray) return false;
	if (!source) return true;
	const modelScope = (path) => path.filter((id) => {
		const field = form.fieldMap[id];
		return field.key != null || field._info.isFieldArray;
	});
	const sourceScope = modelScope(source._info.idPath.slice(0, -1));
	const targetScope = modelScope(position === "center" ? target._info.idPath : target._info.idPath.slice(0, -1));
	return sourceScope.length === targetScope.length && sourceScope.every((id, index) => id === targetScope[index]);
}
function placeField(form, sourceId, targetId, position, rowId) {
	const source = form.fieldMap[sourceId];
	let target = form.fieldMap[targetId];
	const sourceSiblings = childIds(form, parentId(source));
	const sourceIndex = sourceSiblings.indexOf(sourceId);
	if (sourceIndex !== -1) sourceSiblings.splice(sourceIndex, 1);
	let destinationId = parentId(target);
	if (position === "center") {
		destinationId = targetId;
		childIds(form, destinationId).push(sourceId);
	} else if (position === "left" || position === "right") {
		if (isLayoutRow(target)) destinationId = targetId;
		else if (!isLayoutRow(form.fieldMap[destinationId ?? ""])) {
			const siblings = childIds(form, destinationId);
			siblings.splice(siblings.indexOf(targetId), 1, rowId);
			form.fieldMap[rowId] = {
				type: "formly-group",
				className: "col-span-full min-w-0",
				fieldGroupClassName: ROW_CLASSES,
				_info: {
					id: rowId,
					name: "Row",
					formId: form.id,
					idPath: [...target._info.idPath.slice(0, -1), rowId],
					childIds: [targetId],
					isParent: true
				}
			};
			updateFieldPath(form, targetId, form.fieldMap[rowId]._info.idPath);
			destinationId = rowId;
		}
		const siblings = childIds(form, destinationId);
		const index = isLayoutRow(target) ? position === "left" ? 0 : siblings.length : siblings.indexOf(targetId) + (position === "right" ? 1 : 0);
		siblings.splice(index, 0, sourceId);
	} else {
		if (isLayoutRow(form.fieldMap[destinationId ?? ""])) {
			target = form.fieldMap[destinationId];
			destinationId = parentId(target);
		}
		const siblings = childIds(form, destinationId);
		siblings.splice(siblings.indexOf(target._info.id) + (position === "bottom" ? 1 : 0), 0, sourceId);
	}
	updateFieldPath(form, sourceId, destinationId ? form.fieldMap[destinationId]._info.idPath : []);
	removeEmptyRows(form);
}
const defaultTypeOption = {
	name: "",
	displayName: "Unknown Field",
	disableKeyGeneration: true,
	defaultConfig: {}
};
function generateFormId() {
	return `form-${v4()}`;
}
function generateFieldId(type) {
	return `${type || "generic"}-${v4()}`;
}
function generateFieldKey(prefix) {
	return `${prefix ?? "field"}_${Math.random().toString(36).substring(2, 8)}`;
}
function clearFieldModelValue(fieldId, fieldMap, model) {
	const field = fieldMap[fieldId];
	if (!field) return;
	const fieldIds = field._info.idPath;
	const clearValue = (container, pathIndex) => {
		const currentField = fieldMap[fieldIds[pathIndex]];
		if (!currentField) return;
		const key = currentField.key;
		const isTarget = pathIndex === fieldIds.length - 1;
		if (!(key !== void 0 && key !== null)) {
			if (isTarget) currentField._info.childIds.forEach((id) => clearFieldModelValue(id, fieldMap, model));
			else if (currentField._info.isFieldArray && Array.isArray(container)) container.forEach((item) => clearValue(item, pathIndex + 1));
			else clearValue(container, pathIndex + 1);
			return;
		}
		if (isTarget) {
			if (container !== null && typeof container === "object") unset(container, key);
			return;
		}
		const value = get(container, key);
		if (value === void 0 && currentField._info.isParent && !currentField._info.isFieldArray) {
			clearValue(container, pathIndex + 1);
			return;
		}
		if (currentField._info.isFieldArray) {
			if (Array.isArray(value)) value.forEach((item) => clearValue(item, pathIndex + 1));
			return;
		}
		clearValue(value, pathIndex + 1);
	};
	clearValue(model, 0);
}
function convertField(sourceField, fieldId, formId, parentIdPath = [], fieldMap, typeOptions, getDefaultField) {
	if (!sourceField.type && sourceField.fieldGroup) sourceField = {
		type: "formly-group",
		...sourceField
	};
	const typeOption = typeOptions.find((option) => option.name === sourceField.type) ?? defaultTypeOption;
	const baseField = getDefaultField(sourceField.type);
	mergeWith(baseField, sourceField, (_defaultValue, sourceValue) => {
		if (Array.isArray(sourceValue)) return structuredClone(sourceValue);
	});
	const idPath = [...parentIdPath, fieldId];
	const layoutRow = isLayoutRow(sourceField);
	const isParent = layoutRow || typeOption.isParent;
	const isFieldArray = typeOption.isFieldArray;
	let childIds = [];
	if (isFieldArray && baseField.fieldArray) {
		const fieldArray = baseField.fieldArray;
		childIds = [convertField(fieldArray, generateFieldId(fieldArray.type), formId, idPath, fieldMap, typeOptions, getDefaultField)._info.id];
	} else if (Array.isArray(baseField.fieldGroup)) childIds = baseField.fieldGroup.map((f) => convertField(f, generateFieldId(f.type), formId, idPath, fieldMap, typeOptions, getDefaultField)).map((child) => child._info.id);
	const editorField = {
		_info: {
			name: layoutRow ? "Row" : typeOption.displayName,
			id: fieldId,
			formId,
			idPath,
			childIds,
			isParent,
			isFieldArray
		},
		key: baseField.key || (layoutRow || typeOption.disableKeyGeneration ? void 0 : generateFieldKey(typeOption.keyGenerationPrefix)),
		...baseField,
		fieldGroup: void 0,
		fieldArray: void 0
	};
	fieldMap[fieldId] = editorField;
	return editorField;
}
var BuilderEngineService = class BuilderEngineService {
	editorConfig;
	formStoreService;
	destroyRef = inject(DestroyRef);
	pendingFormId;
	cancelLoad$ = new Subject();
	loadVersion = 0;
	activeVersion = 0;
	queuedSaves = /* @__PURE__ */ new Set();
	operations$ = new Subject();
	loadingFormIdSrc = signal(null, ...ngDevMode ? [{ debugName: "loadingFormIdSrc" }] : /* istanbul ignore next */ []);
	formLoadErrorSrc = signal(null, ...ngDevMode ? [{ debugName: "formLoadErrorSrc" }] : /* istanbul ignore next */ []);
	persistenceErrorSrc = signal(null, ...ngDevMode ? [{ debugName: "persistenceErrorSrc" }] : /* istanbul ignore next */ []);
	loadingFormId = this.loadingFormIdSrc.asReadonly();
	formLoadError = this.formLoadErrorSrc.asReadonly();
	persistenceError = this.persistenceErrorSrc.asReadonly();
	autosaveTrigger$ = new Subject();
	autosaveEnabled;
	autosaveDelay;
	saveActiveFormTrigger$ = new Subject();
	saveStatusSrc = signal("saved", ...ngDevMode ? [{ debugName: "saveStatusSrc" }] : /* istanbul ignore next */ []);
	saveStatus = this.saveStatusSrc.asReadonly();
	storageRecoveryIssuesSrc = signal([], ...ngDevMode ? [{ debugName: "storageRecoveryIssuesSrc" }] : /* istanbul ignore next */ []);
	storageRecoveryIssues = this.storageRecoveryIssuesSrc.asReadonly();
	hasStorageRecoveryIssues = computed(() => this.storageRecoveryIssues().length > 0, ...ngDevMode ? [{ debugName: "hasStorageRecoveryIssues" }] : /* istanbul ignore next */ []);
	hasFormStorageRecoveryIssue = computed(() => this.storageRecoveryIssues().some((issue) => issue.kind === "forms"), ...ngDevMode ? [{ debugName: "hasFormStorageRecoveryIssue" }] : /* istanbul ignore next */ []);
	validationStorageAvailable;
	validationsSrc = signal([], ...ngDevMode ? [{ debugName: "validationsSrc" }] : /* istanbul ignore next */ []);
	validations = this.validationsSrc.asReadonly();
	validationsLoadingSrc = signal(false, ...ngDevMode ? [{ debugName: "validationsLoadingSrc" }] : /* istanbul ignore next */ []);
	validationsLoading = this.validationsLoadingSrc.asReadonly();
	validationsLoadErrorSrc = signal(null, ...ngDevMode ? [{ debugName: "validationsLoadErrorSrc" }] : /* istanbul ignore next */ []);
	validationsLoadError = this.validationsLoadErrorSrc.asReadonly();
	validationRecoveryIssues = computed(() => this.storageRecoveryIssues().filter((issue) => issue.kind === "validations"), ...ngDevMode ? [{ debugName: "validationRecoveryIssues" }] : /* istanbul ignore next */ []);
	formListSrc = signal([], ...ngDevMode ? [{ debugName: "formListSrc" }] : /* istanbul ignore next */ []);
	hierarchySrc = signal(createEmptyWorkspaceHierarchy(""), ...ngDevMode ? [{ debugName: "hierarchySrc" }] : /* istanbul ignore next */ []);
	activeFieldIdSrc = signal(null, ...ngDevMode ? [{ debugName: "activeFieldIdSrc" }] : /* istanbul ignore next */ []);
	activeFormSrc = signal(null, ...ngDevMode ? [{ debugName: "activeFormSrc" }] : /* istanbul ignore next */ []);
	activeFieldIdByFormSrc = signal({}, ...ngDevMode ? [{ debugName: "activeFieldIdByFormSrc" }] : /* istanbul ignore next */ []);
	formList = this.formListSrc.asReadonly();
	hierarchy = this.hierarchySrc.asReadonly();
	hierarchyRootNodeIds = computed(() => this.hierarchy().rootNodeIds, ...ngDevMode ? [{ debugName: "hierarchyRootNodeIds" }] : /* istanbul ignore next */ []);
	hierarchyNodeMap = computed(() => this.hierarchy().nodeMap, ...ngDevMode ? [{ debugName: "hierarchyNodeMap" }] : /* istanbul ignore next */ []);
	activeFieldId = this.activeFieldIdSrc.asReadonly();
	activeForm = this.activeFormSrc.asReadonly();
	activeFormId = computed(() => this.activeForm()?.id, ...ngDevMode ? [{ debugName: "activeFormId" }] : /* istanbul ignore next */ []);
	activeFormName = computed(() => this.activeForm()?.name, ...ngDevMode ? [{ debugName: "activeFormName" }] : /* istanbul ignore next */ []);
	activeRootFieldIds = computed(() => this.activeForm()?.rootFieldIds ?? [], ...ngDevMode ? [{ debugName: "activeRootFieldIds" }] : /* istanbul ignore next */ []);
	activeFieldMap = computed(() => this.activeForm()?.fieldMap ?? {}, ...ngDevMode ? [{ debugName: "activeFieldMap" }] : /* istanbul ignore next */ []);
	activeFieldCount = computed(() => Object.keys(this.activeFieldMap()).length, ...ngDevMode ? [{ debugName: "activeFieldCount" }] : /* istanbul ignore next */ []);
	activeField = computed(() => {
		const activeFieldId = this.activeFieldId();
		if (!activeFieldId) return null;
		return this.activeFieldMap()[activeFieldId] || null;
	}, ...ngDevMode ? [{ debugName: "activeField" }] : /* istanbul ignore next */ []);
	activeFormFieldsRaw = computed(() => this.activeRootFieldIds().map((id) => this.buildField(id, this.activeFieldMap())), ...ngDevMode ? [{ debugName: "activeFormFieldsRaw" }] : /* istanbul ignore next */ []);
	activeModel = computed(() => this.activeForm()?.model || {}, ...ngDevMode ? [{ debugName: "activeModel" }] : /* istanbul ignore next */ []);
	activeLibraryId = computed(() => this.activeForm()?.libraryId ?? null, ...ngDevMode ? [{ debugName: "activeLibraryId" }] : /* istanbul ignore next */ []);
	formSelected$ = new Subject();
	activeFormFields = computed(() => structuredClone(this.activeFormFieldsRaw()), ...ngDevMode ? [{ debugName: "activeFormFields" }] : /* istanbul ignore next */ []);
	activePreviewFormFields = computed(() => {
		const clonedFields = structuredClone(this.activeFormFieldsRaw());
		clonedFields.forEach((f) => this.cleanField(f));
		return clonedFields;
	}, ...ngDevMode ? [{ debugName: "activePreviewFormFields" }] : /* istanbul ignore next */ []);
	activeFormFieldsJSON = computed(() => JSON.stringify(this.activePreviewFormFields(), null, 2), ...ngDevMode ? [{ debugName: "activeFormFieldsJSON" }] : /* istanbul ignore next */ []);
	constructor(config, store) {
		this.editorConfig = config;
		this.formStoreService = store;
		this.validationStorageAvailable = !!(store.getValidations$ && store.saveValidations$);
		this.autosaveEnabled = config.autoSave ?? true;
		this.autosaveDelay = config.autoSaveDelay ?? 3e3;
		this.hierarchySrc.set(createEmptyWorkspaceHierarchy(config.editorType));
		this.operations$.pipe(concatMap((operation) => operation()), takeUntilDestroyed(this.destroyRef)).subscribe();
		this.enqueue$(() => this.refreshWorkspace$()).subscribe({ error: (error) => this.handlePersistenceError("load workspace", error) });
		defer(() => this.formStoreService.getRecoveryIssues$?.(this.editorConfig.editorType) ?? EMPTY).pipe(takeUntilDestroyed(this.destroyRef)).subscribe({
			next: (issues) => this.storageRecoveryIssuesSrc.set(issues),
			error: (error) => this.handlePersistenceError("load recovery state", error)
		});
		this.loadValidations();
		if (this.autosaveEnabled) this.autosaveTrigger$.pipe(debounceTime(this.autosaveDelay), takeUntilDestroyed(this.destroyRef)).subscribe((formId) => {
			if (formId && formId === this.activeFormId() && this.saveStatus() === "dirty") this.saveActiveForm();
		});
		this.saveActiveFormTrigger$.pipe(takeUntilDestroyed(this.destroyRef)).subscribe(() => this.requestSave());
	}
	enqueue$(operation) {
		return new Observable((subscriber) => {
			if (this.destroyRef.destroyed) {
				subscriber.complete();
				return;
			}
			this.operations$.next(() => subscriber.closed ? EMPTY : defer(operation).pipe(tap({
				next: (value) => subscriber.next(value),
				error: (error) => subscriber.error(error),
				complete: () => subscriber.complete()
			}), catchError(() => EMPTY)));
		}).pipe(takeUntilDestroyed(this.destroyRef));
	}
	snapshot$(read) {
		return defer(read).pipe(first(), takeUntilDestroyed(this.destroyRef));
	}
	refreshWorkspace$() {
		return forkJoin({
			forms: this.snapshot$(() => this.formStoreService.getFormList$(this.editorConfig.editorType)),
			hierarchy: this.snapshot$(() => this.formStoreService.getHierarchy$(this.editorConfig.editorType))
		}).pipe(tap(({ forms, hierarchy }) => {
			if (!this.hasFormStorageRecoveryIssue()) this.formListSrc.set(forms);
			if (!this.storageRecoveryIssues().some((issue) => issue.kind === "hierarchy")) this.hierarchySrc.set(hierarchy);
		}), map(() => void 0));
	}
	loadValidations() {
		if (!this.validationStorageAvailable) return;
		this.validationsLoadingSrc.set(true);
		this.validationsLoadErrorSrc.set(null);
		this.enqueue$(() => this.readValidations$()).pipe(finalize(() => this.validationsLoadingSrc.set(false))).subscribe({
			next: (rules) => this.validationsSrc.set(rules),
			error: () => this.validationsLoadErrorSrc.set("Saved validations could not be loaded. Try again or recover the affected data.")
		});
	}
	readValidations$() {
		return this.snapshot$(() => {
			if (!this.validationStorageAvailable) throw new Error("Validation storage is unavailable.");
			return this.formStoreService.getValidations$(this.editorConfig.editorType);
		}).pipe(map((rules) => {
			if (!isWorkspaceValidationList(rules)) throw new Error("Invalid validation catalog.");
			return rules.map((rule) => ({ ...rule }));
		}));
	}
	saveValidation$(draft, id) {
		const rule = {
			id: id ?? v4(),
			name: draft.name.trim(),
			expression: draft.expression.trim(),
			message: draft.message.trim()
		};
		return this.mutateValidations$((rules) => {
			if (id && !rules.some((entry) => entry.id === id)) throw new Error("This validation no longer exists.");
			return id ? rules.map((entry) => entry.id === id ? rule : entry) : [...rules, rule];
		});
	}
	deleteValidation$(id) {
		return this.mutateValidations$((rules) => rules.filter((rule) => rule.id !== id));
	}
	mutateValidations$(change) {
		return this.enqueue$(() => this.readValidations$().pipe(map(change), switchMap((rules) => {
			if (!isWorkspaceValidationList(rules)) throw new Error("Validation names must be valid and unique.");
			return this.snapshot$(() => this.formStoreService.saveValidations$(this.editorConfig.editorType, rules)).pipe(tap(() => {
				this.validationsSrc.set(rules);
				this.validationsLoadErrorSrc.set(null);
			}));
		})));
	}
	resetValidations$() {
		return this.enqueue$(() => this.snapshot$(() => {
			const reset = this.formStoreService.resetCorruptedStorage$;
			if (!reset) throw new Error("Validation recovery is unavailable.");
			return reset.call(this.formStoreService, this.editorConfig.editorType, "validations");
		}).pipe(switchMap(() => this.readValidations$()), tap((rules) => {
			this.validationsSrc.set(rules);
			this.validationsLoadErrorSrc.set(null);
		}), map(() => void 0)));
	}
	runMutation(action, operation, recovery = false) {
		this.enqueue$(() => {
			if (!recovery && this.isStorageMutationBlocked()) return EMPTY;
			this.persistenceErrorSrc.set(null);
			return defer(operation).pipe(catchError((error) => {
				this.handlePersistenceError(action, error);
				return of(void 0);
			}), switchMap(() => this.refreshWorkspace$()));
		}).subscribe({ error: (error) => this.handlePersistenceError(action, error) });
	}
	requestSave() {
		const formId = this.activeFormId();
		const version = this.activeVersion;
		if (!formId || this.queuedSaves.has(version) || this.isStorageMutationBlocked()) return;
		this.queuedSaves.add(version);
		this.saveStatusSrc.set("saving");
		this.enqueue$(() => {
			const form = this.activeForm();
			if (!form || version !== this.activeVersion || this.isStorageMutationBlocked()) return EMPTY;
			this.persistenceErrorSrc.set(null);
			return this.snapshot$(() => this.formStoreService.updateForm$(this.editorConfig.editorType, this.convertToRawForm(form))).pipe(switchMap(() => this.refreshWorkspace$()), tap(() => {
				if (version === this.activeVersion) this.saveStatusSrc.set(this.activeForm() === form ? "saved" : "dirty");
			}));
		}).subscribe({
			error: (error) => {
				this.queuedSaves.delete(version);
				if (version === this.activeVersion) {
					this.pendingFormId = void 0;
					this.handlePersistenceError("save form", error);
				} else this.persistenceErrorSrc.set({
					action: "save form",
					cause: error
				});
			},
			complete: () => {
				this.queuedSaves.delete(version);
				if (this.destroyRef.destroyed || version !== this.activeVersion) return;
				if (this.saveStatus() === "dirty") this.requestSave();
				else if (this.pendingFormId) {
					const target = this.pendingFormId;
					this.pendingFormId = void 0;
					this.setActiveForm(target);
				}
			}
		});
	}
	markFormDirty() {
		if (this.loadingFormId()) this.cancelLoad();
		if (this.saveStatus() !== "error") {
			this.saveStatusSrc.set(this.queuedSaves.has(this.activeVersion) ? "saving" : "dirty");
			if (this.autosaveEnabled) this.autosaveTrigger$.next(this.activeFormId() ?? null);
		}
	}
	refreshHierarchy() {
		this.enqueue$(() => this.refreshWorkspace$()).subscribe({ error: (error) => this.handlePersistenceError("load workspace", error) });
	}
	resetCorruptedStorage() {
		const reset = this.formStoreService.resetCorruptedStorage$;
		if (!reset) return;
		this.runMutation("reset storage", () => this.snapshot$(() => reset.call(this.formStoreService, this.editorConfig.editorType)).pipe(switchMap(() => this.refreshWorkspace$()), tap(() => {
			this.loadValidations();
			if (!this.formList().some((form) => form.id === this.activeFormId())) this.setActiveForm(null);
		})), true);
	}
	getStorageRecoveryBackup(kind) {
		return JSON.stringify({
			exportedAt: (/* @__PURE__ */ new Date()).toISOString(),
			editorType: this.editorConfig.editorType,
			entries: this.storageRecoveryIssues().filter((issue) => !kind || issue.kind === kind)
		}, null, 2);
	}
	setActiveField(fieldId) {
		this.activeFieldIdSrc.set(fieldId);
		const formId = this.activeFormId();
		if (formId) this.activeFieldIdByFormSrc.update((map) => ({
			...map,
			[formId]: fieldId
		}));
	}
	setActiveFormName(newName) {
		const form = this.activeForm();
		if (!form) return;
		const newForm = {
			...form,
			name: newName
		};
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
	}
	setWorkspaceNodeName(nodeId, newName) {
		this.runMutation("rename item", () => {
			const node = this.hierarchyNodeMap()[nodeId];
			if (!node) return of(void 0);
			if (node.type === "form") {
				const activeName = this.activeFormId() === nodeId ? this.activeFormName() : void 0;
				return this.snapshot$(() => this.formStoreService.getForm$(this.editorConfig.editorType, nodeId)).pipe(switchMap((form) => form ? this.snapshot$(() => this.formStoreService.updateForm$(this.editorConfig.editorType, {
					...form,
					name: newName
				})) : of(void 0)), tap(() => {
					if (this.activeFormId() === nodeId && this.activeFormName() === activeName) this.setActiveFormName(newName);
				}), switchMap(() => this.snapshot$(() => this.formStoreService.saveHierarchy$(this.editorConfig.editorType, renameNodeInHierarchy(this.hierarchy(), nodeId, newName)))));
			}
			return this.snapshot$(() => this.formStoreService.saveHierarchy$(this.editorConfig.editorType, renameNodeInHierarchy(this.hierarchy(), nodeId, newName)));
		});
	}
	cancelLoad() {
		this.loadVersion++;
		this.cancelLoad$.next();
		this.loadingFormIdSrc.set(null);
	}
	setActiveForm(formId) {
		if (this.destroyRef.destroyed) return;
		this.cancelLoad();
		this.pendingFormId = void 0;
		this.formLoadErrorSrc.set(null);
		if (!formId) {
			this.activeVersion++;
			this.activeFormSrc.set(null);
			this.activeFieldIdSrc.set(null);
			this.saveStatusSrc.set("saved");
			this.formSelected$.next(null);
			return;
		}
		if (formId === this.activeFormId()) return;
		if (this.hasFormStorageRecoveryIssue()) {
			this.formLoadErrorSrc.set({
				formId,
				reason: "recovery-required"
			});
			return;
		}
		if (this.activeForm() && this.saveStatus() !== "saved") {
			this.pendingFormId = formId;
			this.requestSave();
			return;
		}
		const version = this.loadVersion;
		this.loadingFormIdSrc.set(formId);
		this.snapshot$(() => this.formStoreService.getForm$(this.editorConfig.editorType, formId)).pipe(takeUntil(this.cancelLoad$)).subscribe({
			next: (rawForm) => {
				if (version !== this.loadVersion) return;
				this.loadingFormIdSrc.set(null);
				if (!rawForm) {
					this.formLoadErrorSrc.set({
						formId,
						reason: "not-found"
					});
					return;
				}
				if (!this.editorConfig.libraries.some((library) => library.id === rawForm.libraryId)) {
					this.formLoadErrorSrc.set({
						formId,
						reason: "missing-library",
						libraryId: rawForm.libraryId
					});
					return;
				}
				let form;
				try {
					form = this.convertFromRawForm(rawForm);
				} catch (cause) {
					this.formLoadErrorSrc.set({
						formId,
						reason: "invalid-form",
						cause
					});
					return;
				}
				this.activeVersion++;
				this.activeFormSrc.set(form);
				this.saveStatusSrc.set("saved");
				const fieldId = this.activeFieldIdByFormSrc()[formId];
				this.activeFieldIdSrc.set(fieldId && form.fieldMap[fieldId] ? fieldId : form.rootFieldIds[0] ?? null);
				this.formSelected$.next(form);
			},
			error: (cause) => {
				if (version !== this.loadVersion) return;
				this.loadingFormIdSrc.set(null);
				this.formLoadErrorSrc.set({
					formId,
					reason: "store-error",
					cause
				});
			}
		});
	}
	saveActiveForm() {
		this.saveActiveFormTrigger$.next();
	}
	addForm$(name, fields = [], model, libraryId, setActive = true, parentId) {
		const newRawForm = {
			id: generateFormId(),
			libraryId,
			fieldCount: 0,
			parentId: parentId ?? null,
			name,
			fields,
			model
		};
		const newForm = this.convertFromRawForm(newRawForm);
		newRawForm.fieldCount = Object.keys(newForm.fieldMap).length;
		return this.enqueue$(() => this.snapshot$(() => this.formStoreService.addForm$(this.editorConfig.editorType, newRawForm)).pipe(switchMap(() => this.refreshWorkspace$()), tap(() => {
			if (setActive) this.setActiveForm(newForm.id);
		})));
	}
	clearDeletedSelection(formId) {
		if (this.loadingFormId() === formId) this.cancelLoad();
		if (this.pendingFormId === formId) this.pendingFormId = void 0;
		if (this.activeFormId() === formId) this.setActiveForm(null);
	}
	removeForm(formId) {
		this.runMutation("remove form", () => this.snapshot$(() => this.formStoreService.removeForm$(this.editorConfig.editorType, formId)).pipe(tap(() => this.clearDeletedSelection(formId))));
	}
	createFolder(name, parentId = null) {
		if (this.isStorageMutationBlocked()) return void 0;
		const folderId = `folder_${v4().substring(0, 8)}`;
		this.runMutation("create folder", () => {
			const parentNode = parentId ? this.hierarchyNodeMap()[parentId] : null;
			const folder = {
				id: folderId,
				name,
				type: "folder",
				parentId,
				idPath: [...parentNode?.idPath ?? [], folderId],
				childIds: [],
				isExpanded: true
			};
			return this.snapshot$(() => this.formStoreService.saveHierarchy$(this.editorConfig.editorType, addNodeToHierarchy(this.hierarchy(), folder)));
		});
		return folderId;
	}
	deleteWorkspaceNode(nodeId) {
		this.runMutation("delete item", () => {
			if (!this.hierarchyNodeMap()[nodeId]) return of(void 0);
			const { removedNodeIds } = removeNodeFromHierarchy(this.hierarchy(), nodeId);
			const formIds = removedNodeIds.filter((id) => this.formList().some((form) => form.id === id));
			const failedFormIds = [];
			const failures = [];
			return from(formIds).pipe(concatMap((id) => this.snapshot$(() => this.formStoreService.removeForm$(this.editorConfig.editorType, id)).pipe(tap(() => this.clearDeletedSelection(id)), catchError((error) => {
				failedFormIds.push(id);
				failures.push(error);
				return of(void 0);
			}))), toArray(), switchMap(() => this.snapshot$(() => this.formStoreService.getHierarchy$(this.editorConfig.editorType))), switchMap((hierarchy) => {
				for (const id of formIds.filter((id) => !failedFormIds.includes(id))) hierarchy = removeNodeFromHierarchy(hierarchy, id).hierarchy;
				if (!failedFormIds.length) hierarchy = removeNodeFromHierarchy(hierarchy, nodeId).hierarchy;
				return this.snapshot$(() => this.formStoreService.saveHierarchy$(this.editorConfig.editorType, hierarchy));
			}), catchError((error) => {
				failures.push(error);
				return of(void 0);
			}), tap(() => {
				if (failures.length) this.handlePersistenceError("delete item", new AggregateError(failures, "Some forms could not be deleted."), failedFormIds);
			}));
		});
	}
	moveWorkspaceNode(nodeId, targetFolderId, targetIndex) {
		this.runMutation("move item", () => {
			const updated = moveNodeInHierarchy(this.hierarchy(), nodeId, targetFolderId, targetIndex);
			return this.snapshot$(() => this.formStoreService.saveHierarchy$(this.editorConfig.editorType, updated)).pipe(switchMap(() => {
				if (updated.nodeMap[nodeId]?.type !== "form") return of(void 0);
				return this.snapshot$(() => this.formStoreService.getForm$(this.editorConfig.editorType, nodeId)).pipe(switchMap((form) => form ? this.snapshot$(() => this.formStoreService.updateForm$(this.editorConfig.editorType, {
					...form,
					parentId: targetFolderId
				})) : of(void 0)), tap(() => {
					const active = this.activeForm();
					if (active?.id === nodeId) this.activeFormSrc.set({
						...active,
						parentId: targetFolderId
					});
				}));
			}));
		});
	}
	renameWorkspaceNode(nodeId, newName) {
		this.setWorkspaceNodeName(nodeId, newName);
	}
	toggleFolderExpansion(folderId, isExpanded) {
		this.runMutation("update folder", () => this.snapshot$(() => this.formStoreService.saveHierarchy$(this.editorConfig.editorType, toggleFolderExpansion(this.hierarchy(), folderId, isExpanded))));
	}
	isStorageMutationBlocked() {
		if (!this.storageRecoveryIssues().some((issue) => issue.kind !== "validations")) return false;
		this.saveStatusSrc.set("error");
		return true;
	}
	handlePersistenceError(action, error, failedFormIds) {
		this.persistenceErrorSrc.set({
			action,
			cause: error,
			failedFormIds
		});
		this.saveStatusSrc.set("error");
		console.error(`Failed to ${action}`, error);
	}
	modifyActiveField(change) {
		if (!change.path) throw new Error("Path is missing from field change");
		const form = this.activeForm();
		if (!form) return;
		const activeFieldId = this.activeFieldIdSrc();
		if (!activeFieldId) return;
		const activeField = this.getField(activeFieldId);
		if (!activeField) return;
		const newActiveField = modifyPropertyTarget(activeField, change);
		const newFieldMap = {
			...this.activeFieldMap(),
			[newActiveField._info.id]: newActiveField
		};
		const newForm = {
			...form,
			fieldMap: newFieldMap
		};
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
	}
	setActiveModel(newModel) {
		const form = this.activeForm();
		if (!form) return;
		const newForm = {
			...form,
			model: newModel
		};
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
	}
	modifyActiveModel(newModelJSON) {
		const form = this.activeForm();
		if (!form) return;
		const newModel = JSON.parse(newModelJSON);
		const newForm = {
			...form,
			model: newModel
		};
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
	}
	getField(fieldId) {
		return this.activeFieldMap()?.[fieldId];
	}
	getTypeOptions(libraryId) {
		return this.editorConfig.libraries.find((library) => library.id === libraryId)?.fieldTypes ?? [];
	}
	getDefaultField(type, libraryId) {
		const library = this.editorConfig.libraries.find((library) => library.id === libraryId);
		const option = library?.fieldTypes.find((field) => field.name === type);
		return structuredClone(option ? {
			...option.defaultConfig,
			type: option.name
		} : library?.defaultField ?? {});
	}
	insertId(id, arr, index) {
		let newArr;
		if (typeof index === "number") newArr = [
			...arr.slice(0, index),
			id,
			...arr.slice(index)
		];
		else newArr = [...arr, id];
		return newArr;
	}
	buildField(fieldId, fieldMap) {
		const field = fieldMap[fieldId];
		const clonedField = structuredClone(field);
		const info = clonedField._info;
		if (info.isFieldArray && info.childIds.length) {
			const fieldArray = this.buildField(info.childIds[0], fieldMap);
			if (fieldArray) clonedField.fieldArray = fieldArray;
		} else if (info.childIds.length) clonedField.fieldGroup = info.childIds.map((id) => this.buildField(id, fieldMap)).filter((f) => !!f);
		return clonedField;
	}
	cleanField(field) {
		if (field._info.isParent) {
			if (field._info.isFieldArray && field.fieldArray) this.cleanField(field.fieldArray);
			else if (field.fieldGroup?.length) field.fieldGroup.forEach((f) => this.cleanField(f));
		}
		unset(field, "_info");
		[
			"wrappers",
			"templateOptions",
			"props",
			"expression",
			"className",
			"fieldGroupClassName",
			"validation.messages",
			"validation"
		].forEach((p) => {
			if (isEmpty(get(field, p))) unset(field, p);
		});
	}
	convertFromRawForm({ id, name, libraryId, fields, model, parentId }) {
		id = id || generateFormId();
		const fieldMap = {};
		const fieldTypeOptions = this.getTypeOptions(libraryId);
		const rootFieldIds = fields.map((f) => convertField(f, generateFieldId(f.type), id, [], fieldMap, fieldTypeOptions, (type) => this.getDefaultField(type, libraryId))).map((f) => f._info.id);
		return {
			id,
			name,
			libraryId,
			fieldCount: Object.keys(fieldMap).length,
			parentId,
			fieldMap,
			rootFieldIds,
			model
		};
	}
	convertToRawForm({ id, libraryId, name, fieldMap, rootFieldIds, model, parentId }) {
		const fields = rootFieldIds.map((id) => this.buildField(id, fieldMap));
		fields.forEach((f) => this.cleanField(f));
		return {
			id,
			libraryId,
			name,
			fieldCount: Object.keys(fieldMap).length,
			fields,
			model,
			parentId
		};
	}
	getFieldIndex(fieldId) {
		const field = this.getField(fieldId);
		if (!field) return -1;
		const idPath = field._info.idPath;
		const parentId = idPath[idPath.length - 2];
		if (parentId) {
			const parent = this.getField(parentId);
			if (!parent) return -1;
			return parent._info.childIds.indexOf(fieldId);
		}
		const form = this.activeForm();
		if (!form) return -1;
		return form.rootFieldIds.indexOf(fieldId);
	}
	canDropField(sourceId, targetId, position) {
		const form = this.activeForm();
		return !!form && canDropField(form, sourceId, targetId, position);
	}
	dropField(targetId, position, source) {
		const form = this.activeForm();
		const sourceId = "fieldId" in source ? source.fieldId : void 0;
		if (!form || !canDropField(form, sourceId, targetId, position)) return;
		const fieldId = sourceId ?? generateFieldId("fieldType" in source ? source.fieldType : void 0);
		const newForm = create(form, (draft) => {
			if ("fieldType" in source) convertField(source.preset?.field ?? this.getDefaultField(source.fieldType, form.libraryId), fieldId, form.id, [], draft.fieldMap, this.getTypeOptions(form.libraryId), (type) => this.getDefaultField(type, form.libraryId));
			placeField(draft, fieldId, targetId, position, generateFieldId("row"));
		});
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
		this.activeFieldIdSrc.set(fieldId);
	}
	addField(fieldType, parentId, index, preset) {
		const form = this.activeForm();
		if (!form) return;
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) throw new Error("No active configuration is set.");
		const newFieldId = generateFieldId(fieldType);
		const newForm = create(form, (draft) => {
			const fieldMap = draft.fieldMap;
			const parent = parentId ? fieldMap[parentId] : void 0;
			convertField(preset?.field ?? this.getDefaultField(fieldType, activeLibraryId), newFieldId, draft.id, parent ? parent._info.idPath : [], fieldMap, this.getTypeOptions(activeLibraryId), (type) => this.getDefaultField(type, activeLibraryId));
			if (parent) {
				if (parent._info.isFieldArray) {
					const previousChildId = parent._info.childIds[0];
					const removeRecursively = (fieldId) => {
						const field = fieldMap[fieldId];
						if (!field) return;
						field._info.childIds.forEach(removeRecursively);
						delete fieldMap[fieldId];
					};
					if (previousChildId) removeRecursively(previousChildId);
					parent._info.childIds = [newFieldId];
				} else parent._info.childIds = this.insertId(newFieldId, parent._info.childIds, index);
			} else draft.rootFieldIds = this.insertId(newFieldId, draft.rootFieldIds, index);
		});
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
		this.activeFieldIdSrc.set(newFieldId);
	}
	removeField(fieldId) {
		const form = this.activeForm();
		if (!form) return;
		if (!form.fieldMap[fieldId]) return;
		const activeFieldId = this.activeFieldIdSrc();
		const activeField = activeFieldId ? form.fieldMap[activeFieldId] : void 0;
		const newForm = create(form, (draft) => {
			const fieldMap = draft.fieldMap;
			const field = fieldMap[fieldId];
			const parentId = field._info.idPath[field._info.idPath.length - 2];
			if (parentId) {
				const parent = fieldMap[parentId];
				parent._info.childIds = parent._info.childIds.filter((id) => id !== fieldId);
			} else draft.rootFieldIds = draft.rootFieldIds.filter((id) => id !== fieldId);
			clearFieldModelValue(fieldId, fieldMap, draft.model);
			const removeRecursively = (id) => {
				const field = fieldMap[id];
				if (field) {
					field._info.childIds.forEach(removeRecursively);
					delete fieldMap[id];
				}
			};
			removeRecursively(fieldId);
			removeEmptyRows(draft);
		});
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
		if (activeFieldId === fieldId || activeField?._info.idPath.includes(fieldId) || activeFieldId && !newForm.fieldMap[activeFieldId]) this.activeFieldIdSrc.set(null);
	}
	moveField(fieldId, fromIndex, toIndex, toParentId) {
		const form = this.activeForm();
		if (!form) return;
		if (!form.fieldMap[fieldId]) return;
		const newForm = create(form, (draft) => {
			const fieldMap = draft.fieldMap;
			const field = fieldMap[fieldId];
			const currentParentId = field._info.idPath[field._info.idPath.length - 2];
			const targetParent = toParentId ? fieldMap[toParentId] : void 0;
			if (targetParent?._info.idPath.includes(fieldId)) return;
			if (currentParentId) {
				const currentParent = fieldMap[currentParentId];
				currentParent._info.childIds = currentParent._info.childIds.filter((id) => id !== fieldId);
			} else draft.rootFieldIds = draft.rootFieldIds.filter((id) => id !== fieldId);
			if (targetParent) {
				if (targetParent._info.isFieldArray) targetParent._info.childIds = [fieldId];
				else {
					let insertIndex = typeof toIndex === "number" ? toIndex : targetParent._info.childIds.length;
					if (currentParentId === targetParent._info.id && fromIndex < insertIndex) insertIndex--;
					targetParent._info.childIds = this.insertId(fieldId, targetParent._info.childIds, insertIndex);
				}
			} else {
				let insertIndex = typeof toIndex === "number" ? toIndex : draft.rootFieldIds.length;
				if (!currentParentId && fromIndex < insertIndex) insertIndex--;
				draft.rootFieldIds = this.insertId(fieldId, draft.rootFieldIds, insertIndex);
			}
			const updateIdPath = (currFieldId, parentPath) => {
				const currField = fieldMap[currFieldId];
				currField._info.idPath = [...parentPath, currFieldId];
				currField._info.childIds.forEach((childId) => updateIdPath(childId, currField._info.idPath));
			};
			updateIdPath(fieldId, targetParent ? targetParent._info.idPath : []);
			removeEmptyRows(draft);
		});
		if (newForm === form) return;
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
		this.activeFieldIdSrc.set(fieldId);
	}
	replaceField(fieldType, fieldId) {
		const form = this.activeForm();
		if (!form) return;
		const field = form.fieldMap[fieldId];
		if (!field || field.type === fieldType) return;
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) throw new Error("No active configuration is set.");
		const fieldTypeOptions = this.getTypeOptions(activeLibraryId);
		if (!fieldTypeOptions.some((option) => option.name === fieldType)) return;
		const parentId = field._info.idPath[field._info.idPath.length - 2];
		const siblingIndex = (parentId ? form.fieldMap[parentId]?._info.childIds : form.rootFieldIds)?.indexOf(fieldId) ?? -1;
		if (siblingIndex < 0) return;
		const replacementId = generateFieldId(fieldType);
		const newForm = create(form, (draft) => {
			const fieldMap = draft.fieldMap;
			const oldField = fieldMap[fieldId];
			const parent = parentId ? fieldMap[parentId] : void 0;
			convertField(this.getDefaultField(fieldType, activeLibraryId), replacementId, draft.id, parent?._info.idPath ?? [], fieldMap, fieldTypeOptions, (type) => this.getDefaultField(type, activeLibraryId));
			const replacement = fieldMap[replacementId];
			const oldChildIds = [...oldField._info.childIds];
			if (oldField.key !== void 0) replacement.key = oldField.key;
			if (oldField.className !== void 0) replacement.className = oldField.className;
			if (oldField.fieldGroupClassName !== void 0) replacement.fieldGroupClassName = oldField.fieldGroupClassName;
			const canTransferChildren = oldField._info.isParent && replacement._info.isParent;
			const removeSubtree = (id) => {
				const child = fieldMap[id];
				if (!child) return;
				child._info.childIds.forEach(removeSubtree);
				delete fieldMap[id];
			};
			if (canTransferChildren) {
				replacement._info.childIds.forEach(removeSubtree);
				const transferredChildIds = replacement._info.isFieldArray ? oldChildIds.slice(0, 1) : oldChildIds;
				const transferredChildIdSet = new Set(transferredChildIds);
				oldChildIds.filter((childId) => !transferredChildIdSet.has(childId)).forEach(removeSubtree);
				replacement._info.childIds = transferredChildIds;
				const updateIdPath = (id, parentPath) => {
					const child = fieldMap[id];
					if (!child) return;
					child._info.idPath = [...parentPath, id];
					child._info.childIds.forEach((childId) => updateIdPath(childId, child._info.idPath));
				};
				oldChildIds.forEach((childId) => updateIdPath(childId, replacement._info.idPath));
			} else oldChildIds.forEach(removeSubtree);
			if (parent) parent._info.childIds[siblingIndex] = replacementId;
			else draft.rootFieldIds[siblingIndex] = replacementId;
			clearFieldModelValue(fieldId, fieldMap, draft.model);
			delete fieldMap[fieldId];
		});
		this.activeFormSrc.set(newForm);
		this.markFormDirty();
		this.activeFieldIdSrc.set(replacementId);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderEngineService,
		deps: [{ token: BUILDER_ENGINE_CONFIG }, { token: CORE_FORM_STORE }],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderEngineService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderEngineService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{
		type: void 0,
		decorators: [{
			type: Inject,
			args: [BUILDER_ENGINE_CONFIG]
		}]
	}, {
		type: void 0,
		decorators: [{
			type: Inject,
			args: [CORE_FORM_STORE]
		}]
	}]
});
var BuilderFieldStateService = class BuilderFieldStateService {
	formService;
	constructor(formService = inject(BuilderEngineService)) {
		this.formService = formService;
	}
	state = linkedSignal({
		...ngDevMode ? { debugName: "state" } : /* istanbul ignore next */ {},
		source: () => this.formService.activeFieldMap(),
		computation: (fields, previous) => Object.fromEntries(Object.entries(previous?.value ?? {}).filter(([id]) => Object.hasOwn(fields, id)))
	});
	getState(field) {
		const id = field._info?.id;
		return id && Object.hasOwn(this.formService.activeFieldMap(), id) ? this.state()[id] : void 0;
	}
	setState(field, state) {
		const id = field._info?.id;
		if (!id || !Object.hasOwn(this.formService.activeFieldMap(), id)) return;
		this.state.update((current) => ({
			...current,
			[id]: state
		}));
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderFieldStateService,
		deps: [{ token: BuilderEngineService }],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: BuilderFieldStateService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: BuilderFieldStateService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => [{ type: BuilderEngineService }]
});
function provideBuilderEngine(config) {
	return makeEnvironmentProviders([
		{
			provide: BUILDER_ENGINE_CONFIG,
			useValue: config
		},
		{
			provide: CORE_FORM_STORE,
			useClass: config.formStore ?? LocalFormStoreService
		},
		BuilderEngineService,
		BuilderFieldStateService
	]);
}
function provideFormStore(service) {
	return makeEnvironmentProviders([{
		provide: CORE_FORM_STORE,
		useExisting: service
	}]);
}
function provideLocalFormStore() {
	return makeEnvironmentProviders([{
		provide: CORE_FORM_STORE,
		useClass: LocalFormStoreService
	}]);
}
function withValidationExpressions() {
	const wrapped = /* @__PURE__ */ new WeakSet();
	return { extensions: [{
		name: "builder-validation-expressions",
		extension: { postPopulate(root) {
			const options = root.options;
			if (root.parent || !options || wrapped.has(options)) return;
			wrapped.add(options);
			const checkExpressions = options.checkExpressions;
			let previousModel;
			options.checkExpressions = (field, ignoreCache) => {
				checkExpressions?.(field, ignoreCache);
				const fields = expressionFields(root);
				if (!fields.length || isEqual(previousModel, root.model)) return;
				previousModel = cloneDeep(root.model);
				for (const candidate of fields) candidate.formControl?.updateValueAndValidity();
				options.detectChanges?.(root);
			};
		} }
	}] };
}
function expressionFields(field) {
	return [...Object.values(field.validators ?? {}).some((rule) => rule && typeof rule === "object" && "expression" in rule && typeof rule.expression === "string") ? [field] : [], ...(field.fieldGroup ?? []).flatMap(expressionFields)];
}
export { BUILDER_ENGINE_CONFIG, BuilderEngineService, BuilderFieldStateService, CORE_FORM_STORE, FormStoreRecoveryRequiredError, LocalFormStoreService, PropertyChangeType, addNodeToHierarchy, buildHierarchyFromFlatForms, clearFieldModelValue, convertField, createEmptyWorkspaceHierarchy, generateFieldId, generateFormId, getDescendantNodeIds, isAncestorOf, isLayoutRow, isValidationRuleName, modifyPropertyTarget, moveNodeInHierarchy, provideBuilderEngine, provideFormStore, provideLocalFormStore, recalculateNodePaths, removeNodeFromHierarchy, renameNodeInHierarchy, toggleFolderExpansion, withValidationExpressions };

//# sourceMappingURL=ngx-formly-builder.mjs.map