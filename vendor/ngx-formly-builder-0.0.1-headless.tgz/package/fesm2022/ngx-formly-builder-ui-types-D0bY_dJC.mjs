import { BuilderEngineService, CORE_FORM_STORE, CORE_FORM_STORE as CORE_FORM_STORE$1, FormStoreRecoveryRequiredError, PropertyChangeType, modifyPropertyTarget, withValidationExpressions } from "@ngx-formly/builder";
import * as z$1 from "zod";
import z, { treeifyError } from "zod";
import * as i0 from "@angular/core";
import { ApplicationRef, ChangeDetectionStrategy, Component, DestroyRef, Directive, ElementRef, EnvironmentInjector, Injectable, InjectionToken, Injector, Pipe, RendererFactory2, afterNextRender, booleanAttribute, computed, contentChild, createComponent, createEnvironmentInjector, effect, forwardRef, inject, input, model, numberAttribute, output, signal, viewChild } from "@angular/core";
import { takeUntilDestroyed, toSignal } from "@angular/core/rxjs-interop";
import { Dialog } from "@angular/cdk/dialog";
import { hasModifierKey } from "@angular/cdk/keycodes";
import { AsyncPipe, DOCUMENT as DOCUMENT$1, NgTemplateOutlet } from "@angular/common";
import { Subject, map } from "rxjs";
import { isEmpty, isEqual } from "lodash-es";
import { v4 } from "uuid";
import { FORMLY_CONFIG, FieldType, FieldWrapper, FormlyAttributes, FormlyConfig, FormlyForm, FormlyValidationMessage, provideFormlyCore } from "@ngx-formly/core";
import * as i1$1 from "@angular/forms";
import { FormGroup, FormsModule, NG_VALIDATORS, NgControl, ReactiveFormsModule } from "@angular/forms";
import { FormlySelectOptionsPipe } from "@ngx-formly/core/select";
import { javascript } from "@codemirror/lang-javascript";
import { json } from "@codemirror/lang-json";
import { markdown, markdownLanguage } from "@codemirror/lang-markdown";
import { Compartment, EditorState } from "@codemirror/state";
import { EditorView, placeholder } from "@codemirror/view";
import { vscodeDark, vscodeLight } from "@uiw/codemirror-theme-vscode";
import { basicSetup } from "codemirror";
import * as i1 from "@angular/material/tooltip";
import { MatTooltip } from "@angular/material/tooltip";
import { Overlay, OverlayContainer, OverlayKeyboardDispatcher, OverlayOutsideClickDispatcher, OverlayPositionBuilder, ScrollStrategyOptions } from "@angular/cdk/overlay";
import { ScrollDispatcher, ViewportRuler } from "@angular/cdk/scrolling";
import beautify from "js-beautify";
import { minify } from "terser";
var PropertyType;
(function(PropertyType) {
	PropertyType["BOOLEAN"] = "Boolean";
	PropertyType["INPUT"] = "Input";
	PropertyType["MARKDOWN"] = "Markdown";
	PropertyType["DATE"] = "Date";
	PropertyType["OBJECT"] = "Object";
	PropertyType["GROUP"] = "Group";
	PropertyType["ARRAY"] = "Array";
	PropertyType["SELECT"] = "Select";
	PropertyType["CHIPS"] = "Chips";
	PropertyType["WRAPPERS"] = "Wrappers";
	PropertyType["EXPRESSIONS"] = "Expressions";
	PropertyType["VALIDATION_MESSAGES"] = "Validation Messages";
	PropertyType["CUSTOM_VALIDATION"] = "Custom Validation";
})(PropertyType || (PropertyType = {}));
const createArrayProperty = (v) => ({
	...v,
	type: PropertyType.ARRAY
});
const createBooleanProperty = (v) => ({
	...v,
	type: PropertyType.BOOLEAN
});
const createChipsProperty = (v) => ({
	...v,
	type: PropertyType.CHIPS
});
const createCustomValidationProperty = (v) => ({
	...v,
	type: PropertyType.CUSTOM_VALIDATION
});
const createDateProperty = (v) => ({
	...v,
	type: PropertyType.DATE
});
const createExpressionsProperty = (v) => ({
	...v,
	type: PropertyType.EXPRESSIONS
});
const createGroupProperty = (value) => ({
	...value,
	type: PropertyType.GROUP
});
const createInputProperty = (v) => ({
	...v,
	type: PropertyType.INPUT
});
const createMarkdownProperty = (v) => ({
	...v,
	type: PropertyType.MARKDOWN
});
const createObjectProperty = (v) => ({
	...v,
	type: PropertyType.OBJECT
});
const createSelectProperty = (v) => ({
	...v,
	type: PropertyType.SELECT
});
const trackByPropertyKey = (_, property) => property.key;
function getChildPath(path, key) {
	if (key === void 0) throw new Error("key is undefined");
	return [...path, ...key.toString().split(".")];
}
const getDefaultProperty = (type, key = "", dataType = "text", childPropertyType) => {
	const baseProperty = {
		type,
		key,
		isKeyEditable: true,
		isRemovable: true
	};
	switch (type) {
		case PropertyType.BOOLEAN: return {
			...baseProperty,
			type: PropertyType.BOOLEAN
		};
		case PropertyType.INPUT: return {
			...baseProperty,
			type: PropertyType.INPUT,
			dataType
		};
		case PropertyType.MARKDOWN: return {
			...baseProperty,
			type: PropertyType.MARKDOWN
		};
		case PropertyType.DATE: return {
			...baseProperty,
			type: PropertyType.DATE
		};
		case PropertyType.OBJECT: return {
			...baseProperty,
			type: PropertyType.OBJECT,
			childProperties: [],
			populateChildrenFromTarget: true
		};
		case PropertyType.ARRAY: return {
			...baseProperty,
			type: PropertyType.ARRAY,
			canAdd: true,
			childProperty: childPropertyType ? getDefaultProperty(childPropertyType) : void 0
		};
		default: throw new Error(`Property type ${type} does not have a default property`);
	}
};
const getDefaultPropertyFromValue = (value, key) => {
	const propertyType = getPropertyType(value);
	if (!propertyType) return;
	let dataType = "text";
	if (propertyType === PropertyType.INPUT) dataType = typeof value === "number" ? "number" : "text";
	return getDefaultProperty(propertyType, key, dataType);
};
const getDefaultPropertyValue = (type, dataType) => {
	switch (type) {
		case PropertyType.ARRAY: return [];
		case PropertyType.OBJECT: return {};
		case PropertyType.BOOLEAN: return false;
		case PropertyType.DATE: return /* @__PURE__ */ new Date();
		case PropertyType.INPUT: return dataType === "number" ? 0 : "";
		case PropertyType.MARKDOWN: return "";
		case PropertyType.SELECT: return null;
		default: throw new Error(`Property type ${type} does not have a default value`);
	}
};
const getPropertyType = (value) => {
	switch (typeof value) {
		case "object":
			if (value === null) return;
			else if (Array.isArray(value)) return PropertyType.ARRAY;
			else if (value instanceof Date) return PropertyType.DATE;
			return PropertyType.OBJECT;
		case "boolean": return PropertyType.BOOLEAN;
		case "number":
		case "string": return PropertyType.INPUT;
		default: return;
	}
};
function getPropertySchema(property) {
	let schema;
	switch (property.type) {
		case PropertyType.BOOLEAN:
			schema = z.boolean();
			break;
		case PropertyType.DATE:
			schema = z.string();
			break;
		case PropertyType.INPUT:
			schema = property.dataType === "number" ? z.number() : z.string();
			break;
		case PropertyType.MARKDOWN:
			schema = z.string();
			break;
		case PropertyType.OBJECT: {
			const objProp = property;
			const shape = {};
			if (objProp.childProperties) for (const childProp of objProp.childProperties) {
				if (!childProp.key) throw new Error("Child property of an object must have a key defined");
				shape[childProp.key] = getPropertySchema(childProp);
			}
			schema = z.object(shape);
			break;
		}
		case PropertyType.ARRAY: {
			const arrProp = property;
			const childSchema = arrProp.childProperty ? getPropertySchema(arrProp.childProperty) : z.unknown();
			schema = z.array(childSchema);
			break;
		}
		case PropertyType.SELECT: {
			const validValues = property.options.map((opt) => opt.value);
			schema = z.union(validValues.map((val) => z.literal(val)));
			break;
		}
		case PropertyType.CHIPS:
			schema = property.outputString ? z.string() : z.array(z.string());
			break;
		case PropertyType.EXPRESSIONS:
			schema = z.record(z.string(), z.string());
			break;
		case PropertyType.VALIDATION_MESSAGES:
			schema = z.record(z.string(), z.string());
			break;
		case PropertyType.CUSTOM_VALIDATION:
			schema = z.array(z.union([z.object({
				name: z.string(),
				options: z.record(z.string(), z.unknown()).optional()
			}), z.string()]));
			break;
		default: throw new Error(`Unknown property type: ${property.type}`);
	}
	return property.isRequired ? schema : schema.optional();
}
const createValidationMessagesProperty = (v) => ({
	...v,
	type: PropertyType.VALIDATION_MESSAGES
});
const createWrappersProperty = (value) => ({
	...value,
	type: PropertyType.WRAPPERS
});
var Dialog$1 = class Dialog$1 {
	visible = input(false, {
		...ngDevMode ? { debugName: "visible" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	header = input("", ...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	focusOnShow = input(true, {
		...ngDevMode ? { debugName: "focusOnShow" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	style = input({}, ...ngDevMode ? [{ debugName: "style" }] : /* istanbul ignore next */ []);
	pt = input({}, ...ngDevMode ? [{ debugName: "pt" }] : /* istanbul ignore next */ []);
	closable = input(true, {
		...ngDevMode ? { debugName: "closable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	closeOnEscape = input(true, {
		...ngDevMode ? { debugName: "closeOnEscape" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	visibleChange = output();
	opened = output();
	role = input("dialog", ...ngDevMode ? [{ debugName: "role" }] : /* istanbul ignore next */ []);
	headerTemplate = contentChild("header", ...ngDevMode ? [{ debugName: "headerTemplate" }] : /* istanbul ignore next */ []);
	footerTemplate = contentChild("footer", ...ngDevMode ? [{ debugName: "footerTemplate" }] : /* istanbul ignore next */ []);
	titleId = `core-dialog-${crypto.randomUUID()}`;
	body = viewChild("body", ...ngDevMode ? [{ debugName: "body" }] : /* istanbul ignore next */ []);
	dialogs = inject(Dialog);
	injector = inject(Injector);
	ref;
	constructor() {
		effect(() => {
			const body = this.body();
			if (this.visible() && body && !this.ref) {
				const ref = this.dialogs.open(body, {
					ariaLabel: this.header() || void 0,
					ariaLabelledBy: this.header() ? void 0 : this.titleId,
					closeOnNavigation: false,
					disableClose: true,
					autoFocus: this.focusOnShow() ? "first-tabbable" : "dialog",
					panelClass: this.role() === "complementary" ? "core-drawer-overlay" : "core-dialog-overlay"
				});
				this.ref = ref;
				if (this.role() === "complementary") ref.overlayRef.overlayElement.setAttribute("role", "complementary");
				ref.closed.subscribe(() => {
					this.ref = void 0;
					this.visibleChange.emit(false);
				});
				ref.keydownEvents.subscribe((event) => {
					if (event.key === "Escape" && !hasModifierKey(event) && this.closable() && this.closeOnEscape()) {
						event.preventDefault();
						ref.close();
					}
				});
				ref.backdropClick.subscribe(() => {
					if (this.role() === "complementary" && this.closable()) ref.close();
				});
				afterNextRender(() => this.opened.emit(), { injector: this.injector });
			} else if (!this.visible()) this.ref?.close();
		});
	}
	close() {
		this.ref?.close();
	}
	ngOnDestroy() {
		this.ref?.close();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Dialog$1,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: Dialog$1,
		isStandalone: true,
		selector: "core-dialog",
		inputs: {
			visible: {
				classPropertyName: "visible",
				publicName: "visible",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			focusOnShow: {
				classPropertyName: "focusOnShow",
				publicName: "focusOnShow",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			style: {
				classPropertyName: "style",
				publicName: "style",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			pt: {
				classPropertyName: "pt",
				publicName: "pt",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closable: {
				classPropertyName: "closable",
				publicName: "closable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			closeOnEscape: {
				classPropertyName: "closeOnEscape",
				publicName: "closeOnEscape",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			role: {
				classPropertyName: "role",
				publicName: "role",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			visibleChange: "visibleChange",
			opened: "opened"
		},
		queries: [{
			propertyName: "headerTemplate",
			first: true,
			predicate: ["header"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "footerTemplate",
			first: true,
			predicate: ["footer"],
			descendants: true,
			isSignal: true
		}],
		viewQueries: [{
			propertyName: "body",
			first: true,
			predicate: ["body"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <ng-template #body>
      <section
        class="core-root core-dialog"
        [style]="style()"
      >
        <header
          class="core-dialog-header"
          [class]="pt().header?.class"
          [style]="pt().header?.style"
        >
          <div [id]="titleId">
            @if (headerTemplate(); as title) {
              <ng-container
                [ngTemplateOutlet]="title"
                [ngTemplateOutletContext]="{ ariaLabelledBy: titleId + '-text' }"
              />
            } @else {
              <h2>{{ header() }}</h2>
            }
          </div>
          <button
            coreButton
            text
            rounded
            type="button"
            aria-label="Close"
            [disabled]="!closable()"
            (click)="close()"
          >
            <i
              class="material-symbols-outlined"
              aria-hidden="true"
              >close</i
            >
          </button>
        </header>
        <div
          class="core-dialog-content"
          [class]="pt().content?.class"
          [style]="pt().content?.style"
        >
          <ng-content />
        </div>
        @if (footerTemplate(); as footer) {
          <footer
            class="core-dialog-footer"
            [class]="pt().footer?.class"
            [style]="pt().footer?.style"
          >
            <ng-container [ngTemplateOutlet]="footer" />
          </footer>
        }
      </section>
    </ng-template>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: NgTemplateOutlet,
			selector: "[ngTemplateOutlet]",
			inputs: [
				"ngTemplateOutletContext",
				"ngTemplateOutlet",
				"ngTemplateOutletInjector"
			]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Dialog$1,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-dialog",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [NgTemplateOutlet],
			template: `
    <ng-template #body>
      <section
        class="core-root core-dialog"
        [style]="style()"
      >
        <header
          class="core-dialog-header"
          [class]="pt().header?.class"
          [style]="pt().header?.style"
        >
          <div [id]="titleId">
            @if (headerTemplate(); as title) {
              <ng-container
                [ngTemplateOutlet]="title"
                [ngTemplateOutletContext]="{ ariaLabelledBy: titleId + '-text' }"
              />
            } @else {
              <h2>{{ header() }}</h2>
            }
          </div>
          <button
            coreButton
            text
            rounded
            type="button"
            aria-label="Close"
            [disabled]="!closable()"
            (click)="close()"
          >
            <i
              class="material-symbols-outlined"
              aria-hidden="true"
              >close</i
            >
          </button>
        </header>
        <div
          class="core-dialog-content"
          [class]="pt().content?.class"
          [style]="pt().content?.style"
        >
          <ng-content />
        </div>
        @if (footerTemplate(); as footer) {
          <footer
            class="core-dialog-footer"
            [class]="pt().footer?.class"
            [style]="pt().footer?.style"
          >
            <ng-container [ngTemplateOutlet]="footer" />
          </footer>
        }
      </section>
    </ng-template>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		visible: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "visible",
				required: false
			}]
		}],
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: false
			}]
		}],
		focusOnShow: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "focusOnShow",
				required: false
			}]
		}],
		style: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "style",
				required: false
			}]
		}],
		pt: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "pt",
				required: false
			}]
		}],
		closable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closable",
				required: false
			}]
		}],
		closeOnEscape: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "closeOnEscape",
				required: false
			}]
		}],
		visibleChange: [{
			type: i0.Output,
			args: ["visibleChange"]
		}],
		opened: [{
			type: i0.Output,
			args: ["opened"]
		}],
		role: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "role",
				required: false
			}]
		}],
		headerTemplate: [{
			type: i0.ContentChild,
			args: ["header", { isSignal: true }]
		}],
		footerTemplate: [{
			type: i0.ContentChild,
			args: ["footer", { isSignal: true }]
		}],
		body: [{
			type: i0.ViewChild,
			args: ["body", { isSignal: true }]
		}]
	}
});
const CORE_EDITOR_CONFIG = new InjectionToken("CoreLibraryEditorConfig");
const CORE_LIBRARY_CONFIGS = new InjectionToken("CoreLibraryConfigs");
const CORE_FORM_TEMPLATES = new InjectionToken("CoreFormTemplates");
var PanelService = class PanelService {
	showSettings = inject(CORE_EDITOR_CONFIG, { optional: true })?.showSettings ?? true;
	activePanelSrc = signal("forms", ...ngDevMode ? [{ debugName: "activePanelSrc" }] : /* istanbul ignore next */ []);
	activePanel = this.activePanelSrc.asReadonly();
	activeLHSPanelSrc = signal("forms", ...ngDevMode ? [{ debugName: "activeLHSPanelSrc" }] : /* istanbul ignore next */ []);
	activeLHSPanel = this.activeLHSPanelSrc.asReadonly();
	activeAddFieldTab = signal("fields", ...ngDevMode ? [{ debugName: "activeAddFieldTab" }] : /* istanbul ignore next */ []);
	activeWorkspaceTab = signal("forms", ...ngDevMode ? [{ debugName: "activeWorkspaceTab" }] : /* istanbul ignore next */ []);
	activeRHSPanelSrc = signal("field-edit", ...ngDevMode ? [{ debugName: "activeRHSPanelSrc" }] : /* istanbul ignore next */ []);
	activeRHSPanel = this.activeRHSPanelSrc.asReadonly();
	highlightPanelSrc$ = new Subject();
	highlightPanel$ = this.highlightPanelSrc$.asObservable();
	setActivePanel(panel) {
		if (panel === "forms" || panel === "fields" || panel === "add-field" || panel === "settings") this.setActiveLHSPanel(panel);
		else this.setActiveRHSPanel(panel);
	}
	setActiveLHSPanel(panel) {
		if (panel === "settings" && !this.showSettings) return;
		if (panel === "fields" || panel === "add-field") this.activeWorkspaceTab.set("forms");
		this.activeLHSPanelSrc.set(panel);
		this.activePanelSrc.set(panel);
		this.highlightPanelSrc$.next(panel);
	}
	setActiveRHSPanel(panel) {
		this.activeRHSPanelSrc.set(panel);
		this.activePanelSrc.set(panel);
		this.highlightPanelSrc$.next(panel);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PanelService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PanelService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PanelService,
	decorators: [{ type: Injectable }]
});
function generateTypeOptionSchema({ properties, validationConfig }, validationMessagesPath) {
	const rawShape = {};
	const validationProperties = validationConfig ? [
		...validationConfig.rules.map(({ property }) => property),
		...validationConfig.displayProperties ?? [],
		...validationConfig.customValidators ? [validationConfig.customValidators] : [],
		...validationConfig.asyncValidators ? [validationConfig.asyncValidators] : []
	] : [];
	for (const property of [...properties ?? [], ...validationProperties]) {
		const key = property.key;
		if (!key) throw new Error("Property must have a key defined");
		const schema = getPropertySchema(property);
		if (key.includes(".")) {
			const pathParts = key.split(".");
			let current = rawShape;
			for (let i = 0; i < pathParts.length - 1; i++) {
				const part = pathParts[i];
				if (!current[part]) current[part] = {};
				current = current[part];
			}
			const lastKey = pathParts[pathParts.length - 1];
			current[lastKey] = schema;
		} else rawShape[key] = schema;
	}
	if (validationConfig) {
		const pathParts = validationMessagesPath;
		let current = rawShape;
		for (let i = 0; i < pathParts.length - 1; i++) {
			const part = pathParts[i];
			if (!current[part]) current[part] = {};
			current = current[part];
		}
		current[pathParts[pathParts.length - 1]] = z$1.record(z$1.string(), z$1.unknown()).optional();
	}
	const isZodType = (v) => !!v && typeof v === "object" && "_def" in v;
	const buildZodFromShape = (node) => {
		if (isZodType(node)) return node;
		const childShape = {};
		let hasRequiredChild = false;
		for (const [k, v] of Object.entries(node)) {
			const childSchema = isZodType(v) ? v : buildZodFromShape(v);
			childShape[k] = childSchema;
			if (!childSchema.safeParse(void 0).success) hasRequiredChild = true;
		}
		const objectSchema = z$1.looseObject(childShape);
		return hasRequiredChild ? objectSchema : objectSchema.optional();
	};
	const shape = {};
	for (const [k, v] of Object.entries(rawShape)) shape[k] = isZodType(v) ? v : buildZodFromShape(v);
	return shape;
}
function generateTypeOptionSchemaMap(fieldCategoryOptions, validationMessagesPath) {
	const schemaMap = {};
	for (const category of fieldCategoryOptions) for (const typeOption of category.children) schemaMap[typeOption.name] = {
		typeOption,
		schema: generateTypeOptionSchema(typeOption, validationMessagesPath)
	};
	return schemaMap;
}
const defaultTypeOption = {
	name: "",
	displayName: "Unknown Field",
	description: "Start with an empty field for custom configuration or expressions that update field and model values.",
	materialSymbol: "question_mark",
	disableKeyGeneration: true,
	defaultConfig: {},
	properties: [createExpressionsProperty({
		label: "Expressions",
		key: "expressions",
		description: "Expressions to dynamically change field and model properties."
	})]
};
const validationMessagesPath = ["validation", "messages"];
function getFormSchema(fieldCategoryOptions) {
	const defaultTypeSchema = z.looseObject({
		type: z.undefined("ignore").optional(),
		get fieldGroup() {
			return z.array(fieldSchema).optional();
		},
		get fieldArray() {
			return fieldSchema.optional();
		},
		...generateTypeOptionSchema(defaultTypeOption, validationMessagesPath)
	});
	const typeSchemaMap = generateTypeOptionSchemaMap(fieldCategoryOptions, validationMessagesPath);
	const typeSchemas = Object.entries(typeSchemaMap).map(([typeName, { typeOption, schema }]) => {
		if (typeOption.isFieldArray) return z.looseObject({
			type: z.literal(typeName),
			get fieldArray() {
				return fieldSchema;
			},
			...schema
		});
		else if (typeOption.isParent) return z.looseObject({
			type: z.literal(typeName),
			get fieldGroup() {
				return z.array(fieldSchema);
			},
			...schema
		});
		return z.looseObject({
			type: z.literal(typeName),
			...schema
		});
	});
	let fieldSchema;
	if (typeSchemas.length > 1) fieldSchema = z.union([z.discriminatedUnion("type", typeSchemas, { error: (issue) => {
		if (issue.code === "invalid_union") {
			const type = issue.input.type;
			return type !== void 0 ? `Unknown field type: '${type}'` : "ignore";
		}
	} }), defaultTypeSchema]);
	else if (typeSchemas.length === 1) fieldSchema = z.union([typeSchemas[0], defaultTypeSchema]);
	else fieldSchema = defaultTypeSchema;
	return z.array(fieldSchema);
}
function createLibrary(config) {
	return {
		...config,
		defaultTypeOption,
		schema: getFormSchema(config.fieldCategoryOptions)
	};
}
var FileField = class FileField extends FieldType {
	error = signal("", ...ngDevMode ? [{ debugName: "error" }] : /* istanbul ignore next */ []);
	reader;
	selectFile(input) {
		const file = input.files?.[0];
		if (!file) return;
		this.reader?.abort();
		this.error.set("");
		this.formControl.setValue(null);
		this.formControl.markAsDirty();
		this.formControl.markAsTouched();
		const maxSize = this.props["maxFileSize"] ?? 2097152;
		if (file.size > maxSize || this.props["accept"] === "image/*" && !file.type.startsWith("image/")) {
			this.error.set(file.size > maxSize ? "The file is too large." : "Choose an image file.");
			this.formControl.setErrors({ file: true });
			input.value = "";
			return;
		}
		const reader = new FileReader();
		this.reader = reader;
		this.formControl.markAsPending();
		reader.onload = () => {
			this.formControl.setValue({
				name: file.name,
				type: file.type,
				size: file.size,
				dataUrl: reader.result
			});
		};
		reader.onerror = () => {
			this.error.set("Could not read this file. Please choose it again.");
			this.formControl.setErrors({ file: true });
			input.value = "";
		};
		reader.readAsDataURL(file);
	}
	clearFile(input) {
		this.reader?.abort();
		input.value = "";
		this.error.set("");
		this.formControl.setValue(null);
		this.formControl.markAsDirty();
	}
	ngOnDestroy() {
		this.reader?.abort();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FileField,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: FileField,
		isStandalone: true,
		selector: "core-file-field",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <label
      class="mb-2 block"
      [for]="id"
    >
      {{ props.label }}
      @if (props.required) {
        <span aria-hidden="true">*</span>
      }
    </label>
    <input
      #fileInput
      class="block w-full rounded-md border border-surface p-2 text-sm file:mr-3 file:cursor-pointer file:rounded-sm file:border-0 file:px-2 file:py-1 file:bg-emphasis"
      type="file"
      [formlyAttributes]="field"
      [attr.accept]="props['accept'] || null"
      [disabled]="formControl.disabled"
      [attr.aria-describedby]="id + '-description ' + id + '-error'"
      [attr.aria-invalid]="formControl.invalid && formControl.touched"
      (change)="selectFile(fileInput)"
      (blur)="formControl.markAsTouched()"
    />
    <small
      class="mt-1 block text-muted-color"
      [id]="id + '-description'"
      >{{ props.description }}</small
    >
    @if (formControl.value?.name) {
      <div class="mt-2 flex items-center gap-2 text-sm">
        <span class="min-w-0 break-all">Saved file: {{ formControl.value.name }}</span>
        <button
          class="shrink-0 underline"
          type="button"
          [disabled]="formControl.disabled"
          (click)="clearFile(fileInput)"
        >
          Remove file
        </button>
      </div>
    }
    <small
      class="mt-1 block text-red-600 dark:text-red-400"
      role="status"
      [id]="id + '-error'"
    >
      {{
        error() ||
          (formControl.touched && formControl.hasError('required') ? 'This field is required.' : '')
      }}
    </small>
  `,
		isInline: true,
		dependencies: [{
			kind: "directive",
			type: FormlyAttributes,
			selector: "[formlyAttributes]",
			inputs: ["formlyAttributes", "id"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FileField,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-file-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormlyAttributes],
			template: `
    <label
      class="mb-2 block"
      [for]="id"
    >
      {{ props.label }}
      @if (props.required) {
        <span aria-hidden="true">*</span>
      }
    </label>
    <input
      #fileInput
      class="block w-full rounded-md border border-surface p-2 text-sm file:mr-3 file:cursor-pointer file:rounded-sm file:border-0 file:px-2 file:py-1 file:bg-emphasis"
      type="file"
      [formlyAttributes]="field"
      [attr.accept]="props['accept'] || null"
      [disabled]="formControl.disabled"
      [attr.aria-describedby]="id + '-description ' + id + '-error'"
      [attr.aria-invalid]="formControl.invalid && formControl.touched"
      (change)="selectFile(fileInput)"
      (blur)="formControl.markAsTouched()"
    />
    <small
      class="mt-1 block text-muted-color"
      [id]="id + '-description'"
      >{{ props.description }}</small
    >
    @if (formControl.value?.name) {
      <div class="mt-2 flex items-center gap-2 text-sm">
        <span class="min-w-0 break-all">Saved file: {{ formControl.value.name }}</span>
        <button
          class="shrink-0 underline"
          type="button"
          [disabled]="formControl.disabled"
          (click)="clearFile(fileInput)"
        >
          Remove file
        </button>
      </div>
    }
    <small
      class="mt-1 block text-red-600 dark:text-red-400"
      role="status"
      [id]="id + '-error'"
    >
      {{
        error() ||
          (formControl.touched && formControl.hasError('required') ? 'This field is required.' : '')
      }}
    </small>
  `
		}]
	}]
});
var ExampleSubmitField = class ExampleSubmitField extends FieldType {
	submitted = signal(false, ...ngDevMode ? [{ debugName: "submitted" }] : /* istanbul ignore next */ []);
	submit() {
		this.form.markAllAsTouched();
		this.submitted.set(true);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExampleSubmitField,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: ExampleSubmitField,
		isStandalone: true,
		selector: "core-example-submit-field",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <button
      class="w-full cursor-pointer rounded-md bg-primary px-4 py-2 font-medium text-primary-contrast hover:bg-primary-emphasis focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:cursor-not-allowed disabled:opacity-50"
      type="button"
      [disabled]="props.disabled || form.pending"
      (click)="submit()"
    >
      {{ props.label }}
    </button>
    @if (submitted()) {
      <p
        class="mt-2 text-sm text-muted-color"
        role="status"
      >
        {{
          form.valid
            ? 'Demo complete. No data was sent.'
            : 'Please complete the required fields and fix any errors.'
        }}
      </p>
    }
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExampleSubmitField,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-example-submit-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: `
    <button
      class="w-full cursor-pointer rounded-md bg-primary px-4 py-2 font-medium text-primary-contrast hover:bg-primary-emphasis focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary disabled:cursor-not-allowed disabled:opacity-50"
      type="button"
      [disabled]="props.disabled || form.pending"
      (click)="submit()"
    >
      {{ props.label }}
    </button>
    @if (submitted()) {
      <p
        class="mt-2 text-sm text-muted-color"
        role="status"
      >
        {{
          form.valid
            ? 'Demo complete. No data was sent.'
            : 'Please complete the required fields and fix any errors.'
        }}
      </p>
    }
  `
		}]
	}]
});
const labelProperty = createInputProperty({
	label: "Label",
	key: "props.label",
	dataType: "text"
});
const nativeFieldTypes = [{
	name: "file",
	displayName: "File",
	description: "File attachment",
	materialSymbol: "attach_file",
	keyGenerationPrefix: "file",
	defaultConfig: { props: {
		label: "File",
		maxFileSize: 2097152
	} },
	properties: [
		createInputProperty({
			label: "Key",
			key: "key",
			dataType: "text"
		}),
		labelProperty,
		createInputProperty({
			label: "Description",
			key: "props.description",
			dataType: "text"
		}),
		createInputProperty({
			label: "Accepted file types",
			key: "props.accept",
			dataType: "text"
		}),
		createInputProperty({
			label: "Maximum size (bytes)",
			key: "props.maxFileSize",
			dataType: "number"
		}),
		createBooleanProperty({
			label: "Disabled",
			key: "props.disabled"
		})
	],
	validationConfig: { rules: [{
		name: "required",
		property: createBooleanProperty({
			label: "Required",
			key: "props.required"
		})
	}] }
}, {
	name: "example-submit",
	displayName: "Demo Submit",
	description: "Try form validation",
	materialSymbol: "smart_button",
	disableKeyGeneration: true,
	defaultConfig: { props: { label: "Submit" } },
	properties: [labelProperty, createBooleanProperty({
		label: "Disabled",
		key: "props.disabled"
	})]
}];
const nativeFieldConfig = { types: [{
	name: "file",
	component: FileField
}, {
	name: "example-submit",
	component: ExampleSubmitField
}] };
var VanillaField = class VanillaField extends FieldType {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: VanillaField,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: VanillaField,
		isStandalone: true,
		selector: "core-vanilla-field",
		usesInheritance: true,
		ngImport: i0,
		template: `
    @switch (field.type) {
      @case ('checkbox') {
        <input
          type="checkbox"
          [formControl]="formControl"
          [formlyAttributes]="field"
          [attr.aria-describedby]="id + '-description ' + id + '-error'"
          [attr.aria-invalid]="showError"
        />
      }
      @case ('textarea') {
        <textarea
          [formControl]="formControl"
          [formlyAttributes]="field"
          [rows]="props.rows ?? 3"
          [attr.aria-describedby]="id + '-description ' + id + '-error'"
          [attr.aria-invalid]="showError"
        ></textarea>
      }
      @case ('select') {
        <select
          [formControl]="formControl"
          [formlyAttributes]="field"
          [attr.aria-describedby]="id + '-description ' + id + '-error'"
          [attr.aria-invalid]="showError"
        >
          <option [ngValue]="undefined">{{ props.placeholder ?? 'Select an option' }}</option>
          @for (option of props.options | formlySelectOptions: field | async; track $index) {
            @if (option.group) {
              <optgroup [label]="option.label">
                @for (child of option.group; track $index) {
                  <option
                    [ngValue]="child.value"
                    [disabled]="child.disabled"
                  >
                    {{ child.label }}
                  </option>
                }
              </optgroup>
            } @else {
              <option
                [ngValue]="option.value"
                [disabled]="option.disabled"
              >
                {{ option.label }}
              </option>
            }
          }
        </select>
      }
      @default {
        @if (props.type === 'number') {
          <input
            type="number"
            [formControl]="formControl"
            [formlyAttributes]="field"
            [attr.aria-describedby]="id + '-description ' + id + '-error'"
            [attr.aria-invalid]="showError"
          />
        } @else {
          <input
            [type]="props.type ?? 'text'"
            [formControl]="formControl"
            [formlyAttributes]="field"
            [attr.aria-describedby]="id + '-description ' + id + '-error'"
            [attr.aria-invalid]="showError"
          />
        }
      }
    }
  `,
		isInline: true,
		styles: ["input:not([type=checkbox]),textarea,select{display:block;box-sizing:border-box;width:100%;padding:.5rem;border:1px solid currentColor;border-radius:.25rem;background:transparent;color:inherit;font:inherit}input[type=checkbox],select{appearance:auto}\n"],
		dependencies: [
			{
				kind: "ngmodule",
				type: ReactiveFormsModule
			},
			{
				kind: "directive",
				type: i1$1.NgSelectOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1$1.ɵNgSelectMultipleOption,
				selector: "option",
				inputs: ["ngValue", "value"]
			},
			{
				kind: "directive",
				type: i1$1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$1.NumberValueAccessor,
				selector: "input[type=number]:not([ngNoCva])[formControlName],input[type=number]:not([ngNoCva])[formControl],input[type=number]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1$1.CheckboxControlValueAccessor,
				selector: "input[type=checkbox]:not([ngNoCva])[formControlName],input[type=checkbox]:not([ngNoCva])[formControl],input[type=checkbox]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1$1.SelectControlValueAccessor,
				selector: "select:not([multiple]):not([ngNoCva])[formControlName],select:not([multiple]):not([ngNoCva])[formControl],select:not([multiple]):not([ngNoCva])[ngModel]",
				inputs: ["compareWith"]
			},
			{
				kind: "directive",
				type: i1$1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$1.FormControlDirective,
				selector: "[formControl]",
				inputs: [
					"formControl",
					"disabled",
					"ngModel"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngForm"]
			},
			{
				kind: "directive",
				type: FormlyAttributes,
				selector: "[formlyAttributes]",
				inputs: ["formlyAttributes", "id"]
			},
			{
				kind: "pipe",
				type: FormlySelectOptionsPipe,
				name: "formlySelectOptions"
			},
			{
				kind: "pipe",
				type: AsyncPipe,
				name: "async"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: VanillaField,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-vanilla-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [
				ReactiveFormsModule,
				FormlyAttributes,
				FormlySelectOptionsPipe,
				AsyncPipe
			],
			template: `
    @switch (field.type) {
      @case ('checkbox') {
        <input
          type="checkbox"
          [formControl]="formControl"
          [formlyAttributes]="field"
          [attr.aria-describedby]="id + '-description ' + id + '-error'"
          [attr.aria-invalid]="showError"
        />
      }
      @case ('textarea') {
        <textarea
          [formControl]="formControl"
          [formlyAttributes]="field"
          [rows]="props.rows ?? 3"
          [attr.aria-describedby]="id + '-description ' + id + '-error'"
          [attr.aria-invalid]="showError"
        ></textarea>
      }
      @case ('select') {
        <select
          [formControl]="formControl"
          [formlyAttributes]="field"
          [attr.aria-describedby]="id + '-description ' + id + '-error'"
          [attr.aria-invalid]="showError"
        >
          <option [ngValue]="undefined">{{ props.placeholder ?? 'Select an option' }}</option>
          @for (option of props.options | formlySelectOptions: field | async; track $index) {
            @if (option.group) {
              <optgroup [label]="option.label">
                @for (child of option.group; track $index) {
                  <option
                    [ngValue]="child.value"
                    [disabled]="child.disabled"
                  >
                    {{ child.label }}
                  </option>
                }
              </optgroup>
            } @else {
              <option
                [ngValue]="option.value"
                [disabled]="option.disabled"
              >
                {{ option.label }}
              </option>
            }
          }
        </select>
      }
      @default {
        @if (props.type === 'number') {
          <input
            type="number"
            [formControl]="formControl"
            [formlyAttributes]="field"
            [attr.aria-describedby]="id + '-description ' + id + '-error'"
            [attr.aria-invalid]="showError"
          />
        } @else {
          <input
            [type]="props.type ?? 'text'"
            [formControl]="formControl"
            [formlyAttributes]="field"
            [attr.aria-describedby]="id + '-description ' + id + '-error'"
            [attr.aria-invalid]="showError"
          />
        }
      }
    }
  `,
			styles: ["input:not([type=checkbox]),textarea,select{display:block;box-sizing:border-box;width:100%;padding:.5rem;border:1px solid currentColor;border-radius:.25rem;background:transparent;color:inherit;font:inherit}input[type=checkbox],select{appearance:auto}\n"]
		}]
	}]
});
var VanillaFormField = class VanillaFormField extends FieldWrapper {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: VanillaFormField,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: VanillaFormField,
		isStandalone: true,
		selector: "core-vanilla-form-field",
		usesInheritance: true,
		ngImport: i0,
		template: `
    <label [for]="id"
      >{{ props.label }}
      @if (props.required) {
        <span aria-hidden="true">*</span>
      }
    </label>
    <ng-template #fieldComponent />
    <small [id]="id + '-description'">{{ props.description }}</small>
    <small
      aria-live="polite"
      [id]="id + '-error'"
    >
      @if (showError) {
        <formly-validation-message [field]="field" />
      }
    </small>
  `,
		isInline: true,
		styles: [":host{display:block;margin-block:.5rem}label{display:block;margin-bottom:.25rem}small{display:block}\n"],
		dependencies: [{
			kind: "component",
			type: FormlyValidationMessage,
			selector: "formly-validation-message",
			inputs: ["field"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: VanillaFormField,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-vanilla-form-field",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormlyValidationMessage],
			template: `
    <label [for]="id"
      >{{ props.label }}
      @if (props.required) {
        <span aria-hidden="true">*</span>
      }
    </label>
    <ng-template #fieldComponent />
    <small [id]="id + '-description'">{{ props.description }}</small>
    <small
      aria-live="polite"
      [id]="id + '-error'"
    >
      @if (showError) {
        <formly-validation-message [field]="field" />
      }
    </small>
  `,
			styles: [":host{display:block;margin-block:.5rem}label{display:block;margin-bottom:.25rem}small{display:block}\n"]
		}]
	}]
});
const VANILLA_LIBRARY_ID = "form-vanilla";
const key = createInputProperty({
	label: "Key",
	key: "key",
	dataType: "text"
});
const label = createInputProperty({
	label: "Label",
	key: "props.label",
	dataType: "text"
});
const description = createInputProperty({
	label: "Description",
	key: "props.description",
	dataType: "text"
});
const placeholder$1 = createInputProperty({
	label: "Placeholder",
	key: "props.placeholder",
	dataType: "text"
});
const expressions = createExpressionsProperty({
	label: "Expressions",
	key: "expressions"
});
const properties = [
	key,
	label,
	description,
	createBooleanProperty({
		label: "Disabled",
		key: "props.disabled"
	}),
	createBooleanProperty({
		label: "Hide",
		key: "hide"
	}),
	expressions
];
const validationConfig = {
	rules: [{
		name: "required",
		property: createBooleanProperty({
			label: "Required",
			key: "props.required"
		})
	}],
	displayProperties: [createBooleanProperty({
		label: "Show Validation",
		key: "validation.show"
	})]
};
const fieldTypes = [
	{
		name: "input",
		keyGenerationPrefix: "inp",
		displayName: "Input",
		description: "Text, email, password and more",
		materialSymbol: "text_fields",
		defaultConfig: { props: { label: "Input" } },
		properties: [
			...properties,
			placeholder$1,
			createSelectProperty({
				label: "Type",
				key: "props.type",
				options: [
					"text",
					"email",
					"password",
					"tel",
					"url",
					"date",
					"number"
				].map((value) => ({
					label: value,
					value
				}))
			})
		],
		validationConfig
	},
	{
		name: "number",
		keyGenerationPrefix: "num",
		displayName: "Number",
		description: "Numeric value with limits",
		materialSymbol: "numbers",
		defaultConfig: { props: {
			label: "Number",
			type: "number"
		} },
		properties: [...properties, placeholder$1],
		validationConfig: {
			...validationConfig,
			rules: [
				...validationConfig.rules,
				{
					name: "min",
					property: createInputProperty({
						label: "Min",
						key: "props.min",
						dataType: "number"
					})
				},
				{
					name: "max",
					property: createInputProperty({
						label: "Max",
						key: "props.max",
						dataType: "number"
					})
				}
			]
		}
	},
	{
		name: "textarea",
		keyGenerationPrefix: "txt",
		displayName: "Textarea",
		description: "Multi-line text entry",
		materialSymbol: "subject",
		defaultConfig: { props: { label: "Textarea" } },
		properties: [
			...properties,
			placeholder$1,
			createInputProperty({
				label: "Rows",
				key: "props.rows",
				dataType: "number"
			})
		],
		validationConfig
	},
	{
		name: "checkbox",
		keyGenerationPrefix: "chk",
		displayName: "Checkbox",
		description: "Single yes-or-no choice",
		materialSymbol: "check_box",
		defaultConfig: { props: { label: "Checkbox" } },
		properties,
		validationConfig
	},
	{
		name: "select",
		keyGenerationPrefix: "sel",
		displayName: "Select",
		description: "Dropdown list of choices",
		materialSymbol: "list",
		defaultConfig: { props: {
			label: "Select",
			options: [{
				label: "Option 1",
				value: "option1"
			}, {
				label: "Option 2",
				value: "option2"
			}]
		} },
		properties: [
			...properties,
			placeholder$1,
			createArrayProperty({
				label: "Options",
				key: "props.options",
				canAdd: true,
				useTableDialog: true,
				childProperty: createObjectProperty({
					isRemovable: true,
					childProperties: [
						createInputProperty({
							label: "Label",
							key: "label",
							dataType: "text",
							isRequired: true
						}),
						createInputProperty({
							label: "Value",
							key: "value",
							dataType: "text",
							isRequired: true
						}),
						createBooleanProperty({
							label: "Disabled",
							key: "disabled"
						})
					]
				})
			})
		],
		validationConfig
	}
];
const vanillaLibraryConfig = createLibrary({
	id: VANILLA_LIBRARY_ID,
	label: "Vanilla",
	enableFormUploadSchema: true,
	formTemplates: [],
	fieldCategoryOptions: [{
		displayName: "Form Controls",
		children: [...fieldTypes, ...nativeFieldTypes]
	}, {
		displayName: "Containers",
		children: [{
			name: "formly-group",
			displayName: "Group",
			description: "Related fields in one group",
			materialSymbol: "ad_group",
			isParent: true,
			disableKeyGeneration: true,
			defaultConfig: { fieldGroup: [] },
			properties: [key, expressions]
		}]
	}],
	configOptions: [nativeFieldConfig, {
		types: fieldTypes.map((type) => ({
			name: type.name,
			component: VanillaField,
			wrappers: ["form-field"],
			defaultOptions: type.name === "number" ? { props: { type: "number" } } : {}
		})),
		wrappers: [{
			name: "form-field",
			component: VanillaFormField
		}],
		validationMessages: [
			{
				name: "required",
				message: "This field is required."
			},
			{
				name: "min",
				message: "The value is too small."
			},
			{
				name: "max",
				message: "The value is too large."
			}
		]
	}]
});
var CoreLibraryService = class CoreLibraryService {
	libraryConfigs = inject(CORE_LIBRARY_CONFIGS);
	formTemplates = this.libraryConfigs.filter((config) => !config.hidden).flatMap((config) => config.formTemplates ?? []);
	libraryOptions = this.libraryConfigs.filter((cfg) => cfg.id !== "form-vanilla" && !cfg.hidden).map((cfg) => ({
		id: cfg.id,
		label: cfg.label
	}));
	activeLibrarySrc = signal(null, ...ngDevMode ? [{ debugName: "activeLibrarySrc" }] : /* istanbul ignore next */ []);
	activeLibrary = this.activeLibrarySrc.asReadonly();
	activeLibraryId = computed(() => this.activeLibrarySrc()?.id ?? null, ...ngDevMode ? [{ debugName: "activeLibraryId" }] : /* istanbul ignore next */ []);
	activeLibraryLabel = computed(() => this.activeLibrarySrc()?.label ?? null, ...ngDevMode ? [{ debugName: "activeLibraryLabel" }] : /* istanbul ignore next */ []);
	setActiveLibrary(libraryId) {
		if (!libraryId) {
			this.activeLibrarySrc.set(null);
			return;
		}
		const library = this.libraryConfigs.find(({ id }) => id === libraryId);
		if (!library) throw new Error(`Library config with id "${libraryId}" not found.`);
		this.activeLibrarySrc.set(library);
	}
	getLibraryLabel(libraryId) {
		const library = this.libraryConfigs.find((cfg) => cfg.id === libraryId);
		return library ? library.label : null;
	}
	getLibrary(libraryId) {
		return this.libraryConfigs.find((cfg) => cfg.id === libraryId) ?? null;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreLibraryService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreLibraryService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreLibraryService,
	decorators: [{ type: Injectable }]
});
var CoreFieldService = class CoreFieldService {
	editorConfig = inject(CORE_EDITOR_CONFIG);
	libraryConfigs = inject(CORE_LIBRARY_CONFIGS);
	libraryService = inject(CoreLibraryService);
	activeLibraryId = this.libraryService.activeLibraryId;
	libraryPropertyMap = {};
	basePresetStorageKey = "formly-studio-presets";
	defaultTypeOption = this.editorConfig.defaultTypeOption;
	activeFieldTypeMap = computed(() => {
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) return {};
		return this.libraryPropertyMap[activeLibraryId]?.fieldTypeMap ?? {};
	}, ...ngDevMode ? [{ debugName: "activeFieldTypeMap" }] : /* istanbul ignore next */ []);
	activeFieldCategoryOptions = computed(() => {
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) return [];
		return (this.libraryPropertyMap[activeLibraryId]?.fieldCategoryOptions ?? []).map((category) => ({
			...category,
			children: [...category.children].sort((first, second) => first.displayName.localeCompare(second.displayName, void 0, { sensitivity: "base" }))
		}));
	}, ...ngDevMode ? [{ debugName: "activeFieldCategoryOptions" }] : /* istanbul ignore next */ []);
	activeFieldTypeOptions = computed(() => {
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) return [];
		return this.libraryPropertyMap[activeLibraryId]?.fieldTypeOptions ?? [];
	}, ...ngDevMode ? [{ debugName: "activeFieldTypeOptions" }] : /* istanbul ignore next */ []);
	classNamePath = ["className"];
	fieldGroupClassNamePath = ["fieldGroupClassName"];
	filterPaths = [
		"key",
		"props.label",
		"templateOptions.label"
	];
	validationMessagesPath = ["validation", "messages"];
	fieldCategoryPresets = signal([], ...ngDevMode ? [{ debugName: "fieldCategoryPresets" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const activeLibraryId = this.activeLibraryId();
			if (!activeLibraryId) {
				this.fieldCategoryPresets.set([]);
				return;
			}
			this.updatePresetCategories(activeLibraryId);
		});
		this.libraryConfigs.forEach((config) => {
			const presetStorageKey = `${this.basePresetStorageKey}-${config.id}`;
			const fieldCategoryOptions = config.fieldCategoryOptions;
			const fieldTypeOptions = fieldCategoryOptions.flatMap((option) => option.children);
			const fieldTypeMap = fieldTypeOptions.reduce((acc, option) => {
				acc[option.name] = {
					...option,
					defaultConfig: {
						...option.defaultConfig,
						type: option.name
					}
				};
				return acc;
			}, {});
			this.libraryPropertyMap[config.id] = {
				presetStorageKey,
				fieldCategoryOptions,
				fieldTypeOptions,
				fieldTypeMap
			};
			this.setupInitialPresets(config.id);
		});
	}
	getTypeOptions(libraryId) {
		return this.libraryPropertyMap[libraryId]?.fieldTypeOptions ?? [];
	}
	getTypeOption(type) {
		return this.activeFieldTypeMap()[type];
	}
	getDefaultField(type, configId) {
		const { fieldTypeMap } = this.libraryPropertyMap[configId];
		return structuredClone(fieldTypeMap[type]?.defaultConfig ?? this.defaultTypeOption.defaultConfig);
	}
	getProperties(field) {
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) return [];
		const configProperties = this.libraryPropertyMap[activeLibraryId];
		const type = field.type;
		const wrappers = field.wrappers ?? [];
		const typeOption = this.getTypeOptionForProperties(type, configProperties);
		const wrapperOptions = typeOption.wrapperOptions ?? [];
		return [
			...this.getFieldProperties(type, configProperties),
			...wrapperOptions.length ? [createWrappersProperty({
				label: "Wrappers",
				key: "wrappers",
				options: wrapperOptions.map(({ name, label }) => ({
					label,
					value: name
				})),
				description: "Wrappers applied to the field. The selected order is preserved."
			})] : [],
			...this.getWrapperProperties(wrappers, typeOption)
		];
	}
	getValidationConfig(field) {
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) return;
		const configProperties = this.libraryPropertyMap[activeLibraryId];
		const type = field.type;
		return this.getFieldValidationConfig(type, configProperties);
	}
	getFieldIcon(field) {
		const type = field.type;
		return this.activeFieldTypeMap()[type]?.materialSymbol;
	}
	isFieldEqual(a, b) {
		const aType = a.type;
		const bType = b.type;
		const aWrappers = a.wrappers;
		const bWrappers = b.wrappers;
		return aType === bType && isEqual(aWrappers, bWrappers);
	}
	savePreset(displayName, field) {
		const activeLibraryId = this.activeLibraryId();
		if (!activeLibraryId) throw new Error("No active configuration is set.");
		const presetMap = this.getPresetMap(activeLibraryId);
		const type = field.type || "";
		const typePresets = presetMap[type] ?? [];
		typePresets.push({
			id: v4(),
			displayName,
			field,
			isRemovable: true
		});
		presetMap[type] = typePresets;
		this.storePresetMap(presetMap, activeLibraryId);
		this.updatePresetCategories(activeLibraryId);
	}
	getFieldProperties(type, configProperties) {
		return this.getTypeOptionForProperties(type, configProperties).properties ?? [];
	}
	getFieldValidationConfig(type, configProperties) {
		const { fieldTypeMap } = configProperties;
		return fieldTypeMap[type]?.validationConfig ?? this.defaultTypeOption.validationConfig;
	}
	getWrapperProperties(wrappers, typeOption) {
		const wrapperOptionMap = Object.fromEntries((typeOption.wrapperOptions ?? []).map((option) => [option.name, option]));
		return wrappers.flatMap((wrapper) => {
			const wrapperOption = wrapperOptionMap[wrapper];
			const childProperties = (wrapperOption?.properties ?? []).filter(isGroupChildProperty);
			if (!childProperties.length) return [];
			return [createGroupProperty({
				key: `wrapper-${wrapperOption.name}`,
				label: `${wrapperOption.label} Wrapper Options`,
				childProperties,
				description: `${wrapperOption.label} wrapper options.`
			})];
		});
	}
	getTypeOptionForProperties(type, configProperties) {
		return configProperties.fieldTypeMap[type] ?? this.defaultTypeOption;
	}
	setupInitialPresets(configId) {
		const { presetStorageKey, fieldCategoryOptions } = this.libraryPropertyMap[configId];
		if (localStorage.getItem(presetStorageKey)) return;
		const presetMapEntries = fieldCategoryOptions.flatMap((category) => {
			return category.children.map((typeOption) => {
				return [typeOption.name, typeOption.initialPresets ?? []];
			}).filter(([, presets]) => presets.length);
		});
		const presetMap = Object.fromEntries(presetMapEntries);
		this.storePresetMap(presetMap, configId);
	}
	updatePresetCategories(configId) {
		const customPresetsMap = this.getPresetMap(configId);
		const { fieldCategoryOptions } = this.libraryPropertyMap[configId];
		this.fieldCategoryPresets.set(fieldCategoryOptions.map((category) => ({
			displayName: category.displayName,
			children: category.children.flatMap((typeOption) => (customPresetsMap[typeOption.name] ?? []).map((preset) => ({
				...preset,
				typeOption
			}))).sort((first, second) => first.displayName.localeCompare(second.displayName, void 0, { sensitivity: "base" }))
		})));
	}
	getPresetMap(configId) {
		const { presetStorageKey } = this.libraryPropertyMap[configId];
		return JSON.parse(localStorage.getItem(presetStorageKey) || "{}");
	}
	storePresetMap(presetMap, configId) {
		const { presetStorageKey } = this.libraryPropertyMap[configId];
		localStorage.setItem(presetStorageKey, JSON.stringify(presetMap));
	}
	getKey(field) {
		return field["key"] || "";
	}
	getKeyPath(fieldInfo, fieldMap) {
		return fieldInfo.idPath.map((id) => fieldMap[id]["key"]).filter((key) => !!key).join(".");
	}
	getChildIds(fieldInfo) {
		return fieldInfo.childIds;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreFieldService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreFieldService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreFieldService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
function isGroupChildProperty(property) {
	return property.type === PropertyType.BOOLEAN || property.type === PropertyType.INPUT || property.type === PropertyType.SELECT;
}
var CoreFormService = class CoreFormService extends BuilderEngineService {
	libraryService = inject(CoreLibraryService);
	fieldService = inject(CoreFieldService);
	panelService = inject(PanelService);
	activeFormDisplayModeSrc = signal("form", ...ngDevMode ? [{ debugName: "activeFormDisplayModeSrc" }] : /* istanbul ignore next */ []);
	activeFormDisplayMode = this.activeFormDisplayModeSrc.asReadonly();
	isEditMode = computed(() => this.activeFormDisplayModeSrc() === "form", ...ngDevMode ? [{ debugName: "isEditMode" }] : /* istanbul ignore next */ []);
	mouseInsideIds = signal([], ...ngDevMode ? [{ debugName: "mouseInsideIds" }] : /* istanbul ignore next */ []);
	activeMouseInside = computed(() => {
		const ids = this.mouseInsideIds();
		return ids.length ? ids[ids.length - 1] : null;
	}, ...ngDevMode ? [{ debugName: "activeMouseInside" }] : /* istanbul ignore next */ []);
	activeSchema = computed(() => this.libraryService.activeLibrary()?.schema, ...ngDevMode ? [{ debugName: "activeSchema" }] : /* istanbul ignore next */ []);
	constructor() {
		const config = inject(CORE_EDITOR_CONFIG);
		super({
			...config,
			libraries: inject(CORE_LIBRARY_CONFIGS).map((library) => ({
				id: library.id,
				fieldTypes: library.fieldCategoryOptions.flatMap((category) => category.children),
				defaultField: config.defaultTypeOption.defaultConfig
			}))
		}, inject(CORE_FORM_STORE));
		this.formSelected$.pipe(takeUntilDestroyed()).subscribe((form) => {
			this.libraryService.setActiveLibrary(form?.libraryId ?? null);
			if (form) this.panelService.setActiveLHSPanel("fields");
		});
	}
	setMouseEnteredField(fieldId) {
		this.mouseInsideIds.set([...this.mouseInsideIds(), fieldId]);
	}
	setMouseLeftField(fieldId) {
		const ids = this.mouseInsideIds();
		const index = ids.lastIndexOf(fieldId);
		if (index !== -1) this.mouseInsideIds.set(ids.toSpliced(index, 1));
	}
	setActiveFormDisplayMode(mode) {
		this.activeFormDisplayModeSrc.set(mode);
	}
	getAddOptions(info) {
		return info.isParent ? this.fieldService.activeFieldCategoryOptions().map((category) => ({
			label: category.displayName,
			items: category.children.map((child) => ({
				label: child.displayName,
				type: child.name,
				command: () => this.addField(child.name, info.id)
			}))
		})) : [];
	}
	getReplaceOptions(info) {
		const currentType = this.getField(info.id)?.type;
		return this.fieldService.activeFieldCategoryOptions().map((category) => ({
			label: category.displayName,
			items: category.children.filter((child) => child.name !== currentType).map((child) => ({
				label: child.displayName,
				type: child.name,
				command: () => this.replaceField(child.name, info.id)
			}))
		})).filter((category) => category.items.length > 0);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreFormService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CoreFormService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CoreFormService,
	decorators: [{ type: Injectable }],
	ctorParameters: () => []
});
var CreateFormDialogService = class CreateFormDialogService {
	isOpenSrc = signal(false, ...ngDevMode ? [{ debugName: "isOpenSrc" }] : /* istanbul ignore next */ []);
	isOpen = this.isOpenSrc.asReadonly();
	parentIdSrc = signal(null, ...ngDevMode ? [{ debugName: "parentIdSrc" }] : /* istanbul ignore next */ []);
	parentId = this.parentIdSrc.asReadonly();
	open(parentId = null) {
		this.parentIdSrc.set(parentId);
		this.isOpenSrc.set(true);
	}
	close() {
		this.isOpenSrc.set(false);
		this.parentIdSrc.set(null);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CreateFormDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CreateFormDialogService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CreateFormDialogService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
const CORE_THEME = new InjectionToken("CODE_EDITOR_THEME");
var CodeEditor = class CodeEditor {
	text = model.required(...ngDevMode ? [{ debugName: "text" }] : /* istanbul ignore next */ []);
	placeholderText = input("", ...ngDevMode ? [{ debugName: "placeholderText" }] : /* istanbul ignore next */ []);
	mode = input("javascript", ...ngDevMode ? [{ debugName: "mode" }] : /* istanbul ignore next */ []);
	editable = input(true, {
		...ngDevMode ? { debugName: "editable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	editorRef = viewChild.required("editorRef", ...ngDevMode ? [{ debugName: "editorRef" }] : /* istanbul ignore next */ []);
	theme = inject(CORE_THEME, { optional: true });
	elementRef = inject(ElementRef);
	view;
	themeConfig = new Compartment();
	constructor() {
		effect(() => {
			const newText = this.text();
			const view = this.view;
			if (!view) return;
			if (view.state.doc.toString() !== newText) view.dispatch({ changes: {
				from: 0,
				to: view.state.doc.length,
				insert: newText
			} });
		});
		effect(() => {
			const isDarkMode = this.theme?.() === "dark";
			const view = this.view;
			if (!view) return;
			view.dispatch({ effects: this.themeConfig.reconfigure(isDarkMode ? vscodeDark : vscodeLight) });
		});
	}
	ngAfterViewInit() {
		this.view = new EditorView({
			doc: this.text(),
			extensions: [
				placeholder(this.placeholderText() || ""),
				basicSetup,
				...this.getModeExtensions(),
				...this.getEditableExtensions(),
				this.getValueChangeExtension(),
				this.themeConfig.of(this.theme?.() === "dark" ? vscodeDark : vscodeLight)
			],
			parent: this.elementRef.nativeElement
		});
	}
	ngOnDestroy() {
		this.view?.destroy();
	}
	getModeExtensions() {
		switch (this.mode()) {
			case "javascript": return [javascript()];
			case "json": return [json()];
			case "markdown": return [markdown({ base: markdownLanguage })];
		}
	}
	getEditableExtensions() {
		return !this.editable() ? [EditorState.readOnly.of(true), EditorView.editable.of(false)] : [];
	}
	getValueChangeExtension() {
		return EditorView.updateListener.of((update) => {
			if (update.docChanged) this.text.set(update.state.doc.toString());
		});
	}
	getValue() {
		return this.view?.state.doc.toString();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: CodeEditor,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: CodeEditor,
		isStandalone: true,
		selector: "core-code-editor",
		inputs: {
			text: {
				classPropertyName: "text",
				publicName: "text",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			placeholderText: {
				classPropertyName: "placeholderText",
				publicName: "placeholderText",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			mode: {
				classPropertyName: "mode",
				publicName: "mode",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			editable: {
				classPropertyName: "editable",
				publicName: "editable",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: { text: "textChange" },
		viewQueries: [{
			propertyName: "editorRef",
			first: true,
			predicate: ["editorRef"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: "",
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: CodeEditor,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-code-editor",
			changeDetection: ChangeDetectionStrategy.OnPush,
			template: ""
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		text: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "text",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["textChange"]
		}],
		placeholderText: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "placeholderText",
				required: false
			}]
		}],
		mode: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "mode",
				required: false
			}]
		}],
		editable: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "editable",
				required: false
			}]
		}],
		editorRef: [{
			type: i0.ViewChild,
			args: ["editorRef", { isSignal: true }]
		}]
	}
});
var FieldLabelPipe = class FieldLabelPipe {
	transform(label, key) {
		return `${label}${key ? ` (${key})` : ""}`;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldLabelPipe,
		deps: [],
		target: i0.ɵɵFactoryTarget.Pipe
	});
	static ɵpipe = i0.ɵɵngDeclarePipe({
		minVersion: "14.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldLabelPipe,
		isStandalone: true,
		name: "coreFieldLabel"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldLabelPipe,
	decorators: [{
		type: Pipe,
		args: [{ name: "coreFieldLabel" }]
	}]
});
var Filter = class Filter {
	value = model.required(...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	clearLabel = input("Clear filter", ...ngDevMode ? [{ debugName: "clearLabel" }] : /* istanbul ignore next */ []);
	clear = output();
	input = viewChild.required("input", ...ngDevMode ? [{ debugName: "input" }] : /* istanbul ignore next */ []);
	focus() {
		this.input().nativeElement.focus();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Filter,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: Filter,
		isStandalone: true,
		selector: "core-filter",
		inputs: {
			value: {
				classPropertyName: "value",
				publicName: "value",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			clearLabel: {
				classPropertyName: "clearLabel",
				publicName: "clearLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			value: "valueChange",
			clear: "clear"
		},
		viewQueries: [{
			propertyName: "input",
			first: true,
			predicate: ["input"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div class="flex min-w-0 items-center gap-2">
      <span class="inline-flex shrink-0 items-center">
        <i class="material-symbols-outlined"> search </i>
      </span>
      <input
        #input
        class="w-full truncate text-sm"
        coreInput
        type="text"
        placeholder="Filter items..."
        [(ngModel)]="value"
      />
      <span class="inline-flex shrink-0 items-center">
        <button
          coreButton
          severity="secondary"
          [attr.aria-label]="clearLabel()"
          (click)="clear.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            clear
          </i>
        </button>
      </span>
    </div>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Filter,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-filter",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule],
			template: `
    <div class="flex min-w-0 items-center gap-2">
      <span class="inline-flex shrink-0 items-center">
        <i class="material-symbols-outlined"> search </i>
      </span>
      <input
        #input
        class="w-full truncate text-sm"
        coreInput
        type="text"
        placeholder="Filter items..."
        [(ngModel)]="value"
      />
      <span class="inline-flex shrink-0 items-center">
        <button
          coreButton
          severity="secondary"
          [attr.aria-label]="clearLabel()"
          (click)="clear.emit()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            clear
          </i>
        </button>
      </span>
    </div>
  `
		}]
	}],
	propDecorators: {
		value: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "value",
				required: true
			}]
		}, {
			type: i0.Output,
			args: ["valueChange"]
		}],
		clearLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "clearLabel",
				required: false
			}]
		}],
		clear: [{
			type: i0.Output,
			args: ["clear"]
		}],
		input: [{
			type: i0.ViewChild,
			args: ["input", { isSignal: true }]
		}]
	}
});
var PanelHeader = class PanelHeader {
	header = input.required(...ngDevMode ? [{ debugName: "header" }] : /* istanbul ignore next */ []);
	subHeader = input.required(...ngDevMode ? [{ debugName: "subHeader" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PanelHeader,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: PanelHeader,
		isStandalone: true,
		selector: "core-panel-header",
		inputs: {
			header: {
				classPropertyName: "header",
				publicName: "header",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			},
			subHeader: {
				classPropertyName: "subHeader",
				publicName: "subHeader",
				isSignal: true,
				isRequired: true,
				transformFunction: null
			}
		},
		ngImport: i0,
		template: `
    <div
      class="flex min-h-(--panel-header-height) shrink-0 flex-wrap items-center justify-between gap-2 px-4 py-2"
    >
      <div class="flex grow flex-col">
        <h2 class="text-lg font-medium">{{ header() }}</h2>
        <span class="text-sm text-muted-color">{{ subHeader() }}</span>
      </div>
      <span class="inline-flex items-center gap-2">
        <ng-content select="[actions]" />
      </span>
    </div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PanelHeader,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-panel-header",
			changeDetection: ChangeDetectionStrategy.OnPush,
			standalone: true,
			template: `
    <div
      class="flex min-h-(--panel-header-height) shrink-0 flex-wrap items-center justify-between gap-2 px-4 py-2"
    >
      <div class="flex grow flex-col">
        <h2 class="text-lg font-medium">{{ header() }}</h2>
        <span class="text-sm text-muted-color">{{ subHeader() }}</span>
      </div>
      <span class="inline-flex items-center gap-2">
        <ng-content select="[actions]" />
      </span>
    </div>
  `
		}]
	}],
	propDecorators: {
		header: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "header",
				required: true
			}]
		}],
		subHeader: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "subHeader",
				required: true
			}]
		}]
	}
});
var Tooltip = class Tooltip {
	tooltip = inject(MatTooltip);
	constructor() {
		this.tooltip.showDelay = 500;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: Tooltip,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: Tooltip,
		isStandalone: true,
		selector: "[coreTooltip]",
		hostDirectives: [{
			directive: i1.MatTooltip,
			inputs: [
				"matTooltip",
				"coreTooltip",
				"matTooltipPosition",
				"tooltipPosition",
				"matTooltipShowDelay",
				"showDelay"
			]
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: Tooltip,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[coreTooltip]",
			hostDirectives: [{
				directive: MatTooltip,
				inputs: [
					"matTooltip: coreTooltip",
					"matTooltipPosition: tooltipPosition",
					"matTooltipShowDelay: showDelay"
				]
			}]
		}]
	}],
	ctorParameters: () => []
});
var MouseInsideService = class MouseInsideService {
	isMoudeInsideSrc = signal(false, ...ngDevMode ? [{ debugName: "isMoudeInsideSrc" }] : /* istanbul ignore next */ []);
	isMouseInside = this.isMoudeInsideSrc.asReadonly();
	setMouseInside(isInside) {
		this.isMoudeInsideSrc.set(isInside);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MouseInsideService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MouseInsideService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MouseInsideService,
	decorators: [{ type: Injectable }]
});
var TreeItem = class TreeItem {
	level = input(0, {
		...ngDevMode ? { debugName: "level" } : /* istanbul ignore next */ {},
		transform: numberAttribute
	});
	isTabRoot = input(false, {
		...ngDevMode ? { debugName: "isTabRoot" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	isExpanded = input(false, {
		...ngDevMode ? { debugName: "isExpanded" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	isParent = input(false, {
		...ngDevMode ? { debugName: "isParent" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	isActive = input(false, {
		...ngDevMode ? { debugName: "isActive" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	canInteract = input(true, {
		...ngDevMode ? { debugName: "canInteract" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	alwaysShowActions = input(false, {
		...ngDevMode ? { debugName: "alwaysShowActions" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	selectionLabel = input("", ...ngDevMode ? [{ debugName: "selectionLabel" }] : /* istanbul ignore next */ []);
	iconTile = input(false, {
		...ngDevMode ? { debugName: "iconTile" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	isSelected = input(false, ...ngDevMode ? [{ debugName: "isSelected" }] : /* istanbul ignore next */ []);
	selectionDisabled = input(false, ...ngDevMode ? [{ debugName: "selectionDisabled" }] : /* istanbul ignore next */ []);
	toggleClicked = output();
	selectionToggled = output();
	mouseInsideService = inject(MouseInsideService);
	isMouseInsideRoot = this.mouseInsideService.isMouseInside;
	linePaddingLeft = `calc(var(--spacing) * 3.75)`;
	isMouseInside = signal(false, ...ngDevMode ? [{ debugName: "isMouseInside" }] : /* istanbul ignore next */ []);
	lines = computed(() => Array.from({ length: this.level() }, (_, i) => i), ...ngDevMode ? [{ debugName: "lines" }] : /* istanbul ignore next */ []);
	paddingLeft = computed(() => `calc(((var(--spacing) * 4) * ${this.level()}) + var(--spacing))`, ...ngDevMode ? [{ debugName: "paddingLeft" }] : /* istanbul ignore next */ []);
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: TreeItem,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: TreeItem,
		isStandalone: true,
		selector: "core-tree-item",
		inputs: {
			level: {
				classPropertyName: "level",
				publicName: "level",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isTabRoot: {
				classPropertyName: "isTabRoot",
				publicName: "isTabRoot",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isExpanded: {
				classPropertyName: "isExpanded",
				publicName: "isExpanded",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isParent: {
				classPropertyName: "isParent",
				publicName: "isParent",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isActive: {
				classPropertyName: "isActive",
				publicName: "isActive",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			canInteract: {
				classPropertyName: "canInteract",
				publicName: "canInteract",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			alwaysShowActions: {
				classPropertyName: "alwaysShowActions",
				publicName: "alwaysShowActions",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionLabel: {
				classPropertyName: "selectionLabel",
				publicName: "selectionLabel",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			iconTile: {
				classPropertyName: "iconTile",
				publicName: "iconTile",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			isSelected: {
				classPropertyName: "isSelected",
				publicName: "isSelected",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			},
			selectionDisabled: {
				classPropertyName: "selectionDisabled",
				publicName: "selectionDisabled",
				isSignal: true,
				isRequired: false,
				transformFunction: null
			}
		},
		outputs: {
			toggleClicked: "toggleClicked",
			selectionToggled: "selectionToggled"
		},
		host: {
			listeners: {
				"mouseenter": "isMouseInside.set(true)",
				"mouseleave": "isMouseInside.set(false)"
			},
			properties: {
				"class.py-2": "iconTile()",
				"class.py-1.5": "!iconTile()",
				"class.bg-primary/20": "isActive()",
				"class.bg-content-hover-background": "!isActive() && alwaysShowActions()",
				"class.hover:bg-content-hover-background": "!isActive() && canInteract()",
				"class.cursor-pointer": "canInteract()",
				"tabindex": "isTabRoot() ? 0 : -1"
			},
			classAttribute: "group/tree-item relative flex items-center rounded-lg transition-colors select-none"
		},
		ngImport: i0,
		template: `
    <span
      class="pointer-events-none absolute inline-flex h-full pl-1"
      [class.opacity-100]="isMouseInsideRoot()"
      [class.opacity-0]="!isMouseInsideRoot()"
    >
      @for (lineIndex of lines(); track $index) {
        <span
          class="inline-block h-full w-0 border-r border-primary/20"
          [style.paddingLeft]="linePaddingLeft"
        ></span>
      }
    </span>

    @if (selectionLabel()) {
      <button
        coreButton
        type="button"
        text
        class="touch-actions-visible absolute inset-y-0 z-10 rounded-l-lg opacity-0 group-focus-within/tree-item:opacity-100"
        [class.w-14]="iconTile()"
        [class.w-10]="!iconTile()"
        [style.left]="'calc(var(--spacing) * 4 * ' + level() + ')'"
        [class.opacity-100]="isMouseInside() || isSelected()"
        [attr.aria-label]="selectionLabel()"
        [attr.aria-pressed]="isSelected()"
        [disabled]="selectionDisabled()"
        (click)="$event.preventDefault(); $event.stopPropagation(); selectionToggled.emit()"
      >
        <i
          coreButtonIcon
          class="material-symbols-outlined"
          aria-hidden="true"
        >
          {{ isSelected() ? 'check_box' : 'check_box_outline_blank' }}
        </i>
      </button>
    }

    <div
      class="flex min-w-0 grow items-center justify-between gap-2 pr-1"
      [style.paddingLeft]="paddingLeft()"
    >
      <div
        class="flex min-w-0 items-center overflow-hidden"
        [class.gap-3]="iconTile()"
        [class.gap-2]="!iconTile()"
      >
        @if (selectionLabel()) {
          <span
            class="pointer-events-none flex shrink-0 items-center justify-center"
            aria-hidden="true"
            [class]="iconTile() ? 'size-12 rounded-xl border border-surface bg-emphasis' : 'w-8'"
          >
            <span
              class="tree-item-icon flex group-focus-within/tree-item:invisible"
              [class.invisible]="isMouseInside() || isSelected()"
            >
              <ng-content select="[itemIcon]" />
            </span>
          </span>
        }
        @if (isParent() || !selectionLabel()) {
          <button
            coreButton
            text
            class="size-8 shrink-0"
            rounded
            aria-label="Toggle children"
            [class.invisible]="!isParent()"
            [class.disabled]="!isParent()"
            (click)="toggleClicked.emit($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              style="font-size: 24px;"
              [class.rotate-90]="isExpanded()"
            >
              chevron_right
            </i>
          </button>
        }
        <ng-content />
      </div>

      <span
        class="touch-actions-visible inline-flex shrink-0 gap-2 opacity-0 focus-within:opacity-100"
        [class.opacity-100]="isMouseInside() || alwaysShowActions()"
      >
        <ng-content select="[actions]" />
      </span>
    </div>
  `,
		isInline: true,
		styles: ["@media(hover:none),(pointer:coarse){.tree-item-icon{visibility:hidden}}\n"],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: TreeItem,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-tree-item",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [],
			host: {
				class: "group/tree-item relative flex items-center rounded-lg transition-colors select-none",
				"[class.py-2]": "iconTile()",
				"[class.py-1.5]": "!iconTile()",
				"[class.bg-primary/20]": "isActive()",
				"[class.bg-content-hover-background]": "!isActive() && alwaysShowActions()",
				"[class.hover:bg-content-hover-background]": "!isActive() && canInteract()",
				"[class.cursor-pointer]": "canInteract()",
				"[tabindex]": "isTabRoot() ? 0 : -1",
				"(mouseenter)": "isMouseInside.set(true)",
				"(mouseleave)": "isMouseInside.set(false)"
			},
			template: `
    <span
      class="pointer-events-none absolute inline-flex h-full pl-1"
      [class.opacity-100]="isMouseInsideRoot()"
      [class.opacity-0]="!isMouseInsideRoot()"
    >
      @for (lineIndex of lines(); track $index) {
        <span
          class="inline-block h-full w-0 border-r border-primary/20"
          [style.paddingLeft]="linePaddingLeft"
        ></span>
      }
    </span>

    @if (selectionLabel()) {
      <button
        coreButton
        type="button"
        text
        class="touch-actions-visible absolute inset-y-0 z-10 rounded-l-lg opacity-0 group-focus-within/tree-item:opacity-100"
        [class.w-14]="iconTile()"
        [class.w-10]="!iconTile()"
        [style.left]="'calc(var(--spacing) * 4 * ' + level() + ')'"
        [class.opacity-100]="isMouseInside() || isSelected()"
        [attr.aria-label]="selectionLabel()"
        [attr.aria-pressed]="isSelected()"
        [disabled]="selectionDisabled()"
        (click)="$event.preventDefault(); $event.stopPropagation(); selectionToggled.emit()"
      >
        <i
          coreButtonIcon
          class="material-symbols-outlined"
          aria-hidden="true"
        >
          {{ isSelected() ? 'check_box' : 'check_box_outline_blank' }}
        </i>
      </button>
    }

    <div
      class="flex min-w-0 grow items-center justify-between gap-2 pr-1"
      [style.paddingLeft]="paddingLeft()"
    >
      <div
        class="flex min-w-0 items-center overflow-hidden"
        [class.gap-3]="iconTile()"
        [class.gap-2]="!iconTile()"
      >
        @if (selectionLabel()) {
          <span
            class="pointer-events-none flex shrink-0 items-center justify-center"
            aria-hidden="true"
            [class]="iconTile() ? 'size-12 rounded-xl border border-surface bg-emphasis' : 'w-8'"
          >
            <span
              class="tree-item-icon flex group-focus-within/tree-item:invisible"
              [class.invisible]="isMouseInside() || isSelected()"
            >
              <ng-content select="[itemIcon]" />
            </span>
          </span>
        }
        @if (isParent() || !selectionLabel()) {
          <button
            coreButton
            text
            class="size-8 shrink-0"
            rounded
            aria-label="Toggle children"
            [class.invisible]="!isParent()"
            [class.disabled]="!isParent()"
            (click)="toggleClicked.emit($event)"
          >
            <i
              coreButtonIcon
              class="material-symbols-outlined"
              style="font-size: 24px;"
              [class.rotate-90]="isExpanded()"
            >
              chevron_right
            </i>
          </button>
        }
        <ng-content />
      </div>

      <span
        class="touch-actions-visible inline-flex shrink-0 gap-2 opacity-0 focus-within:opacity-100"
        [class.opacity-100]="isMouseInside() || alwaysShowActions()"
      >
        <ng-content select="[actions]" />
      </span>
    </div>
  `,
			styles: ["@media(hover:none),(pointer:coarse){.tree-item-icon{visibility:hidden}}\n"]
		}]
	}],
	propDecorators: {
		level: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "level",
				required: false
			}]
		}],
		isTabRoot: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isTabRoot",
				required: false
			}]
		}],
		isExpanded: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isExpanded",
				required: false
			}]
		}],
		isParent: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isParent",
				required: false
			}]
		}],
		isActive: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isActive",
				required: false
			}]
		}],
		canInteract: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "canInteract",
				required: false
			}]
		}],
		alwaysShowActions: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "alwaysShowActions",
				required: false
			}]
		}],
		selectionLabel: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionLabel",
				required: false
			}]
		}],
		iconTile: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "iconTile",
				required: false
			}]
		}],
		isSelected: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "isSelected",
				required: false
			}]
		}],
		selectionDisabled: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "selectionDisabled",
				required: false
			}]
		}],
		toggleClicked: [{
			type: i0.Output,
			args: ["toggleClicked"]
		}],
		selectionToggled: [{
			type: i0.Output,
			args: ["selectionToggled"]
		}]
	}
});
var JSONContent = class JSONContent {
	editable = input(true, {
		...ngDevMode ? { debugName: "editable" } : /* istanbul ignore next */ {},
		transform: booleanAttribute
	});
	control = inject(NgControl, { self: true });
	onChange;
	onTouched;
	value = signal("", ...ngDevMode ? [{ debugName: "value" }] : /* istanbul ignore next */ []);
	validationErrors;
	constructor() {
		this.control.valueAccessor = this;
		if (!this.control.statusChanges) throw new Error("Unable to access statusChanges");
		this.validationErrors = toSignal(this.control.statusChanges.pipe(map((status) => {
			if (status === "INVALID" && !isEmpty(this.control.errors)) return Object.entries(this.control.errors).flatMap(([errorKey, errorValue]) => {
				if (errorKey === "required") return {
					label: "REQUIRED",
					messages: ["JSON is required"]
				};
				if (Array.isArray(errorValue)) return errorValue;
				return {
					label: errorKey.toUpperCase(),
					messages: ["JSON is not valid"]
				};
			});
			return [];
		})), { initialValue: [] });
		this.control.valueChanges?.subscribe((v) => this.value.set(v));
	}
	writeValue(val) {
		this.value.set(val);
	}
	registerOnChange(fn) {
		this.onChange = fn;
	}
	registerOnTouched(fn) {
		this.onTouched = fn;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: JSONContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: JSONContent,
		isStandalone: true,
		selector: "core-json-content",
		inputs: { editable: {
			classPropertyName: "editable",
			publicName: "editable",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "relative block w-full" },
		ngImport: i0,
		template: `
    <core-code-editor
      mode="json"
      [editable]="editable()"
      [text]="value()"
      (textChange)="onChange($event)"
      (blur)="onTouched()"
    />
    @if (editable()) {
      <div class="absolute right-4 bottom-4 flex flex-col gap-2">
        @for (error of validationErrors(); track $index) {
          <div
            role="alert"
            class="core-message"
            severity="error"
          >
            <i class="material-symbols-outlined">error</i>

            <div>
              <div>{{ error.label }}</div>
              @for (message of error.messages; track $index) {
                <div>{{ message }}</div>
              }
            </div>
          </div>
        } @empty {
          <div
            role="status"
            class="core-message"
            severity="success"
          >
            <i class="material-symbols-outlined">check</i>

            JSON is valid
          </div>
        }
      </div>
    }
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: CodeEditor,
			selector: "core-code-editor",
			inputs: [
				"text",
				"placeholderText",
				"mode",
				"editable"
			],
			outputs: ["textChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: JSONContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-json-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [CodeEditor],
			host: { class: "relative block w-full" },
			template: `
    <core-code-editor
      mode="json"
      [editable]="editable()"
      [text]="value()"
      (textChange)="onChange($event)"
      (blur)="onTouched()"
    />
    @if (editable()) {
      <div class="absolute right-4 bottom-4 flex flex-col gap-2">
        @for (error of validationErrors(); track $index) {
          <div
            role="alert"
            class="core-message"
            severity="error"
          >
            <i class="material-symbols-outlined">error</i>

            <div>
              <div>{{ error.label }}</div>
              @for (message of error.messages; track $index) {
                <div>{{ message }}</div>
              }
            </div>
          </div>
        } @empty {
          <div
            role="status"
            class="core-message"
            severity="success"
          >
            <i class="material-symbols-outlined">check</i>

            JSON is valid
          </div>
        }
      </div>
    }
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { editable: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "editable",
			required: false
		}]
	}] }
});
var JSONFormatValidator = class JSONFormatValidator {
	validate(control) {
		if (control.value) try {
			JSON.parse(control.value);
			return null;
		} catch {
			return { jsonFormat: this.getValidationErrors() };
		}
		return null;
	}
	getValidationErrors() {
		return [{
			label: "Format",
			messages: ["JSON format is not valid"]
		}];
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: JSONFormatValidator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: JSONFormatValidator,
		isStandalone: true,
		selector: "[coreJsonFormat]",
		providers: [{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => JSONFormatValidator),
			multi: true
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: JSONFormatValidator,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[coreJsonFormat]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => JSONFormatValidator),
				multi: true
			}]
		}]
	}]
});
var JSONSchemaValidator = class JSONSchemaValidator {
	jsonSchema = input(void 0, {
		...ngDevMode ? { debugName: "jsonSchema" } : /* istanbul ignore next */ {},
		alias: "coreJsonSchema"
	});
	validate(control) {
		const schema = this.jsonSchema();
		if (!schema || !control.value) return null;
		try {
			const parseResult = schema.safeParse(JSON.parse(control.value));
			if (parseResult.success) return null;
			const errors = this.getValidationErrors(parseResult.error);
			return errors.length ? { jsonSchema: errors } : null;
		} catch (error) {
			console.warn("Error validating schema", error);
			return null;
		}
	}
	getValidationErrors(error) {
		const treeifiedError = treeifyError(error);
		return this.flattenTreeifiedErrors(treeifiedError).filter((e) => e.message !== "ignore").reduce((acc, err) => {
			if (!acc.find((e) => e.path === err.path)) acc.push(err);
			return acc;
		}, []).map((err) => ({
			label: "Schema",
			messages: [err.path, err.message]
		}));
	}
	flattenTreeifiedErrors(tree, parentPath = "") {
		const result = [];
		if (tree.errors && tree.errors.length > 0) for (const message of tree.errors) result.push({
			path: parentPath,
			message
		});
		if (tree.properties) for (const [key, childTree] of Object.entries(tree.properties)) {
			const fullPath = parentPath ? `${parentPath}.${key}` : key;
			result.push(...this.flattenTreeifiedErrors(childTree, fullPath));
		}
		if (tree.items) tree.items.forEach((itemTree, index) => {
			if (itemTree) {
				const fullPath = parentPath ? `${parentPath}.${index}` : `${index}`;
				result.push(...this.flattenTreeifiedErrors(itemTree, fullPath));
			}
		});
		return result;
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: JSONSchemaValidator,
		deps: [],
		target: i0.ɵɵFactoryTarget.Directive
	});
	static ɵdir = i0.ɵɵngDeclareDirective({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: JSONSchemaValidator,
		isStandalone: true,
		selector: "[coreJsonSchema]",
		inputs: { jsonSchema: {
			classPropertyName: "jsonSchema",
			publicName: "coreJsonSchema",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [{
			provide: NG_VALIDATORS,
			useExisting: forwardRef(() => JSONSchemaValidator),
			multi: true
		}],
		ngImport: i0
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: JSONSchemaValidator,
	decorators: [{
		type: Directive,
		args: [{
			selector: "[coreJsonSchema]",
			providers: [{
				provide: NG_VALIDATORS,
				useExisting: forwardRef(() => JSONSchemaValidator),
				multi: true
			}]
		}]
	}],
	propDecorators: { jsonSchema: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "coreJsonSchema",
			required: false
		}]
	}] }
});
const CORE_BUILDER_FORM = new InjectionToken("CoreBuilderForm");
var ReadonlyWrapper = class ReadonlyWrapper extends FieldWrapper {
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ReadonlyWrapper,
		deps: null,
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "14.0.0",
		version: "22.2.3",
		type: ReadonlyWrapper,
		isStandalone: true,
		selector: "core-readonly-wrapper",
		host: { properties: {
			"class.contents": "!props.readonly",
			"class.block": "props.readonly",
			"class.opacity-50": "props.readonly"
		} },
		usesInheritance: true,
		ngImport: i0,
		template: `<ng-template #fieldComponent />`,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ReadonlyWrapper,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-readonly-wrapper",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: {
				"[class.contents]": "!props.readonly",
				"[class.block]": "props.readonly",
				"[class.opacity-50]": "props.readonly"
			},
			template: `<ng-template #fieldComponent />`
		}]
	}]
});
var FormlyConfigService = class FormlyConfigService {
	libraryService = inject(CoreLibraryService);
	formlyConfig = inject(FormlyConfig);
	parentFormlyConfigs = inject(FORMLY_CONFIG, {
		optional: true,
		skipSelf: true
	});
	formlyConfigs = inject(FORMLY_CONFIG, { optional: true });
	isBuilderForm = inject(CORE_BUILDER_FORM, { optional: true }) ?? false;
	loadedLibraryId = null;
	loadLibraryConfigOptions() {
		const library = this.libraryService.activeLibrary();
		const libraryId = library?.id ?? null;
		if (this.loadedLibraryId === libraryId) return;
		this.loadedLibraryId = libraryId;
		Object.assign(this.formlyConfig, new FormlyConfig());
		this.parentFormlyConfigs?.forEach((config) => this.formlyConfig.addConfig(config));
		this.formlyConfigs?.forEach((config) => this.formlyConfig.addConfig(config));
		for (const option of library?.configOptions ?? []) this.formlyConfig.addConfig(option);
		if (this.isBuilderForm) for (const option of library?.builderConfigOptions ?? []) this.formlyConfig.addConfig(option);
		this.formlyConfig.addConfig(withValidationExpressions());
		this.formlyConfig.addConfig({
			wrappers: [{
				name: "core-readonly",
				component: ReadonlyWrapper
			}],
			extensions: [{
				name: "core-readonly",
				extension: { postPopulate(field) {
					if (!field.parent || field.wrappers?.includes("core-readonly")) return;
					const wrappers = field.wrappers ??= [];
					wrappers.splice(wrappers.indexOf("core-field") + 1, 0, "core-readonly");
				} }
			}]
		});
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyConfigService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormlyConfigService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormlyConfigService,
	decorators: [{ type: Injectable }]
});
const PREVIEW_DEVICE_WIDTHS = {
	auto: null,
	sm: 640,
	md: 768,
	lg: 1024,
	xl: 1280
};
const MIN_CUSTOM_WIDTH = 240;
const MAX_CUSTOM_WIDTH = 3840;
var PreviewViewportService = class PreviewViewportService {
	presetSrc = signal("auto", ...ngDevMode ? [{ debugName: "presetSrc" }] : /* istanbul ignore next */ []);
	customWidthSrc = signal(PREVIEW_DEVICE_WIDTHS.sm, ...ngDevMode ? [{ debugName: "customWidthSrc" }] : /* istanbul ignore next */ []);
	preset = this.presetSrc.asReadonly();
	customWidth = this.customWidthSrc.asReadonly();
	targetWidth = computed(() => {
		const preset = this.preset();
		return preset === "custom" ? this.customWidth() : PREVIEW_DEVICE_WIDTHS[preset];
	}, ...ngDevMode ? [{ debugName: "targetWidth" }] : /* istanbul ignore next */ []);
	selectPreset(preset) {
		this.presetSrc.set(preset);
	}
	setCustomWidth(width) {
		if (!Number.isFinite(width)) return;
		this.customWidthSrc.set(Math.round(Math.min(MAX_CUSTOM_WIDTH, Math.max(MIN_CUSTOM_WIDTH, width))));
		this.presetSrc.set("custom");
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PreviewViewportService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PreviewViewportService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PreviewViewportService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var FormPreviewRenderer = class FormPreviewRenderer {
	formFields = input([], ...ngDevMode ? [{ debugName: "formFields" }] : /* istanbul ignore next */ []);
	formService = inject(CoreFormService);
	formlyConfig = inject(FormlyConfigService);
	clonedFormFields = computed(() => structuredClone(this.formFields()), ...ngDevMode ? [{ debugName: "clonedFormFields" }] : /* istanbul ignore next */ []);
	model = computed(() => structuredClone(this.formService.activeModel()), ...ngDevMode ? [{ debugName: "model" }] : /* istanbul ignore next */ []);
	formGroup = new FormGroup({});
	options = {};
	constructor() {
		effect(() => {
			this.formFields();
			this.formlyConfig.loadLibraryConfigOptions();
			this.formGroup = new FormGroup({});
			this.options = {};
		});
	}
	onFormModelChanged(model) {
		this.formService.setActiveModel(model);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormPreviewRenderer,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.1.0",
		version: "22.2.3",
		type: FormPreviewRenderer,
		isStandalone: true,
		selector: "core-form-preview-renderer",
		inputs: { formFields: {
			classPropertyName: "formFields",
			publicName: "formFields",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		providers: [
			provideFormlyCore(),
			FormlyConfigService,
			{
				provide: CORE_BUILDER_FORM,
				useValue: false
			}
		],
		ngImport: i0,
		template: `
    <formly-form
      [fields]="clonedFormFields()"
      [model]="model()"
      [form]="formGroup"
      [options]="options"
      (modelChange)="onFormModelChanged($event)"
    />
  `,
		isInline: true,
		dependencies: [{
			kind: "component",
			type: FormlyForm,
			selector: "formly-form",
			inputs: [
				"form",
				"model",
				"fields",
				"options"
			],
			outputs: ["modelChange", "fieldChange"]
		}],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormPreviewRenderer,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-preview-renderer",
			changeDetection: ChangeDetectionStrategy.OnPush,
			providers: [
				provideFormlyCore(),
				FormlyConfigService,
				{
					provide: CORE_BUILDER_FORM,
					useValue: false
				}
			],
			imports: [FormlyForm],
			template: `
    <formly-form
      [fields]="clonedFormFields()"
      [model]="model()"
      [form]="formGroup"
      [options]="options"
      (modelChange)="onFormModelChanged($event)"
    />
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: { formFields: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "formFields",
			required: false
		}]
	}] }
});
var FormPreviewContent = class FormPreviewContent {
	formFields = input([], ...ngDevMode ? [{ debugName: "formFields" }] : /* istanbul ignore next */ []);
	viewport = inject(PreviewViewportService);
	applicationRef = inject(ApplicationRef);
	environmentInjector = inject(EnvironmentInjector);
	destroyRef = inject(DestroyRef);
	document = inject(DOCUMENT$1);
	rendererFactory = inject(RendererFactory2);
	canvas = viewChild.required("canvas", ...ngDevMode ? [{ debugName: "canvas" }] : /* istanbul ignore next */ []);
	previewFrame = viewChild.required("previewFrame", ...ngDevMode ? [{ debugName: "previewFrame" }] : /* istanbul ignore next */ []);
	rendererRef = null;
	frameInjector = null;
	resizeObserver = null;
	styleObserver = null;
	frameStyles = /* @__PURE__ */ new Map();
	canvasWidth = signal(0, ...ngDevMode ? [{ debugName: "canvasWidth" }] : /* istanbul ignore next */ []);
	canvasHeight = signal(0, ...ngDevMode ? [{ debugName: "canvasHeight" }] : /* istanbul ignore next */ []);
	scale = computed(() => {
		const targetWidth = this.viewport.targetWidth();
		if (targetWidth === null) return 1;
		const canvasWidth = this.canvasWidth();
		return canvasWidth > 0 ? Math.min(1, canvasWidth / targetWidth) : 1;
	}, ...ngDevMode ? [{ debugName: "scale" }] : /* istanbul ignore next */ []);
	scaledWidth = computed(() => {
		const targetWidth = this.viewport.targetWidth();
		return targetWidth ? `${targetWidth * this.scale()}px` : "auto";
	}, ...ngDevMode ? [{ debugName: "scaledWidth" }] : /* istanbul ignore next */ []);
	frameWidth = computed(() => {
		const targetWidth = this.viewport.targetWidth();
		return targetWidth ? `${targetWidth}px` : "100%";
	}, ...ngDevMode ? [{ debugName: "frameWidth" }] : /* istanbul ignore next */ []);
	frameHeight = computed(() => {
		const scale = this.scale();
		return scale > 0 ? this.canvasHeight() / scale : 0;
	}, ...ngDevMode ? [{ debugName: "frameHeight" }] : /* istanbul ignore next */ []);
	constructor() {
		effect(() => {
			const fields = this.formFields();
			this.rendererRef?.setInput("formFields", fields);
		});
		afterNextRender(() => this.observeCanvas());
		this.destroyRef.onDestroy(() => this.destroyFrame());
	}
	async initializeFrame() {
		this.destroyRenderer();
		const frameDocument = this.previewFrame().nativeElement.contentDocument;
		if (!frameDocument) return;
		frameDocument.open();
		frameDocument.write("<!doctype html><html><head></head><body></body></html>");
		frameDocument.close();
		const base = frameDocument.createElement("base");
		base.href = this.document.baseURI;
		frameDocument.head.append(base);
		this.syncFrameAppearance(frameDocument);
		this.syncFrameStyles(frameDocument);
		this.observeStyles(frameDocument);
		await Promise.all(Array.from(frameDocument.querySelectorAll("link[rel=\"stylesheet\"]")).map((link) => link.sheet ? Promise.resolve() : new Promise((resolve) => {
			link.addEventListener("load", () => resolve(), { once: true });
			link.addEventListener("error", () => resolve(), { once: true });
		})));
		if (this.destroyRef.destroyed || this.previewFrame().nativeElement.contentDocument !== frameDocument) return;
		const hostElement = frameDocument.createElement("core-form-preview-renderer");
		frameDocument.body.append(hostElement);
		this.frameInjector = createEnvironmentInjector([
			{
				provide: DOCUMENT$1,
				useValue: frameDocument
			},
			{
				provide: RendererFactory2,
				useValue: this.createFrameRendererFactory(frameDocument)
			},
			Overlay,
			OverlayContainer,
			OverlayPositionBuilder,
			OverlayKeyboardDispatcher,
			OverlayOutsideClickDispatcher,
			ScrollStrategyOptions,
			ScrollDispatcher,
			ViewportRuler
		], this.environmentInjector);
		const rendererRef = createComponent(FormPreviewRenderer, {
			environmentInjector: this.frameInjector,
			hostElement
		});
		this.applicationRef.attachView(rendererRef.hostView);
		this.rendererRef = rendererRef;
		rendererRef.setInput("formFields", this.formFields());
	}
	createFrameRendererFactory(document) {
		const factory = Object.create(this.rendererFactory);
		factory.createRenderer = (host, type) => {
			const parentRenderer = this.rendererFactory.createRenderer(host, type);
			const renderer = Object.create(parentRenderer);
			renderer.listen = (target, ...args) => {
				if (target === "window") target = document.defaultView;
				else if (target === "document") target = document;
				else if (target === "body") target = document.body;
				return parentRenderer.listen(target, ...args);
			};
			return renderer;
		};
		return factory;
	}
	observeCanvas() {
		this.resizeObserver = new ResizeObserver(([entry]) => {
			this.canvasWidth.set(entry.contentRect.width);
			this.canvasHeight.set(entry.contentRect.height);
		});
		this.resizeObserver.observe(this.canvas().nativeElement);
	}
	observeStyles(frameDocument) {
		this.styleObserver?.disconnect();
		this.styleObserver = new MutationObserver(() => {
			this.syncFrameAppearance(frameDocument);
			this.syncFrameStyles(frameDocument);
		});
		this.styleObserver.observe(this.document.head, {
			childList: true,
			subtree: true,
			characterData: true
		});
	}
	syncFrameAppearance(frameDocument) {
		frameDocument.documentElement.className = this.document.documentElement.className;
		frameDocument.documentElement.style.cssText = this.document.documentElement.style.cssText;
	}
	syncFrameStyles(frameDocument) {
		const sources = Array.from(this.document.head.querySelectorAll("link[rel=\"stylesheet\"], style"));
		for (const [source, copy] of this.frameStyles) if (!sources.includes(source)) {
			copy.remove();
			this.frameStyles.delete(source);
		}
		let previous = null;
		for (const source of sources) {
			let copy = this.frameStyles.get(source);
			if (!copy || !copy.isEqualNode(source)) {
				const updated = source.cloneNode(true);
				copy?.replaceWith(updated);
				copy = updated;
				this.frameStyles.set(source, copy);
			}
			if (copy.parentElement !== frameDocument.head || copy.previousElementSibling !== previous) frameDocument.head.insertBefore(copy, previous ? previous.nextSibling : frameDocument.head.firstChild);
			previous = copy;
		}
	}
	destroyRenderer() {
		const rendererRef = this.rendererRef;
		if (rendererRef) {
			this.applicationRef.detachView(rendererRef.hostView);
			rendererRef.destroy();
			this.rendererRef = null;
		}
		this.frameInjector?.destroy();
		this.frameInjector = null;
		this.frameStyles.clear();
	}
	destroyFrame() {
		this.resizeObserver?.disconnect();
		this.styleObserver?.disconnect();
		this.destroyRenderer();
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FormPreviewContent,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.2.0",
		version: "22.2.3",
		type: FormPreviewContent,
		isStandalone: true,
		selector: "core-form-preview-content",
		inputs: { formFields: {
			classPropertyName: "formFields",
			publicName: "formFields",
			isSignal: true,
			isRequired: false,
			transformFunction: null
		} },
		host: { classAttribute: "flex h-full w-full min-h-0 flex-col overflow-hidden" },
		viewQueries: [{
			propertyName: "canvas",
			first: true,
			predicate: ["canvas"],
			descendants: true,
			isSignal: true
		}, {
			propertyName: "previewFrame",
			first: true,
			predicate: ["previewFrame"],
			descendants: true,
			isSignal: true
		}],
		ngImport: i0,
		template: `
    <div
      #canvas
      class="min-h-0 grow overflow-hidden px-4 pb-4"
    >
      <div
        class="relative mx-auto overflow-hidden"
        [style.width]="scaledWidth()"
        [style.height.px]="canvasHeight()"
      >
        <iframe
          #previewFrame
          class="block origin-top-left"
          title="Responsive form preview"
          [style.width]="frameWidth()"
          [style.height.px]="frameHeight()"
          [style.transform]="'scale(' + scale() + ')'"
          (load)="initializeFrame()"
        ></iframe>
      </div>
    </div>
  `,
		isInline: true,
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FormPreviewContent,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-form-preview-content",
			changeDetection: ChangeDetectionStrategy.OnPush,
			host: { class: "flex h-full w-full min-h-0 flex-col overflow-hidden" },
			template: `
    <div
      #canvas
      class="min-h-0 grow overflow-hidden px-4 pb-4"
    >
      <div
        class="relative mx-auto overflow-hidden"
        [style.width]="scaledWidth()"
        [style.height.px]="canvasHeight()"
      >
        <iframe
          #previewFrame
          class="block origin-top-left"
          title="Responsive form preview"
          [style.width]="frameWidth()"
          [style.height.px]="frameHeight()"
          [style.transform]="'scale(' + scale() + ')'"
          (load)="initializeFrame()"
        ></iframe>
      </div>
    </div>
  `
		}]
	}],
	ctorParameters: () => [],
	propDecorators: {
		formFields: [{
			type: i0.Input,
			args: [{
				isSignal: true,
				alias: "formFields",
				required: false
			}]
		}],
		canvas: [{
			type: i0.ViewChild,
			args: ["canvas", { isSignal: true }]
		}],
		previewFrame: [{
			type: i0.ViewChild,
			args: ["previewFrame", { isSignal: true }]
		}]
	}
});
var PreviewDeviceToolbar = class PreviewDeviceToolbar {
	scale = input.required(...ngDevMode ? [{ debugName: "scale" }] : /* istanbul ignore next */ []);
	viewport = inject(PreviewViewportService);
	scalePercent = computed(() => Math.round(this.scale() * 100), ...ngDevMode ? [{ debugName: "scalePercent" }] : /* istanbul ignore next */ []);
	customWidthDraft = signal(this.viewport.customWidth(), ...ngDevMode ? [{ debugName: "customWidthDraft" }] : /* istanbul ignore next */ []);
	isCustomWidthValid = computed(() => {
		const width = this.customWidthDraft();
		return width !== null && Number.isFinite(width) && width >= 240 && width <= 3840;
	}, ...ngDevMode ? [{ debugName: "isCustomWidthValid" }] : /* istanbul ignore next */ []);
	presetOptions = [
		{
			label: "Auto",
			value: "auto"
		},
		{
			label: "SM",
			value: "sm"
		},
		{
			label: "MD",
			value: "md"
		},
		{
			label: "LG",
			value: "lg"
		},
		{
			label: "XL",
			value: "xl"
		},
		{
			label: "Custom",
			value: "custom"
		}
	];
	selectPreset(preset) {
		this.viewport.selectPreset(preset);
		if (preset === "custom") this.resetCustomWidthDraft();
	}
	resetCustomWidthDraft() {
		this.customWidthDraft.set(this.viewport.customWidth());
	}
	confirmCustomWidth() {
		const width = this.customWidthDraft();
		if (width !== null && this.isCustomWidthValid()) this.viewport.setCustomWidth(width);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PreviewDeviceToolbar,
		deps: [],
		target: i0.ɵɵFactoryTarget.Component
	});
	static ɵcmp = i0.ɵɵngDeclareComponent({
		minVersion: "17.0.0",
		version: "22.2.3",
		type: PreviewDeviceToolbar,
		isStandalone: true,
		selector: "core-preview-device-toolbar",
		inputs: { scale: {
			classPropertyName: "scale",
			publicName: "scale",
			isSignal: true,
			isRequired: true,
			transformFunction: null
		} },
		host: { classAttribute: "flex flex-wrap items-center justify-center min-h-(--sub-panel-header-height) shrink-0 gap-2" },
		ngImport: i0,
		template: `
    <div
      class="core-segmented"
      role="group"
      aria-label="Preview device width"
    >
      @for (option of presetOptions; track option.value) {
        <button
          coreButton
          text
          type="button"
          [attr.aria-pressed]="viewport.preset() === option.value"
          (click)="selectPreset(option.value)"
        >
          {{ option.label }}
        </button>
      }
    </div>
    @if (viewport.preset() === 'custom') {
      <span class="inline-flex items-center gap-1">
        <input
          coreInput
          type="number"
          aria-label="Custom width"
          id="preview-custom-width"
          class="w-24"
          [min]="240"
          [max]="3840"
          [ngModel]="customWidthDraft()"
          (ngModelChange)="customWidthDraft.set($event)"
          (keydown.enter)="confirmCustomWidth()"
        />
        <button
          coreButton
          text
          rounded
          aria-label="Confirm width"
          coreTooltip="Confirm width"
          tooltipPosition="above"
          [disabled]="!isCustomWidthValid()"
          (click)="confirmCustomWidth()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            check
          </i>
        </button>
      </span>
    }
    <span
      class="text-sm whitespace-nowrap text-muted-color"
      aria-live="polite"
    >
      {{ viewport.targetWidth() ? viewport.targetWidth() + 'px' : 'Auto' }} · {{ scalePercent() }}%
    </span>
  `,
		isInline: true,
		dependencies: [
			{
				kind: "ngmodule",
				type: FormsModule
			},
			{
				kind: "directive",
				type: i1$1.DefaultValueAccessor,
				selector: "input:not([type=checkbox]):not([ngNoCva])[formControlName],textarea:not([ngNoCva])[formControlName],input:not([type=checkbox]):not([ngNoCva])[formControl],textarea:not([ngNoCva])[formControl],input:not([type=checkbox]):not([ngNoCva])[ngModel],textarea:not([ngNoCva])[ngModel],[ngDefaultControl]"
			},
			{
				kind: "directive",
				type: i1$1.NumberValueAccessor,
				selector: "input[type=number]:not([ngNoCva])[formControlName],input[type=number]:not([ngNoCva])[formControl],input[type=number]:not([ngNoCva])[ngModel]"
			},
			{
				kind: "directive",
				type: i1$1.NgControlStatus,
				selector: "[formControlName],[ngModel],[formControl]"
			},
			{
				kind: "directive",
				type: i1$1.MinValidator,
				selector: "input[type=number][min][formControlName],input[type=number][min][formControl],input[type=number][min][ngModel]",
				inputs: ["min"]
			},
			{
				kind: "directive",
				type: i1$1.MaxValidator,
				selector: "input[type=number][max][formControlName],input[type=number][max][formControl],input[type=number][max][ngModel]",
				inputs: ["max"]
			},
			{
				kind: "directive",
				type: i1$1.NgModel,
				selector: "[ngModel]:not([formControlName]):not([formControl])",
				inputs: [
					"name",
					"disabled",
					"ngModel",
					"ngModelOptions"
				],
				outputs: ["ngModelChange"],
				exportAs: ["ngModel"]
			},
			{
				kind: "directive",
				type: Tooltip,
				selector: "[coreTooltip]"
			}
		],
		changeDetection: i0.ChangeDetectionStrategy.OnPush
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PreviewDeviceToolbar,
	decorators: [{
		type: Component,
		args: [{
			selector: "core-preview-device-toolbar",
			changeDetection: ChangeDetectionStrategy.OnPush,
			imports: [FormsModule, Tooltip],
			host: { class: "flex flex-wrap items-center justify-center min-h-(--sub-panel-header-height) shrink-0 gap-2" },
			template: `
    <div
      class="core-segmented"
      role="group"
      aria-label="Preview device width"
    >
      @for (option of presetOptions; track option.value) {
        <button
          coreButton
          text
          type="button"
          [attr.aria-pressed]="viewport.preset() === option.value"
          (click)="selectPreset(option.value)"
        >
          {{ option.label }}
        </button>
      }
    </div>
    @if (viewport.preset() === 'custom') {
      <span class="inline-flex items-center gap-1">
        <input
          coreInput
          type="number"
          aria-label="Custom width"
          id="preview-custom-width"
          class="w-24"
          [min]="240"
          [max]="3840"
          [ngModel]="customWidthDraft()"
          (ngModelChange)="customWidthDraft.set($event)"
          (keydown.enter)="confirmCustomWidth()"
        />
        <button
          coreButton
          text
          rounded
          aria-label="Confirm width"
          coreTooltip="Confirm width"
          tooltipPosition="above"
          [disabled]="!isCustomWidthValid()"
          (click)="confirmCustomWidth()"
        >
          <i
            coreButtonIcon
            class="material-symbols-outlined"
          >
            check
          </i>
        </button>
      </span>
    }
    <span
      class="text-sm whitespace-nowrap text-muted-color"
      aria-live="polite"
    >
      {{ viewport.targetWidth() ? viewport.targetWidth() + 'px' : 'Auto' }} · {{ scalePercent() }}%
    </span>
  `
		}]
	}],
	propDecorators: { scale: [{
		type: i0.Input,
		args: [{
			isSignal: true,
			alias: "scale",
			required: true
		}]
	}] }
});
var ExportDialogService = class ExportDialogService {
	isOpenSrc = signal(false, ...ngDevMode ? [{ debugName: "isOpenSrc" }] : /* istanbul ignore next */ []);
	isOpen = this.isOpenSrc.asReadonly();
	open() {
		this.isOpenSrc.set(true);
	}
	close() {
		this.isOpenSrc.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExportDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExportDialogService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExportDialogService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var PreviewDialogService = class PreviewDialogService {
	isOpenSrc = signal(false, ...ngDevMode ? [{ debugName: "isOpenSrc" }] : /* istanbul ignore next */ []);
	isOpen = this.isOpenSrc.asReadonly();
	open() {
		this.isOpenSrc.set(true);
	}
	close() {
		this.isOpenSrc.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PreviewDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: PreviewDialogService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: PreviewDialogService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
var ArrayTableDialogService = class ArrayTableDialogService {
	_data = signal(null, ...ngDevMode ? [{ debugName: "_data" }] : /* istanbul ignore next */ []);
	data = this._data.asReadonly();
	_isOpen = signal(false, ...ngDevMode ? [{ debugName: "_isOpen" }] : /* istanbul ignore next */ []);
	isOpen = this._isOpen.asReadonly();
	open(data) {
		this._data.set({
			...data,
			childProperties: structuredClone(data.childProperties),
			rows: structuredClone(data.rows)
		});
		this._isOpen.set(true);
	}
	close() {
		this._data.set(null);
		this._isOpen.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ArrayTableDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ArrayTableDialogService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ArrayTableDialogService,
	decorators: [{ type: Injectable }]
});
var ExpressionDialogService = class ExpressionDialogService {
	_data = signal(null, ...ngDevMode ? [{ debugName: "_data" }] : /* istanbul ignore next */ []);
	data = this._data.asReadonly();
	_isOpen = signal(false, ...ngDevMode ? [{ debugName: "_isOpen" }] : /* istanbul ignore next */ []);
	isOpen = this._isOpen.asReadonly();
	open(data) {
		this._data.set(data);
		this._isOpen.set(true);
	}
	close() {
		this._data.set(null);
		this._isOpen.set(false);
	}
	setKey(key) {
		this._data.update((d) => d ? {
			...d,
			key
		} : d);
	}
	setValue(value) {
		this._data.update((d) => d ? {
			...d,
			value
		} : d);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpressionDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ExpressionDialogService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ExpressionDialogService,
	decorators: [{ type: Injectable }]
});
function beautifyCode(code) {
	return beautify.js(code, { indent_size: 2 });
}
async function flattenToOneLine(code) {
	try {
		const result = await minify(code, {
			compress: false,
			mangle: false,
			format: {
				semicolons: true,
				beautify: false,
				comments: false,
				wrap_iife: false,
				quote_style: 1
			}
		});
		if (result && typeof result.code === "string") return result.code.replace(/\s*\n\s*/g, " ").trim();
	} catch (e) {
		console.warn("Failed to minify, using fall back..", e);
	}
	return code.replace(/\s*\n\s*/g, " ").replace(/\s+/g, " ").trim();
}
var MarkdownDialogService = class MarkdownDialogService {
	_data = signal(null, ...ngDevMode ? [{ debugName: "_data" }] : /* istanbul ignore next */ []);
	data = this._data.asReadonly();
	_isOpen = signal(false, ...ngDevMode ? [{ debugName: "_isOpen" }] : /* istanbul ignore next */ []);
	isOpen = this._isOpen.asReadonly();
	open(data) {
		this._data.set(data);
		this._isOpen.set(true);
	}
	close() {
		this._data.set(null);
		this._isOpen.set(false);
	}
	setValue(value) {
		this._data.update((data) => data ? {
			...data,
			value
		} : data);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MarkdownDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: MarkdownDialogService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: MarkdownDialogService,
	decorators: [{ type: Injectable }]
});
var FieldPresetDialogService = class FieldPresetDialogService {
	_data = signal(null, ...ngDevMode ? [{ debugName: "_data" }] : /* istanbul ignore next */ []);
	data = this._data.asReadonly();
	_isOpen = signal(false, ...ngDevMode ? [{ debugName: "_isOpen" }] : /* istanbul ignore next */ []);
	isOpen = this._isOpen.asReadonly();
	open(data) {
		this._data.set(data);
		this._isOpen.set(true);
	}
	close() {
		this._data.set(null);
		this._isOpen.set(false);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldPresetDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: FieldPresetDialogService
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: FieldPresetDialogService,
	decorators: [{ type: Injectable }]
});
var ImportDialogService = class ImportDialogService {
	isOpenSrc = signal(false, ...ngDevMode ? [{ debugName: "isOpenSrc" }] : /* istanbul ignore next */ []);
	isOpen = this.isOpenSrc.asReadonly();
	onImportedCallback = null;
	open(onImported) {
		this.onImportedCallback = onImported ?? null;
		this.isOpenSrc.set(true);
	}
	close() {
		this.isOpenSrc.set(false);
		this.onImportedCallback = null;
	}
	notifyImported(formId) {
		this.onImportedCallback?.(formId);
	}
	static ɵfac = i0.ɵɵngDeclareFactory({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ImportDialogService,
		deps: [],
		target: i0.ɵɵFactoryTarget.Injectable
	});
	static ɵprov = i0.ɵɵngDeclareInjectable({
		minVersion: "12.0.0",
		version: "22.2.3",
		ngImport: i0,
		type: ImportDialogService,
		providedIn: "root"
	});
};
i0.ɵɵngDeclareClassMetadata({
	minVersion: "12.0.0",
	version: "22.2.3",
	ngImport: i0,
	type: ImportDialogService,
	decorators: [{
		type: Injectable,
		args: [{ providedIn: "root" }]
	}]
});
export { createSelectProperty as $, CoreLibraryService as A, CORE_EDITOR_CONFIG as B, PanelHeader as C, CreateFormDialogService as D, CORE_THEME as E, createLibrary as F, createValidationMessagesProperty as G, CORE_LIBRARY_CONFIGS as H, defaultTypeOption as I, getDefaultPropertyFromValue as J, getChildPath as K, generateTypeOptionSchema as L, vanillaLibraryConfig as M, nativeFieldConfig as N, CoreFormService as O, nativeFieldTypes as P, trackByPropertyKey as Q, generateTypeOptionSchemaMap as R, Tooltip as S, CodeEditor as T, Dialog$1 as U, CORE_FORM_TEMPLATES as V, createWrappersProperty as W, getPropertySchema as X, getDefaultPropertyValue as Y, modifyPropertyTarget as Z, JSONSchemaValidator as _, MarkdownDialogService as a, createDateProperty as at, TreeItem as b, ExpressionDialogService as c, createBooleanProperty as ct, ExportDialogService as d, PropertyType as dt, createObjectProperty as et, PreviewDeviceToolbar as f, CORE_BUILDER_FORM as g, FormlyConfigService as h, FieldPresetDialogService as i, createExpressionsProperty as it, VANILLA_LIBRARY_ID as j, CoreFieldService as k, ArrayTableDialogService as l, createArrayProperty as lt, PreviewViewportService as m, FormStoreRecoveryRequiredError as n, createInputProperty as nt, beautifyCode as o, createCustomValidationProperty as ot, FormPreviewContent as p, getDefaultProperty as q, ImportDialogService as r, createGroupProperty as rt, flattenToOneLine as s, createChipsProperty as st, CORE_FORM_STORE$1 as t, createMarkdownProperty as tt, PreviewDialogService as u, PropertyChangeType as ut, JSONFormatValidator as v, Filter as w, MouseInsideService as x, JSONContent as y, PanelService as z };

//# sourceMappingURL=ngx-formly-builder-ui-types-D0bY_dJC.mjs.map